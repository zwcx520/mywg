<?php
declare(strict_types=1);

/**
 * 墨韵文阁 CMS 安装程序
 * 适用环境：PHP 8.0+、MySQL 5.7+ / 8.0+、PDO MySQL
 * 安装完成后请删除或重命名本文件。
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('log_errors', '1');

define('INSTALL_ROOT', __DIR__);
define('LOCK_FILE', INSTALL_ROOT . '/storage/install.lock');

session_name('moyun_install');
session_start();

function h(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function post(string $key, string $default = ''): string
{
    return trim((string) ($_POST[$key] ?? $default));
}

function env_checks(): array
{
    $checks = [];
    $checks[] = [
        'label' => 'PHP 版本 ≥ 8.0',
        'ok' => version_compare(PHP_VERSION, '8.0.0', '>='),
        'value' => PHP_VERSION,
        'hint' => '建议使用 PHP 8.2 及以上版本以获得官方安全支持。',
    ];
    foreach (['pdo_mysql' => 'PDO MySQL 扩展', 'mbstring' => '多字节字符串扩展', 'json' => 'JSON 扩展', 'session' => '会话扩展'] as $ext => $label) {
        $checks[] = [
            'label' => $label,
            'ok' => extension_loaded($ext),
            'value' => extension_loaded($ext) ? '已启用' : '未启用',
            'hint' => $ext === 'pdo_mysql' ? '需要安装 pdo_mysql 扩展才能连接 MySQL。' : '',
        ];
    }
    foreach (['config' => 'config 目录', 'storage' => 'storage 目录', 'storage/logs' => 'storage/logs 目录', 'uploads' => 'uploads 目录'] as $dir => $label) {
        $path = INSTALL_ROOT . '/' . $dir;
        if (!is_dir($path)) {
            @mkdir($path, 0775, true);
        }
        $checks[] = [
            'label' => $label . '可写',
            'ok' => is_dir($path) && is_writable($path),
            'value' => is_dir($path) ? (is_writable($path) ? '可写' : '不可写') : '创建失败',
            'hint' => 'Linux 下可执行 chmod -R 775 并确保 Web 用户拥有写权限。',
        ];
    }
    $checks[] = [
        'label' => '数据库结构文件',
        'ok' => is_file(INSTALL_ROOT . '/database/schema.sql'),
        'value' => is_file(INSTALL_ROOT . '/database/schema.sql') ? '已就绪' : '缺失',
        'hint' => '请确认 database/schema.sql 已上传完整。',
    ];
    return $checks;
}

function sql_statements(string $sql): array
{
    $statements = [];
    $buffer = '';
    $length = strlen($sql);
    $quote = null;
    $lineComment = false;
    $blockComment = false;

    for ($i = 0; $i < $length; $i++) {
        $char = $sql[$i];
        $next = $sql[$i + 1] ?? '';
        if ($lineComment) {
            if ($char === "\n") {
                $lineComment = false;
                $buffer .= $char;
            }
            continue;
        }
        if ($blockComment) {
            if ($char === '*' && $next === '/') {
                $blockComment = false;
                $i++;
            }
            continue;
        }
        if ($quote !== null) {
            $buffer .= $char;
            if ($char === '\\' && $next !== '') {
                $buffer .= $next;
                $i++;
                continue;
            }
            if ($char === $quote) {
                $quote = null;
            }
            continue;
        }
        if ($char === '-' && $next === '-') {
            $lineComment = true;
            $i++;
            continue;
        }
        if ($char === '#') {
            $lineComment = true;
            continue;
        }
        if ($char === '/' && $next === '*') {
            $blockComment = true;
            $i++;
            continue;
        }
        if ($char === "'" || $char === '"' || $char === '`') {
            $quote = $char;
            $buffer .= $char;
            continue;
        }
        if ($char === ';') {
            $trimmed = trim($buffer);
            if ($trimmed !== '') {
                $statements[] = $trimmed;
            }
            $buffer = '';
            continue;
        }
        $buffer .= $char;
    }
    $trimmed = trim($buffer);
    if ($trimmed !== '') {
        $statements[] = $trimmed;
    }
    return $statements;
}

/**
 * 演示数据：作者 + 两本作品 + 分卷章节，全部走“审核版 → 发布版”结构。
 */
function seed_demo(PDO $pdo, int $adminId): void
{
    $now = date('Y-m-d H:i:s');
    $hash = password_hash('demo1234', PASSWORD_DEFAULT);

    $stmt = $pdo->prepare('INSERT INTO users (login_name, email, password_hash, status, register_ip, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute(['author_demo', 'author_demo@example.com', $hash, 'active', '127.0.0.1', $now, $now]);
    $authorUserId = (int) $pdo->lastInsertId();

    $pdo->prepare('INSERT INTO user_profiles (user_id, nickname, bio) VALUES (?, ?, ?)')
        ->execute([$authorUserId, '云间墨', '在字里行间写温柔的重逢。']);
    $pdo->prepare('INSERT INTO user_settings (user_id, font_size, line_height, theme, reading_mode, updated_at) VALUES (?, 18, 2, ?, ?, ?)')
        ->execute([$authorUserId, 'light', 'scroll', $now]);

    $roleStmt = $pdo->prepare('SELECT id FROM roles WHERE code = ?');
    foreach (['reader', 'author'] as $code) {
        $roleStmt->execute([$code]);
        $roleId = (int) $roleStmt->fetchColumn();
        if ($roleId > 0) {
            $pdo->prepare('INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)')->execute([$authorUserId, $roleId]);
        }
    }

    $pdo->prepare('INSERT INTO authors (user_id, pen_name, intro, status, created_at) VALUES (?, ?, ?, ?, ?)')
        ->execute([$authorUserId, '云间墨', '喜欢写旧城灯火与长夜重逢，作品以温柔见长。', 'active', $now]);
    $authorId = (int) $pdo->lastInsertId();

    $pdo->prepare('INSERT INTO author_applications (user_id, pen_name, intro, real_name, id_no, phone, status, remark, reviewed_by, reviewed_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$authorUserId, '云间墨', '喜欢写旧城灯火与长夜重逢。', '演示作者', '110101199001011234', '13800000000', 'approved', '演示数据自动通过', $adminId, $now, $now]);
    $pdo->prepare('INSERT INTO user_identities (user_id, real_name, id_no, phone, status, remark, reviewed_by, reviewed_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$authorUserId, '演示作者', '110101199001011234', '13800000000', 'approved', '演示数据自动通过', $adminId, $now, $now]);

    $books = [
        [
            'code' => 'DEMO001', 'category' => 1, 'title' => '长夜灯火', 'status' => 'serializing',
            'summary' => '城市入夜之后，顾清和在一间旧书店遇见了多年未见的故人。灯火、雨声与未寄出的信，把两个人的距离一点点拉近。这是一个关于等待与重逢的温柔故事。',
            'tags' => [1, 10, 11],
            'chapters' => [
                ['第一章 雨落旧书店', "雨是从傍晚开始下的。\n\n顾清和收好最后一摞书，抬头时，玻璃门外站着一个撑黑伞的人。伞沿压得很低，只露出一截熟悉的下颌线。\n\n“打烊了吗？”那人问。\n\n声音落下来的瞬间，顾清和手里的书脊轻轻磕在柜台上。那是她以为再也不会听见的声音。\n\n“还没有。”她说，把灯又调亮了一些。"],
                ['第二章 未寄出的信', "旧书店的二楼有一只看不清年代的木箱，里面放着几十封没有寄出的信。\n\n信封上写着同一个名字，字迹从少年时的青涩，慢慢变得沉稳。顾清和从来没有打开过它们。\n\n“为什么不寄？”程屿问。\n\n“因为不知道地址。”她笑了一下，“也不知道，收到的人还需不需要。”\n\n窗外雨声渐密，灯影在纸页上轻轻晃动。"],
                ['第三章 灯火与你', "临近午夜，雨终于停了。\n\n程屿帮她把最后一箱书搬进储藏室，衣袖上沾了薄薄一层灰。顾清和递过去一杯热茶，杯沿冒着细白的雾。\n\n“书店会一直开下去吗？”他问。\n\n“会。”她说，“只要还有人愿意在夜里读书。”\n\n程屿看着她，忽然说：“那我以后常来。”\n\n城市的灯火落在玻璃上，像一场迟到很久的回应。"],
            ],
        ],
        [
            'code' => 'DEMO002', 'category' => 2, 'title' => '雪落长安', 'status' => 'finished',
            'summary' => '长安初雪那日，沈知雪在城门口捡到一枚断裂的玉簪。玉簪主人是少年将军，也是她此生最不该靠近的人。山河与风雪之间，一段克制而深的旧梦缓缓展开。',
            'tags' => [2, 9, 12],
            'chapters' => [
                ['第一章 初雪', "长安的第一场雪来得比往年早。\n\n沈知雪裹紧披风，在城门下的积雪里看见一点莹白。她弯腰拾起，是一枚断成两半的玉簪，簪尾刻着极小的一个“砚”字。\n\n守城的老卒说，那是裴小将军今晨出城时遗落的。\n\n她把玉簪收进袖中，指尖被冻得发红，却没有立刻归还。"],
                ['第二章 城头月', "裴砚回城时已是深夜。\n\n城头的月色薄得像一层霜，沈知雪站在灯下等他，袖中的玉簪硌着掌心。\n\n“沈姑娘。”他翻身下马，声音里带着风雪的凉意，“这么晚，不安全。”\n\n“有人托我还你一样东西。”她把玉簪递过去，没有抬头。\n\n裴砚看了很久，才伸手接过。断口锋利，像某些未说出口的话。"],
            ],
        ],
    ];

    $bookStmt = $pdo->prepare('INSERT INTO books (book_code, author_id, category_id, title, summary, copyright_note, status, word_count, view_count, favorite_count, rating, rating_count, published_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $volStmt = $pdo->prepare('INSERT INTO volumes (book_id, title, sort, status, created_at) VALUES (?, ?, ?, ?, ?)');
    $chapterStmt = $pdo->prepare('INSERT INTO chapters (book_id, volume_id, chapter_no, title, status, word_count, read_count, published_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $contentStmt = $pdo->prepare('INSERT INTO chapter_contents (chapter_id, version_no, content, word_count, checksum, created_at) VALUES (?, 1, ?, ?, ?, ?)');
    $versionStmt = $pdo->prepare('INSERT INTO chapter_versions (chapter_id, version_no, kind, content, word_count, created_by, created_at) VALUES (?, 1, ?, ?, ?, ?, ?)');
    $tagStmt = $pdo->prepare('INSERT INTO book_tag_map (book_id, tag_id) VALUES (?, ?)');
    $reviewStmt = $pdo->prepare('INSERT INTO book_reviews (book_id, reviewer_id, action, reason, created_at) VALUES (?, ?, ?, ?, ?)');

    foreach ($books as $index => $book) {
        $plain = '';
        $chapterRows = [];
        foreach ($book['chapters'] as $chapter) {
            $chapterRows[] = [
                'title' => $chapter[0],
                'content' => $chapter[1],
                'words' => (int) mb_strlen(preg_replace('/\s+/u', '', strip_tags($chapter[1])) ?? '', 'UTF-8'),
            ];
            $plain .= $chapter[1];
        }
        $totalWords = (int) mb_strlen(preg_replace('/\s+/u', '', strip_tags($plain)) ?? '', 'UTF-8');
        $bookStmt->execute([
            $book['code'], $authorId, $book['category'], $book['title'], $book['summary'],
            '本作品为演示数据，版权归作者所有，仅用于展示先审后发流程。',
            $book['status'], $totalWords, 1200 + $index * 800, 260 + $index * 120,
            9.2 - $index * 0.4, 12 + $index * 6, $now, $now, $now,
        ]);
        $bookId = (int) $pdo->lastInsertId();
        $volStmt->execute([$bookId, '第一卷 · 初遇', 0, 'public', $now]);
        $volumeId = (int) $pdo->lastInsertId();
        $reviewStmt->execute([$bookId, $adminId, 'approve', '演示数据自动审核通过', $now]);

        foreach ($chapterRows as $i => $row) {
            $chapterStmt->execute([$bookId, $volumeId, $i + 1, $row['title'], 'published', $row['words'], 300 + $i * 120, $now, $now, $now]);
            $chapterId = (int) $pdo->lastInsertId();
            $contentStmt->execute([$chapterId, $row['content'], $row['words'], md5($row['content']), $now]);
            $versionStmt->execute([$chapterId, 'publish', $row['content'], $row['words'], $authorUserId, $now]);
        }
        foreach ($book['tags'] as $tagId) {
            $tagStmt->execute([$bookId, $tagId]);
        }
    }
}

$checks = env_checks();
$envOk = true;
foreach ($checks as $check) {
    if (!$check['ok']) {
        $envOk = false;
    }
}
$installed = is_file(LOCK_FILE);
$errors = [];
$done = false;
$adminAccount = '';
$installResult = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$installed) {
    $token = (string) ($_POST['_token'] ?? '');
    if (empty($_SESSION['_install_csrf']) || !hash_equals((string) $_SESSION['_install_csrf'], $token)) {
        $errors[] = '安装会话已过期，请刷新页面后重新提交。';
    }

    $dbHost = post('db_host', '127.0.0.1');
    $dbPort = (int) post('db_port', '3306');
    $dbName = post('db_name', 'moyun_cms');
    $dbUser = post('db_user', 'root');
    $dbPass = post('db_pass', '');
    $siteName = post('site_name', '墨韵文阁');
    $baseUrl = rtrim(post('base_url', ''), '/');
    $loginName = post('admin_login', '');
    $password = post('admin_password', '');
    $nickname = post('admin_nickname', '站长');
    $demo = isset($_POST['demo_data']);

    if (!$envOk) {
        $errors[] = '环境检查未全部通过，请修复后重试。';
    }
    if ($dbName === '' || !preg_match('/^[A-Za-z0-9_]+$/', $dbName)) {
        $errors[] = '数据库名不能为空，且只能包含字母、数字与下划线。';
    }
    if ($dbHost === '' || $dbUser === '' || $dbPort <= 0) {
        $errors[] = '请完整填写数据库主机、端口与账号。';
    }
    if (!preg_match('/^[A-Za-z0-9_]{3,32}$/', $loginName)) {
        $errors[] = '站长账号需为 3-32 位字母、数字或下划线。';
    }
    if (strlen($password) < 8) {
        $errors[] = '站长密码至少 8 位。';
    }
    if ($siteName === '') {
        $errors[] = '请填写站点名称。';
    }
    if ($baseUrl === '' || !preg_match('#^https?://[^\s]+$#i', $baseUrl)) {
        $errors[] = '站点地址需以 http:// 或 https:// 开头。';
    }
    if (!is_file(INSTALL_ROOT . '/database/schema.sql')) {
        $errors[] = '缺少数据库结构文件 database/schema.sql。';
    }

    if ($errors === []) {
        try {
            $serverDsn = 'mysql:host=' . $dbHost . ';port=' . $dbPort . ';charset=utf8mb4';
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,
            ];
            $server = new PDO($serverDsn, $dbUser, $dbPass, $options);
            $server->exec('CREATE DATABASE IF NOT EXISTS `' . $dbName . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');

            $pdo = new PDO(
                'mysql:host=' . $dbHost . ';port=' . $dbPort . ';dbname=' . $dbName . ';charset=utf8mb4',
                $dbUser,
                $dbPass,
                $options
            );

            $sql = (string) file_get_contents(INSTALL_ROOT . '/database/schema.sql');
            $count = 0;
            foreach (sql_statements($sql) as $statement) {
                $pdo->exec($statement);
                $count++;
            }

            // 写入官方完整分类与标签（幂等，已存在的自动跳过）
            require_once INSTALL_ROOT . '/app/Services/TaxonomySeeder.php';
            \App\Services\TaxonomySeeder::run($pdo);

            $now = date('Y-m-d H:i:s');
            $stmt = $pdo->prepare('SELECT id FROM users WHERE login_name = ? LIMIT 1');
            $stmt->execute([$loginName]);
            $exists = $stmt->fetchColumn();
            if ($exists) {
                $adminId = (int) $exists;
                $pdo->prepare('UPDATE users SET password_hash = ?, status = ?, updated_at = ? WHERE id = ?')
                    ->execute([password_hash($password, PASSWORD_DEFAULT), 'active', $now, $adminId]);
            } else {
                $pdo->prepare('INSERT INTO users (login_name, email, password_hash, status, register_ip, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
                    ->execute([$loginName, $loginName . '@example.com', password_hash($password, PASSWORD_DEFAULT), 'active', '127.0.0.1', $now, $now]);
                $adminId = (int) $pdo->lastInsertId();
            }

            $profile = $pdo->prepare('SELECT id FROM user_profiles WHERE user_id = ?');
            $profile->execute([$adminId]);
            if (!$profile->fetchColumn()) {
                $pdo->prepare('INSERT INTO user_profiles (user_id, nickname, bio) VALUES (?, ?, ?)')
                    ->execute([$adminId, $nickname, '在这里，守护每一个温柔的故事。']);
            } else {
                $pdo->prepare('UPDATE user_profiles SET nickname = ? WHERE user_id = ?')->execute([$nickname, $adminId]);
            }
            $pdo->prepare('INSERT IGNORE INTO user_settings (user_id, font_size, line_height, theme, reading_mode, updated_at) VALUES (?, 18, 2, ?, ?, ?)')
                ->execute([$adminId, 'light', 'scroll', $now]);

            $roleStmt = $pdo->prepare('SELECT id FROM roles WHERE code = ?');
            foreach (['admin', 'reader'] as $code) {
                $roleStmt->execute([$code]);
                $roleId = (int) $roleStmt->fetchColumn();
                if ($roleId > 0) {
                    $pdo->prepare('INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)')->execute([$adminId, $roleId]);
                }
            }

            $pdo->prepare('INSERT INTO site_settings (skey, svalue, grp, updated_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue), updated_at = VALUES(updated_at)')
                ->execute(['site_name', $siteName, 'site', $now]);

            if ($demo) {
                $demoStmt = $pdo->prepare('SELECT id FROM users WHERE login_name = ? LIMIT 1');
                $demoStmt->execute(['author_demo']);
                if (!$demoStmt->fetchColumn()) {
                    seed_demo($pdo, $adminId);
                }
            }

            $config = [
                'app_name' => $siteName,
                'base_url' => $baseUrl,
                // query：使用 index.php?r=/path 访问，无需配置 Nginx 伪静态
                // pretty：站点已配置 try_files 伪静态后可改为 pretty
                'url_mode' => 'query',
                'timezone' => 'Asia/Shanghai',
                'debug' => false,
                'db' => [
                    'host' => $dbHost,
                    'port' => $dbPort,
                    'name' => $dbName,
                    'user' => $dbUser,
                    'pass' => $dbPass,
                    'charset' => 'utf8mb4',
                    'collation' => 'utf8mb4_unicode_ci',
                ],
                'security' => [
                    'session_name' => 'moyun_session',
                    'install_lock' => 'storage/install.lock',
                ],
            ];
            $configPath = INSTALL_ROOT . '/config/config.php';
            $written = file_put_contents($configPath, "<?php\n\nreturn " . var_export($config, true) . ";\n");
            if ($written === false) {
                throw new RuntimeException('无法写入 config/config.php，请检查目录权限。');
            }

            foreach (['uploads/covers', 'uploads/avatars', 'uploads/branding', 'storage/logs'] as $dir) {
                $path = INSTALL_ROOT . '/' . $dir;
                if (!is_dir($path)) {
                    @mkdir($path, 0775, true);
                }
            }

            file_put_contents(LOCK_FILE, "installed_at=" . $now . "\nversion=1.0\n");

            $_SESSION['_install_csrf'] = null;
            $done = true;
            $adminAccount = $loginName;
            $installResult = [
                'site' => $siteName,
                'base_url' => $baseUrl,
                'admin' => $loginName,
                'password' => $password,
                'demo' => $demo,
                'statements' => $count,
            ];
        } catch (Throwable $e) {
            $errors[] = '安装失败：' . $e->getMessage();
        }
    }
}

if (empty($_SESSION['_install_csrf'])) {
    $_SESSION['_install_csrf'] = bin2hex(random_bytes(32));
}
$csrf = (string) $_SESSION['_install_csrf'];

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
$scriptDir = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/install.php'))), '/');
$autoBase = $scheme . '://' . $host . ($scriptDir === '' ? '' : $scriptDir);
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>安装 · 墨韵文阁 CMS</title>
    <?php
    $fontLocal = 'resources/assets/vendor/fonts/google-fonts.css';
    $faLocal = 'resources/assets/vendor/font-awesome/css/all.min.css';
    ?>
    <link rel="stylesheet" href="<?= h(is_file(INSTALL_ROOT . '/' . $fontLocal) ? $fontLocal : 'https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@400;500;600;700&display=swap') ?>">
    <link rel="stylesheet" href="<?= h(is_file(INSTALL_ROOT . '/' . $faLocal) ? $faLocal : 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css') ?>">
    <style>
        :root {
            --ink: #3d2b3f;
            --ink-soft: #6b566d;
            --rose: #c48698;
            --rose-deep: #a96b7f;
            --gold: #d8b48a;
            --cream: #fbf6f0;
            --paper: rgba(255, 252, 248, .88);
            --line: rgba(141, 107, 133, .18);
            --shadow: 0 24px 60px rgba(89, 57, 79, .14);
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Noto Serif SC", "Songti SC", serif;
            color: var(--ink);
            background:
                radial-gradient(1200px 700px at 12% -8%, #f3d9de 0%, transparent 55%),
                radial-gradient(900px 600px at 92% 8%, #e6d7ef 0%, transparent 52%),
                linear-gradient(160deg, #fdf8f2 0%, #f7ece9 45%, #f4ecf6 100%);
            background-attachment: fixed;
        }
        .wrap { max-width: 860px; margin: 0 auto; padding: 56px 24px 72px; }
        .brand { text-align: center; margin-bottom: 34px; }
        .brand .seal {
            width: 64px; height: 64px; margin: 0 auto 16px;
            display: grid; place-items: center;
            border-radius: 50%;
            border: 1px solid rgba(168, 107, 127, .35);
            background: linear-gradient(150deg, #fdf4f2, #f3e2e6);
            color: var(--rose-deep); font-size: 26px;
            box-shadow: 0 10px 30px rgba(168, 107, 127, .18);
        }
        .brand h1 { margin: 0 0 8px; font-size: 30px; letter-spacing: .18em; font-weight: 600; }
        .brand p { margin: 0; color: var(--ink-soft); font-size: 13px; letter-spacing: .12em; }
        .card {
            background: var(--paper);
            border: 1px solid var(--line);
            border-radius: 26px;
            box-shadow: var(--shadow);
            backdrop-filter: blur(16px);
            padding: 34px;
            margin-bottom: 22px;
        }
        .steps { display: flex; gap: 10px; margin-bottom: 26px; flex-wrap: wrap; }
        .step {
            flex: 1 1 160px; padding: 12px 16px; border-radius: 16px;
            border: 1px solid var(--line); background: rgba(255,255,255,.55);
            font-size: 13px; color: var(--ink-soft);
        }
        .step strong { display: block; font-size: 12px; color: var(--rose-deep); letter-spacing: .14em; margin-bottom: 4px; }
        h2 { font-size: 19px; margin: 0 0 8px; font-weight: 600; letter-spacing: .08em; }
        .sub { color: var(--ink-soft); font-size: 13px; margin: 0 0 22px; }
        .check-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 10px; }
        .check-list li {
            display: flex; align-items: center; gap: 12px; padding: 12px 16px;
            border-radius: 14px; background: rgba(255,255,255,.62); border: 1px solid var(--line);
        }
        .check-list i { font-size: 15px; }
        .ok { color: #4f8a6d; }
        .bad { color: #b4525b; }
        .check-list .meta { margin-left: auto; font-size: 12px; color: var(--ink-soft); }
        .check-list .hint { flex-basis: 100%; font-size: 12px; color: #a07f86; margin-top: 4px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .field { display: flex; flex-direction: column; gap: 7px; }
        .field.full { grid-column: 1 / -1; }
        label { font-size: 13px; color: var(--ink-soft); letter-spacing: .06em; }
        input[type=text], input[type=password], input[type=number] {
            width: 100%; padding: 12px 14px; border-radius: 12px;
            border: 1px solid var(--line); background: rgba(255,255,255,.8);
            font-family: inherit; font-size: 14px; color: var(--ink);
            outline: none; transition: border-color .2s, box-shadow .2s;
        }
        input:focus { border-color: var(--rose); box-shadow: 0 0 0 4px rgba(196, 134, 152, .14); }
        .switch-row { display: flex; align-items: center; gap: 10px; font-size: 13px; color: var(--ink-soft); }
        .divider { height: 1px; background: var(--line); margin: 24px 0; }
        .btn {
            display: inline-flex; align-items: center; justify-content: center; gap: 10px;
            width: 100%; padding: 15px 22px; border: 0; border-radius: 999px;
            background: linear-gradient(120deg, #b9788d, #d3a0ac 55%, #d8b48a);
            color: #fff; font-family: inherit; font-size: 15px; letter-spacing: .22em;
            cursor: pointer; box-shadow: 0 16px 34px rgba(169, 107, 127, .28);
            transition: transform .2s, box-shadow .2s;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 20px 40px rgba(169, 107, 127, .34); }
        .btn[disabled] { opacity: .55; cursor: not-allowed; transform: none; }
        .alert { border-radius: 14px; padding: 14px 18px; font-size: 13px; margin-bottom: 18px; }
        .alert.error { background: #fbeaec; border: 1px solid #e6bcc3; color: #8f3b45; }
        .alert.success { background: #edf7f0; border: 1px solid #c3e0cd; color: #376b50; }
        .alert.info { background: #f4effa; border: 1px solid #ddd0ea; color: #5d4a75; }
        .done-hero { text-align: center; padding: 12px 0 6px; }
        .done-hero i { font-size: 46px; color: #7fa78a; }
        .done-hero h2 { margin-top: 14px; }
        .kv { width: 100%; border-collapse: collapse; margin-top: 18px; font-size: 13.5px; }
        .kv th, .kv td { text-align: left; padding: 11px 12px; border-bottom: 1px dashed var(--line); vertical-align: top; }
        .kv th { width: 132px; color: var(--ink-soft); font-weight: 500; }
        .links { display: grid; gap: 12px; margin-top: 22px; }
        .link-card {
            display: flex; align-items: center; gap: 14px; padding: 16px 18px;
            border-radius: 16px; border: 1px solid var(--line); background: rgba(255,255,255,.66);
            color: var(--ink); text-decoration: none; transition: transform .2s, border-color .2s;
        }
        .link-card:hover { transform: translateY(-2px); border-color: var(--rose); }
        .link-card i { color: var(--rose-deep); font-size: 18px; width: 24px; text-align: center; }
        .link-card span { font-size: 13px; color: var(--ink-soft); display: block; }
        .notice {
            margin-top: 18px; padding: 14px 18px; border-radius: 14px;
            background: rgba(216, 180, 138, .12); border: 1px dashed rgba(184, 140, 96, .4);
            font-size: 12.5px; color: #8a6a4c; line-height: 1.8;
        }
        .footer { text-align: center; font-size: 11.5px; color: #a895a0; letter-spacing: .12em; margin-top: 30px; }
        @media (max-width: 640px) {
            .wrap { padding: 32px 16px 48px; }
            .card { padding: 22px 18px; border-radius: 20px; }
            .grid { grid-template-columns: 1fr; }
            .brand h1 { font-size: 24px; }
        }
    </style>
</head>
<body>
<div class="wrap">
    <div class="brand">
        <div class="seal"><i class="fa-solid fa-feather-pointed"></i></div>
        <h1>墨韵文阁</h1>
        <p>CMS 安装向导 · 浪漫唯美网络文学平台</p>
    </div>

    <?php if ($installed): ?>
        <div class="card">
            <div class="done-hero">
                <i class="fa-solid fa-lock"></i>
                <h2>系统已经安装</h2>
                <p class="sub">检测到 storage/install.lock，为避免覆盖数据，安装程序已锁定。</p>
            </div>
            <div class="links">
                <a class="link-card" href="index.php"><i class="fa-solid fa-book-open"></i><div>进入网站首页<span>读者访问端</span></div></a>
                <a class="link-card" href="index.php?r=admin"><i class="fa-solid fa-sliders"></i><div>进入站长后台<span>内容审核 · 用户 · 运营</span></div></a>
            </div>
            <div class="notice">
                如需重新安装，请先备份数据库与 uploads、config/config.php，然后删除 storage/install.lock 后再次访问 install.php。
                正式上线前请务必删除或重命名 install.php。
            </div>
        </div>
    <?php elseif ($done): ?>
        <div class="card">
            <div class="done-hero">
                <i class="fa-solid fa-circle-check"></i>
                <h2>安装完成，灯火已点亮</h2>
                <p class="sub">「<?= h($installResult['site']) ?>」已经准备好，愿每一次阅读都有温柔的回声。</p>
            </div>
            <table class="kv">
                <tr><th>站点地址</th><td><?= h($installResult['base_url']) ?></td></tr>
                <tr><th>站长账号</th><td><?= h($installResult['admin']) ?></td></tr>
                <tr><th>站长密码</th><td><?= h($installResult['password']) ?>（请立即妥善保存并修改）</td></tr>
                <tr><th>演示数据</th><td><?= $installResult['demo'] ? '已写入（作者 author_demo / demo1234）' : '未写入' ?></td></tr>
                <tr><th>数据库</th><td>结构执行完成，共 <?= (int) $installResult['statements'] ?> 条语句</td></tr>
            </table>
            <div class="links">
                <a class="link-card" href="<?= h(rtrim($installResult['base_url'], '/') . '/index.php') ?>"><i class="fa-solid fa-book-open"></i><div>进入网站首页<span>读者访问端 · 支持手机 / 电脑 UA 自适应</span></div></a>
                <a class="link-card" href="<?= h(rtrim($installResult['base_url'], '/') . '/index.php?r=admin') ?>"><i class="fa-solid fa-sliders"></i><div>进入站长后台<span>审核队列 · 用户 · 分类 · 榜单 · 开关 · 日志</span></div></a>
                <a class="link-card" href="<?= h(rtrim($installResult['base_url'], '/') . '/index.php?r=author/apply') ?>"><i class="fa-solid fa-feather-pointed"></i><div>作家认证入口<span>认证后进入作家创作台</span></div></a>
            </div>
            <div class="notice">
                <strong>上线前请完成：</strong><br>
                1. 删除或重命名 <code>install.php</code>；<br>
                2. 将 <code>config/config.php</code> 与站点根目录设置为不可公开读取；<br>
                3. 为 <code>uploads</code>、<code>storage</code> 配置正确的写入权限；<br>
                4. 配置计划任务每 1-5 分钟执行 <code>php cron.php</code>，以驱动定时发布；<br>
                5. 商业化功能在第一版被锁定关闭，所有已标识付费章节免费开放阅读。
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="steps">
                <div class="step"><strong>STEP 01</strong>环境检查</div>
                <div class="step"><strong>STEP 02</strong>数据库与站长</div>
                <div class="step"><strong>STEP 03</strong>写入配置</div>
            </div>

            <h2>环境检查</h2>
            <p class="sub">先确认运行环境满足首版上线的最低要求。</p>
            <?php if (!$envOk): ?>
                <div class="alert error">存在未通过的环境项，请修复后刷新本页。</div>
            <?php endif; ?>
            <ul class="check-list">
                <?php foreach ($checks as $check): ?>
                    <li>
                        <i class="fa-solid <?= $check['ok'] ? 'fa-circle-check ok' : 'fa-circle-exclamation bad' ?>"></i>
                        <div><?= h($check['label']) ?></div>
                        <div class="meta"><?= h($check['value']) ?></div>
                        <?php if (($check['hint'] ?? '') !== ''): ?>
                            <div class="hint"><?= h($check['hint']) ?></div>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <form class="card" method="post" action="install.php" autocomplete="off">
            <input type="hidden" name="_token" value="<?= h($csrf) ?>">

            <h2>数据库连接</h2>
            <p class="sub">安装程序会自动创建数据库并执行 database/schema.sql。</p>
            <div class="grid">
                <div class="field">
                    <label for="db_host">数据库主机</label>
                    <input id="db_host" type="text" name="db_host" value="<?= h(post('db_host', '127.0.0.1')) ?>" required>
                </div>
                <div class="field">
                    <label for="db_port">端口</label>
                    <input id="db_port" type="number" name="db_port" value="<?= h(post('db_port', '3306')) ?>" min="1" max="65535" required>
                </div>
                <div class="field">
                    <label for="db_name">数据库名</label>
                    <input id="db_name" type="text" name="db_name" value="<?= h(post('db_name', 'moyun_cms')) ?>" required>
                </div>
                <div class="field">
                    <label for="db_user">数据库账号</label>
                    <input id="db_user" type="text" name="db_user" value="<?= h(post('db_user', 'root')) ?>" required>
                </div>
                <div class="field full">
                    <label for="db_pass">数据库密码</label>
                    <input id="db_pass" type="password" name="db_pass" value="<?= h(post('db_pass')) ?>" placeholder="如无需密码可留空">
                </div>
            </div>

            <div class="divider"></div>

            <h2>站点与站长</h2>
            <p class="sub">站长账号将获得全部后台权限，请妥善保管。</p>
            <div class="grid">
                <div class="field">
                    <label for="site_name">站点名称</label>
                    <input id="site_name" type="text" name="site_name" value="<?= h(post('site_name', '墨韵文阁')) ?>" required>
                </div>
                <div class="field">
                    <label for="base_url">站点地址</label>
                    <input id="base_url" type="text" name="base_url" value="<?= h(post('base_url', $autoBase)) ?>" required>
                </div>
                <div class="field">
                    <label for="admin_login">站长账号</label>
                    <input id="admin_login" type="text" name="admin_login" value="<?= h(post('admin_login', 'admin')) ?>" required>
                </div>
                <div class="field">
                    <label for="admin_password">站长密码（≥ 8 位）</label>
                    <input id="admin_password" type="password" name="admin_password" value="<?= h(post('admin_password')) ?>" minlength="8" required>
                </div>
                <div class="field full">
                    <label for="admin_nickname">站长昵称</label>
                    <input id="admin_nickname" type="text" name="admin_nickname" value="<?= h(post('admin_nickname', '站长')) ?>">
                </div>
            </div>

            <div class="divider"></div>

            <div class="switch-row">
                <input id="demo_data" type="checkbox" name="demo_data" value="1" <?= isset($_POST['demo_data']) ? 'checked' : 'checked' ?>>
                <label for="demo_data">写入演示数据（2 本已审核作品、1 位演示作者），便于立即预览先审后发与阅读流程</label>
            </div>

            <div class="divider"></div>

            <button class="btn" type="submit" <?= $envOk ? '' : 'disabled' ?>>
                <i class="fa-solid fa-wand-magic-sparkles"></i> 开始安装
            </button>
            <div class="notice">
                安装过程不会包含任何支付、订阅、打赏或结算功能。第一版商业化开关在数据库中被锁定关闭，
                后台不可切换，相关路由不会注册。
            </div>
        </form>
    <?php endif; ?>

    <div class="footer">墨韵文阁 CMS · 原创文学平台 · 先审后发 · 尊重版权</div>
</div>
</body>
</html>
