<?php
/**
 * 配置示例：安装程序会依据填写内容自动生成 config/config.php。
 * 手动部署时可将本文件复制为 config/config.php 并修改下列值。
 */
return [
    'app_name' => '墨韵文阁',
    'base_url' => 'http://localhost',
    // query：所有站内链接输出为 index.php?r=/path，无需 Nginx 伪静态即可访问
    // pretty：已配置 try_files / .htaccess 伪静态后改用此值
    'url_mode' => 'query',
    'timezone' => 'Asia/Shanghai',
    'debug' => false,
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'moyun_cms',
        'user' => 'root',
        'password' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
    ],
    'security' => [
        'session_name' => 'moyun_session',
        'install_lock' => 'storage/install.lock',
    ],
];
