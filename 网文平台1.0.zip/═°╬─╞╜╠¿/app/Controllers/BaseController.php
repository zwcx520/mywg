<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Request;
use App\Core\View;

class BaseController
{
    protected function view(string $view, array $data = [], string $layout = 'public'): void
    {
        View::render($view, $data, $layout);
    }

    protected function adminView(string $view, array $data = []): void
    {
        View::render('admin/' . $view, $data, 'admin');
    }

    protected function requirePost(): void
    {
        if (!Request::isPost()) {
            abort(405, '该操作需要使用 POST 提交。');
        }
    }

    protected function currentAuthor(): ?array
    {
        $user = Auth::user();
        if (!$user) {
            return null;
        }
        return Database::one('SELECT * FROM authors WHERE user_id = ? LIMIT 1', [(int) $user['id']]);
    }

    protected function requireAuthor(): array
    {
        Auth::requireLogin('/login');
        if (!Auth::hasRole('author') && !Auth::hasRole('admin')) {
            Flash::add('warning', '你的账号未开通作家权限，请联系站长。');
            redirect('/author/apply');
        }
        $author = $this->currentAuthor();
        if (!$author) {
            Flash::add('info', '请先完成作家认证。');
            redirect('/author/apply');
        }
        if ((string) $author['status'] !== 'active') {
            Flash::add('warning', '作家账号当前状态为：' . status_label((string) $author['status']) . '。');
            redirect('/author/apply');
        }
        return $author;
    }

    protected function ownedBook(int $bookId, int $authorId): array
    {
        $book = Database::one("SELECT * FROM books WHERE id = ? AND author_id = ? AND status <> 'deleted' LIMIT 1", [$bookId, $authorId]);
        if (!$book) {
            abort(404, '作品不存在或不属于当前账号。');
        }
        return $book;
    }

    protected function ownedChapter(int $chapterId, int $authorId): array
    {
        $chapter = Database::one(
            'SELECT c.*, b.title AS book_title, b.status AS book_status, b.author_id
             FROM chapters c JOIN books b ON b.id = c.book_id
             WHERE c.id = ? AND b.author_id = ? AND b.status <> \'deleted\' LIMIT 1',
            [$chapterId, $authorId]
        );
        if (!$chapter) {
            abort(404, '章节不存在或不属于当前账号。');
        }
        return $chapter;
    }
}
