<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Logger;
use App\Core\Request;
use App\Core\Settings;
use App\Core\Switches;
use App\Services\RecycleService;
use App\Services\UploadService;
use Throwable;

class SystemController extends BaseController
{
    public function switches(): void
    {
        Auth::requirePermission('admin.switches');
        $rows = Database::all('SELECT * FROM switches ORDER BY grp ASC, id ASC');
        $groups = [];
        foreach ($rows as $row) {
            $groups[(string) $row['grp']][] = $row;
        }
        $this->adminView('switches', compact('groups', 'rows'));
    }

    public function switchToggle(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.switches.manage');
        $switch = Database::one('SELECT * FROM switches WHERE id = ?', [(int) $id]);
        if (!$switch) {
            abort(404, '开关不存在。');
        }
        if ((int) $switch['allow_toggle'] !== 1) {
            Flash::add('error', '该开关在第一版被锁定，不允许变更。');
            redirect('/admin/switches');
        }
        $value = Request::int('value', (int) $switch['value']) === 1 ? 1 : 0;
        $reason = Request::str('reason', '', 255);
        if ($reason === '') {
            Flash::add('error', '变更业务开关必须填写变更原因。');
            redirect('/admin/switches');
        }
        $version = (int) $switch['version'] + 1;
        Database::update('switches', [
            'value' => $value,
            'version' => $version,
            'updated_by' => Auth::id(),
            'updated_at' => date('Y-m-d H:i:s'),
            'reason' => $reason,
        ], ['id' => (int) $switch['id']]);
        Logger::admin(
            'switches',
            '切换业务开关',
            $switch['name'] . '（' . $switch['code'] . '）' . ((int) $switch['value'] === 1 ? '开启' : '关闭') . ' → ' . ($value === 1 ? '开启' : '关闭') . '，版本 v' . $version . '，原因：' . $reason,
            'switch',
            (int) $switch['id']
        );
        Flash::add('success', '开关已更新，版本 v' . $version . '。');
        redirect('/admin/switches');
    }

    public function logs(): void
    {
        Auth::requirePermission('admin.logs');
        $module = Request::str('module', '', 30);
        $keyword = Request::str('q', '', 60);
        $page = max(1, Request::int('page', 1));
        $perPage = 20;

        $where = ['1 = 1'];
        $params = [];
        if ($module !== '') {
            $where[] = 'l.module = ?';
            $params[] = $module;
        }
        if ($keyword !== '') {
            $where[] = '(l.action LIKE ? OR l.detail LIKE ? OR p.nickname LIKE ? OR u.login_name LIKE ?)';
            $like = '%' . $keyword . '%';
            array_push($params, $like, $like, $like, $like);
        }
        $whereSql = implode(' AND ', $where);

        $total = (int) Database::value(
            "SELECT COUNT(*) FROM admin_logs l
             LEFT JOIN user_profiles p ON p.user_id = l.admin_id
             LEFT JOIN users u ON u.id = l.admin_id
             WHERE {$whereSql}",
            $params
        );
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/admin/logs'), ['module' => $module, 'q' => $keyword, 'page' => null]);

        $rows = Database::all(
            "SELECT l.*, p.nickname, u.login_name
             FROM admin_logs l
             LEFT JOIN user_profiles p ON p.user_id = l.admin_id
             LEFT JOIN users u ON u.id = l.admin_id
             WHERE {$whereSql}
             ORDER BY l.id DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );
        $modules = Database::all('SELECT DISTINCT module FROM admin_logs ORDER BY module ASC');

        $this->adminView('logs', compact('rows', 'pager', 'module', 'keyword', 'modules'));
    }

    public function recycle(): void
    {
        Auth::requirePermission('admin.recycle');
        $type = Request::str('type', 'all', 20);
        $page = max(1, Request::int('page', 1));
        $perPage = 20;

        $where = ['r.restored_at IS NULL'];
        $params = [];
        if (in_array($type, ['book', 'volume', 'chapter', 'comment', 'bookshelf'], true)) {
            $where[] = 'r.target_type = ?';
            $params[] = $type;
        }
        $whereSql = implode(' AND ', $where);

        $total = (int) Database::value("SELECT COUNT(*) FROM recycle_items r WHERE {$whereSql}", $params);
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/admin/recycle'), ['type' => $type, 'page' => null]);

        $rows = Database::all(
            "SELECT r.*, p.nickname AS owner_name
             FROM recycle_items r
             LEFT JOIN user_profiles p ON p.user_id = r.owner_id
             WHERE {$whereSql}
             ORDER BY r.id DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );

        $this->adminView('recycle', compact('rows', 'pager', 'type'));
    }

    public function recycleRestore(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.recycle');
        $item = Database::one('SELECT * FROM recycle_items WHERE id = ? AND restored_at IS NULL', [(int) $id]);
        if (!$item) {
            Flash::add('error', '回收站记录不存在或已恢复。');
            redirect('/admin/recycle');
        }
        try {
            Database::transaction(function () use ($item): void {
                $targetId = (int) $item['target_id'];
                switch ((string) $item['target_type']) {
                    case 'book':
                        Database::update('books', [
                            'status' => 'offline',
                            'updated_at' => date('Y-m-d H:i:s'),
                        ], ['id' => $targetId]);
                        break;
                    case 'chapter':
                        $hasContent = Database::one('SELECT chapter_id FROM chapter_contents WHERE chapter_id = ?', [$targetId]);
                        Database::update('chapters', ['status' => $hasContent ? 'published' : 'draft'], ['id' => $targetId]);
                        $chapter = Database::one('SELECT id, book_id FROM chapters WHERE id = ?', [$targetId]);
                        if ($chapter) {
                            RecycleService::restoreChapterAt(
                                (int) $chapter['book_id'],
                                (int) $chapter['id'],
                                RecycleService::parsePosition($item['reason'] ?? null)
                            );
                        }
                        break;
                    case 'volume':
                        Database::update('volumes', ['status' => 'hidden'], ['id' => $targetId]);
                        break;
                    case 'comment':
                        Database::update('comments', ['status' => 'hidden'], ['id' => $targetId]);
                        break;
                }
                Database::update('recycle_items', ['restored_at' => date('Y-m-d H:i:s')], ['id' => (int) $item['id']]);
            });
            Logger::admin('recycle', '恢复回收站内容', $item['target_type'] . ' #' . $item['target_id'] . ' ' . $item['title'], (string) $item['target_type'], (int) $item['target_id']);
            Flash::add('success', '内容已恢复。');
        } catch (Throwable $e) {
            Flash::add('error', '恢复失败：' . $e->getMessage());
        }
        redirect('/admin/recycle');
    }

    public function recyclePurge(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.recycle');
        $item = Database::one('SELECT * FROM recycle_items WHERE id = ?', [(int) $id]);
        if (!$item) {
            Flash::add('error', '回收站记录不存在。');
            redirect('/admin/recycle');
        }
        $bookCover = '';
        try {
            Database::transaction(function () use ($item, &$bookCover): void {
                $targetId = (int) $item['target_id'];
                switch ((string) $item['target_type']) {
                    case 'book':
                        $bookCover = RecycleService::purgeBook($targetId);
                        break;
                    case 'chapter':
                        RecycleService::purgeChapter($targetId);
                        break;
                    case 'volume':
                        RecycleService::purgeVolume($targetId);
                        break;
                    case 'comment':
                        Database::query('DELETE FROM comment_likes WHERE comment_id = ?', [$targetId]);
                        Database::query('DELETE FROM comments WHERE id = ?', [$targetId]);
                        break;
                    case 'bookshelf':
                        Database::query('DELETE FROM bookshelf WHERE id = ?', [$targetId]);
                        break;
                }
                Database::query('DELETE FROM recycle_items WHERE id = ?', [(int) $item['id']]);
            });
            // 彻底删除作品时同步清掉用户目录里的封面文件
            if ($bookCover !== '') {
                UploadService::delete($bookCover);
            }
            Logger::admin('recycle', '彻底删除回收站内容', $item['target_type'] . ' #' . $item['target_id'] . ' ' . $item['title'], (string) $item['target_type'], (int) $item['target_id']);
            Flash::add('success', '内容已彻底删除，无法恢复。');
        } catch (Throwable $e) {
            Flash::add('error', '删除失败：' . $e->getMessage());
        }
        redirect('/admin/recycle');
    }

    public function finance(): void
    {
        Auth::requirePermission('admin.finance');
        $commercialCodes = ['recharge', 'subscription', 'chapter_purchase', 'reward', 'auto_subscribe', 'monthly_ticket', 'reward_gift', 'author_settlement'];
        $commercialSwitches = Database::all(
            "SELECT * FROM switches WHERE code IN ('" . implode("','", $commercialCodes) . "') ORDER BY id ASC"
        );
        $counts = [
            'orders' => (int) Database::value('SELECT COUNT(*) FROM orders'),
            'subscription_orders' => (int) Database::value('SELECT COUNT(*) FROM subscription_orders'),
            'rewards' => (int) Database::value('SELECT COUNT(*) FROM rewards'),
            'settlements' => (int) Database::value('SELECT COUNT(*) FROM settlements'),
        ];
        $this->adminView('finance', compact('commercialSwitches', 'counts'));
    }

    public function settings(): void
    {
        Auth::requirePermission('admin.settings');
        $all = Settings::all(true);
        $this->adminView('settings', ['settings' => $all]);
    }

    public function settingsSave(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.settings');
        $fields = ['site_name', 'site_slogan', 'site_keywords', 'site_desc', 'icp_no', 'copyright_text', 'contact_email', 'report_notice', 'about_text'];
        $changed = [];
        foreach ($fields as $key) {
            if (!array_key_exists($key, $_POST)) {
                continue;
            }
            $value = Request::str($key, '', 4000);
            Settings::save($key, $value);
            $changed[] = $key;
        }
        $logo = Request::file('logo');
        if ($logo !== null) {
            try {
                $oldLogo = (string) Settings::get('site_logo', '');
                $uploaded = UploadService::image($logo, 'logo');
                Settings::save('site_logo', $uploaded);
                $changed[] = 'site_logo';
                if ($oldLogo !== '' && $oldLogo !== $uploaded) {
                    UploadService::delete($oldLogo);
                }
            } catch (Throwable $e) {
                Flash::add('warning', '站点 Logo 上传失败：' . $e->getMessage());
            }
        }
        Logger::admin('settings', '更新站点配置', '变更字段：' . implode(', ', $changed));
        Flash::add('success', '站点配置已保存。');
        redirect('/admin/settings');
    }
}
