<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Logger;
use App\Core\Request;
use App\Services\RecycleService;
use App\Services\ReviewService;

class ContentController extends BaseController
{
    public function books(): void
    {
        Auth::requirePermission('admin.books');
        $keyword = Request::str('q', '', 60);
        $status = Request::str('status', 'all', 20);
        $page = max(1, Request::int('page', 1));
        $perPage = 20;

        $where = ['1 = 1'];
        $params = [];
        if ($keyword !== '') {
            $where[] = '(b.title LIKE ? OR a.pen_name LIKE ? OR b.book_code LIKE ?)';
            $like = '%' . $keyword . '%';
            array_push($params, $like, $like, $like);
        }
        $allowedStatuses = ['draft', 'reviewing', 'rejected', 'approved', 'serializing', 'paused', 'finished', 'offline'];
        if (in_array($status, $allowedStatuses, true)) {
            $where[] = 'b.status = ?';
            $params[] = $status;
        } else {
            // 默认不展示回收站内的作品，删除后统一到回收站处理
            $where[] = "b.status <> 'deleted'";
        }
        $whereSql = implode(' AND ', $where);

        $total = (int) Database::value(
            "SELECT COUNT(*) FROM books b JOIN authors a ON a.id = b.author_id WHERE {$whereSql}",
            $params
        );
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/admin/books'), ['q' => $keyword, 'status' => $status, 'page' => null]);
        $rows = Database::all(
            "SELECT b.*, a.pen_name, COALESCE(NULLIF(a.avatar, ''), p.avatar) AS author_avatar, c.name AS category_name
             FROM books b JOIN authors a ON a.id = b.author_id LEFT JOIN user_profiles p ON p.user_id = a.user_id
             LEFT JOIN book_categories c ON c.id = b.category_id
             WHERE {$whereSql} ORDER BY b.updated_at DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );

        $this->adminView('books', compact('rows', 'pager', 'keyword', 'status'));
    }

    public function bookAction(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.books');
        $book = Database::one('SELECT * FROM books WHERE id = ?', [(int) $id]);
        if (!$book) {
            abort(404, '作品不存在。');
        }
        $action = Request::str('action', '', 20);
        $reason = Request::str('reason', '', 255);
        $now = date('Y-m-d H:i:s');

        if ($action === 'offline') {
            Database::update('books', ['status' => 'offline', 'updated_at' => $now], ['id' => (int) $book['id']]);
            Database::insert('book_reviews', [
                'book_id' => (int) $book['id'],
                'reviewer_id' => Auth::id(),
                'action' => 'offline',
                'reason' => $reason === '' ? '运营下架' : $reason,
                'created_at' => $now,
            ]);
            Logger::admin('books', '下架作品', '《' . $book['title'] . '》原因：' . $reason, 'book', (int) $book['id']);
            Flash::add('success', '作品已下架，前台目录与阅读入口立即关闭。');
        } elseif ($action === 'restore') {
            $newStatus = $book['published_at'] ? 'serializing' : 'draft';
            Database::update('books', ['status' => $newStatus, 'updated_at' => $now], ['id' => (int) $book['id']]);
            Database::insert('book_reviews', [
                'book_id' => (int) $book['id'],
                'reviewer_id' => Auth::id(),
                'action' => 'restore',
                'reason' => $reason === '' ? '恢复上架' : $reason,
                'created_at' => $now,
            ]);
            Logger::admin('books', '恢复作品', '《' . $book['title'] . '》恢复为 ' . $newStatus, 'book', (int) $book['id']);
            Flash::add('success', '作品已恢复。');
        } elseif ($action === 'feature_on' || $action === 'feature_off') {
            Database::update('books', ['is_featured' => $action === 'feature_on' ? 1 : 0, 'updated_at' => $now], ['id' => (int) $book['id']]);
            Logger::admin('books', '编辑推荐位', '《' . $book['title'] . '》' . ($action === 'feature_on' ? '加入' : '移出') . '推荐', 'book', (int) $book['id']);
            Flash::add('success', '推荐标识已更新。');
        } elseif ($action === 'delete') {
            if ((string) $book['status'] === 'deleted') {
                Flash::add('error', '该作品已在回收站中，请到回收站恢复或彻底删除。');
                redirect('/admin/recycle');
            }
            Database::transaction(function () use ($book, $now, $reason): void {
                Database::update('books', ['status' => 'deleted', 'updated_at' => $now], ['id' => (int) $book['id']]);
                Database::insert('recycle_items', [
                    'target_type' => 'book',
                    'target_id' => (int) $book['id'],
                    'title' => $book['title'],
                    'owner_id' => Auth::id(),
                    'deleted_by' => Auth::id(),
                    'deleted_at' => $now,
                    'restore_deadline' => date('Y-m-d H:i:s', time() + 30 * 86400),
                    'reason' => $reason === '' ? '后台删除作品' : $reason,
                    'restored_at' => null,
                ]);
                Database::query('DELETE FROM recommendations WHERE book_id = ?', [(int) $book['id']]);
                Database::query(
                    "UPDATE review_tasks SET status = 'handled', handled_at = ?
                     WHERE status IN ('waiting','assigned')
                       AND ((target_type = 'book' AND target_id = ?)
                            OR (target_type = 'chapter' AND target_id IN (SELECT id FROM chapters WHERE book_id = ?)))",
                    [$now, (int) $book['id'], (int) $book['id']]
                );
            });
            Logger::admin('books', '删除作品', '《' . $book['title'] . '》移入回收站，原因：' . ($reason === '' ? '后台删除作品' : $reason), 'book', (int) $book['id']);
            Flash::add('success', '作品已移入回收站，可在回收站恢复或彻底删除。');
            redirect('/admin/books');
        }
        redirect('/admin/books?status=' . Request::str('status', 'all', 20));
    }

    public function chapters(): void
    {
        Auth::requirePermission('admin.books');
        $bookId = Request::int('book_id');
        $status = Request::str('status', 'all', 20);
        $keyword = Request::str('q', '', 60);
        $page = max(1, Request::int('page', 1));
        $perPage = 25;

        $where = ['1 = 1'];
        $params = [];
        // 已删除作品的章节不再出现在章节管理中
        $where[] = "b.status <> 'deleted'";
        if ($bookId > 0) {
            $where[] = 'c.book_id = ?';
            $params[] = $bookId;
        }
        if (in_array($status, ['draft', 'pending', 'published', 'scheduled', 'rejected', 'hidden', 'offline'], true)) {
            $where[] = 'c.status = ?';
            $params[] = $status;
        } else {
            // 默认不展示回收站章节，避免已删除章节仍在管理中可见
            $where[] = "c.status <> 'recycle'";
        }
        if ($keyword !== '') {
            $where[] = 'c.title LIKE ?';
            $params[] = '%' . $keyword . '%';
        }
        $whereSql = implode(' AND ', $where);
        $total = (int) Database::value("SELECT COUNT(*) FROM chapters c JOIN books b ON b.id = c.book_id WHERE {$whereSql}", $params);
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/admin/chapters'), ['book_id' => $bookId ?: null, 'status' => $status, 'q' => $keyword, 'page' => null]);
        $rows = Database::all(
            "SELECT c.*, b.title AS book_title, a.pen_name, COALESCE(NULLIF(a.avatar, ''), p.avatar) AS author_avatar
             FROM chapters c JOIN books b ON b.id = c.book_id JOIN authors a ON a.id = b.author_id
             LEFT JOIN user_profiles p ON p.user_id = a.user_id
             WHERE {$whereSql} ORDER BY c.id DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );

        $this->adminView('chapters', compact('rows', 'pager', 'bookId', 'status', 'keyword'));
    }

    public function chapterAction(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.books');
        $chapter = Database::one(
            'SELECT c.*, b.title AS book_title FROM chapters c JOIN books b ON b.id = c.book_id WHERE c.id = ? AND b.status <> \'deleted\'',
            [(int) $id]
        );
        if (!$chapter) {
            abort(404, '章节不存在。');
        }
        $action = Request::str('action', '', 20);
        if ($action === 'hide') {
            Database::update('chapters', ['status' => 'hidden', 'updated_at' => date('Y-m-d H:i:s')], ['id' => (int) $chapter['id']]);
            Logger::admin('chapters', '隐藏章节', '《' . $chapter['book_title'] . '》' . $chapter['title'], 'chapter', (int) $chapter['id']);
            Flash::add('success', '章节已隐藏。');
        } elseif ($action === 'offline') {
            Database::update('chapters', ['status' => 'offline', 'updated_at' => date('Y-m-d H:i:s')], ['id' => (int) $chapter['id']]);
            Logger::admin('chapters', '下架章节', '《' . $chapter['book_title'] . '》' . $chapter['title'], 'chapter', (int) $chapter['id']);
            Flash::add('success', '章节已下架。');
        } elseif ($action === 'restore') {
            $hasContent = Database::one('SELECT id FROM chapter_contents WHERE chapter_id = ? LIMIT 1', [(int) $chapter['id']]);
            $newStatus = $hasContent ? 'published' : 'draft';
            Database::update('chapters', ['status' => $newStatus, 'updated_at' => date('Y-m-d H:i:s')], ['id' => (int) $chapter['id']]);
            Logger::admin('chapters', '恢复章节', '《' . $chapter['book_title'] . '》' . $chapter['title'] . ' → ' . $newStatus, 'chapter', (int) $chapter['id']);
            Flash::add('success', '章节已恢复。');
        } elseif ($action === 'delete') {
            if ((string) $chapter['status'] === 'recycle') {
                Flash::add('error', '该章节已在回收站中。');
                redirect('/admin/chapters');
            }
            $now = date('Y-m-d H:i:s');
            $originalNo = (int) $chapter['chapter_no'];
            Database::transaction(function () use ($chapter, $now, $originalNo): void {
                RecycleService::parkChapter((int) $chapter['id']);
                Database::update('chapters', ['status' => 'recycle', 'updated_at' => $now], ['id' => (int) $chapter['id']]);
                Database::insert('recycle_items', [
                    'target_type' => 'chapter',
                    'target_id' => (int) $chapter['id'],
                    'title' => mb_substr($chapter['book_title'] . ' · ' . $chapter['title'], 0, 120, 'UTF-8'),
                    'owner_id' => Auth::id(),
                    'deleted_by' => Auth::id(),
                    'deleted_at' => $now,
                    'restore_deadline' => date('Y-m-d H:i:s', time() + 30 * 86400),
                    'reason' => '后台删除章节（原序 ' . $originalNo . '）',
                    'restored_at' => null,
                ]);
                Database::query(
                    "UPDATE review_tasks SET status = 'handled', handled_at = ?
                     WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned')",
                    [$now, (int) $chapter['id']]
                );
                // 剩余章节依次前移，编号保持连续
                RecycleService::resequenceChapters((int) $chapter['book_id']);
            });
            Logger::admin('chapters', '删除章节', '《' . $chapter['book_title'] . '》' . $chapter['title'] . ' 移入回收站', 'chapter', (int) $chapter['id']);
            Flash::add('success', '章节已移入回收站。');
            redirect('/admin/chapters');
        }
        redirect('/admin/chapters?status=' . Request::str('status', 'all', 20));
    }

    public function reviews(): void
    {
        Auth::requirePermission('admin.review');
        $tab = Request::str('tab', 'book', 20);
        if (!in_array($tab, ['book', 'chapter', 'author'], true)) {
            $tab = 'book';
        }

        $bookTasks = Database::all(
            "SELECT rt.*, b.title, b.cover, b.status AS book_status, b.summary, a.pen_name, COALESCE(NULLIF(a.avatar, ''), p.avatar) AS author_avatar
             FROM review_tasks rt JOIN books b ON b.id = rt.target_id JOIN authors a ON a.id = b.author_id
             LEFT JOIN user_profiles p ON p.user_id = a.user_id
             WHERE rt.target_type = 'book' AND rt.status IN ('waiting','assigned') AND b.status <> 'deleted'
             ORDER BY rt.priority ASC, rt.created_at ASC LIMIT 30"
        );
        $chapterTasks = Database::all(
            "SELECT rt.*, c.title, c.status AS chapter_status, b.title AS book_title, b.id AS book_id, b.cover AS book_cover, a.pen_name, COALESCE(NULLIF(a.avatar, ''), p.avatar) AS author_avatar
             FROM review_tasks rt JOIN chapters c ON c.id = rt.target_id JOIN books b ON b.id = c.book_id JOIN authors a ON a.id = b.author_id
             LEFT JOIN user_profiles p ON p.user_id = a.user_id
             WHERE rt.target_type = 'chapter' AND rt.status IN ('waiting','assigned') AND b.status <> 'deleted'
             ORDER BY rt.priority ASC, rt.created_at ASC LIMIT 30"
        );
        $authorTasks = Database::all(
            "SELECT rt.*, aa.pen_name, aa.real_name, aa.status AS application_status, aa.user_id, p.avatar
             FROM review_tasks rt JOIN author_applications aa ON aa.id = rt.target_id
             LEFT JOIN user_profiles p ON p.user_id = aa.user_id
             WHERE rt.target_type = 'author' AND rt.status IN ('waiting','assigned')
             ORDER BY rt.created_at ASC LIMIT 30"
        );

        $this->adminView('reviews', compact('tab', 'bookTasks', 'chapterTasks', 'authorTasks'));
    }

    public function reviewDetail(string $type, string $id): void
    {
        Auth::requirePermission('admin.review');
        $entityId = (int) $id;
        if ($type === 'book') {
            $book = Database::one(
                'SELECT b.*, a.pen_name, COALESCE(NULLIF(a.avatar, \'\'), p.avatar) AS author_avatar, a.user_id AS author_user_id, c.name AS category_name
                 FROM books b JOIN authors a ON a.id = b.author_id LEFT JOIN user_profiles p ON p.user_id = a.user_id
                 LEFT JOIN book_categories c ON c.id = b.category_id
                 WHERE b.id = ? AND b.status <> \'deleted\'',
                [$entityId]
            );
            if (!$book) {
                abort(404, '作品不存在。');
            }
            $chapters = Database::all('SELECT id, title, status, word_count, created_at FROM chapters WHERE book_id = ? ORDER BY chapter_no ASC LIMIT 30', [$entityId]);
            $reviews = Database::all(
                'SELECT br.*, p.nickname FROM book_reviews br LEFT JOIN user_profiles p ON p.user_id = br.reviewer_id WHERE br.book_id = ? ORDER BY br.id DESC LIMIT 20',
                [$entityId]
            );
            $identity = Database::one('SELECT real_name, id_no, status FROM user_identities WHERE user_id = ?', [(int) $book['author_user_id']]);
            $this->adminView('review_detail', [
                'type' => 'book',
                'entity' => $book,
                'chapters' => $chapters,
                'reviews' => $reviews,
                'identity' => $identity,
                'content' => $book['summary'],
                'task' => null,
            ]);
            return;
        }

        if ($type === 'chapter') {
            $chapter = Database::one(
                'SELECT c.*, b.title AS book_title, b.status AS book_status, a.pen_name, COALESCE(NULLIF(a.avatar, \'\'), p.avatar) AS author_avatar, a.user_id AS author_user_id
                 FROM chapters c JOIN books b ON b.id = c.book_id JOIN authors a ON a.id = b.author_id
                 LEFT JOIN user_profiles p ON p.user_id = a.user_id
                 WHERE c.id = ? AND b.status <> \'deleted\'',
                [$entityId]
            );
            if (!$chapter) {
                abort(404, '章节不存在。');
            }
            $task = Database::one(
                "SELECT * FROM review_tasks WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned') ORDER BY id DESC LIMIT 1",
                [$entityId]
            );
            $versionNo = $task ? (int) $task['version_no'] : 0;
            $version = $versionNo > 0
                ? Database::one('SELECT * FROM chapter_versions WHERE chapter_id = ? AND version_no = ?', [$entityId, $versionNo])
                : null;
            $content = $version ? (string) $version['content'] : '';
            $versions = Database::all(
                'SELECT version_no, kind, word_count, created_at FROM chapter_versions WHERE chapter_id = ? ORDER BY version_no DESC LIMIT 12',
                [$entityId]
            );
            $reviews = Database::all(
                'SELECT cr.*, p.nickname FROM chapter_reviews cr LEFT JOIN user_profiles p ON p.user_id = cr.reviewer_id WHERE cr.chapter_id = ? ORDER BY cr.id DESC LIMIT 20',
                [$entityId]
            );
            $this->adminView('review_detail', [
                'type' => 'chapter',
                'entity' => $chapter,
                'versions' => $versions,
                'reviews' => $reviews,
                'identity' => null,
                'content' => $content,
                'task' => $task,
                'versionNo' => $versionNo,
            ]);
            return;
        }

        abort(404, '未知审核对象。');
    }

    public function reviewAct(string $type, string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.review.handle');
        $entityId = (int) $id;
        $action = Request::str('action', '', 20);
        $reason = Request::str('reason', '', 255);
        $note = Request::str('note', '', 500);

        if ($type === 'book') {
            if ($action === 'approve') {
                $result = ReviewService::approveBook($entityId, Auth::id(), $note);
            } else {
                if ($reason === '') {
                    Flash::add('error', '驳回必须填写可理解的原因。');
                    redirect('/admin/review/book/' . $entityId);
                }
                $result = ReviewService::rejectBook($entityId, Auth::id(), $reason);
            }
            Logger::admin('review', ($action === 'approve' ? '通过' : '驳回') . '作品', $reason, 'book', $entityId);
            Flash::add(($result['ok'] ?? false) ? 'success' : 'error', (string) $result['message']);
            redirect('/admin/reviews?tab=book');
        }

        if ($type === 'chapter') {
            if ($action === 'approve') {
                $result = ReviewService::approveChapter($entityId, Auth::id(), 'approve', $note);
            } else {
                if ($reason === '') {
                    Flash::add('error', '驳回必须填写可理解的原因。');
                    redirect('/admin/review/chapter/' . $entityId);
                }
                $result = ReviewService::rejectChapter($entityId, Auth::id(), $reason);
            }
            Logger::admin('review', ($action === 'approve' ? '通过' : '驳回') . '章节', $reason, 'chapter', $entityId);
            Flash::add(($result['ok'] ?? false) ? 'success' : 'error', (string) $result['message']);
            redirect('/admin/reviews?tab=chapter');
        }

        abort(404, '未知审核对象。');
    }

    public function comments(): void
    {
        Auth::requirePermission('admin.comments');
        $status = Request::str('status', 'all', 20);
        $keyword = Request::str('q', '', 60);
        $page = max(1, Request::int('page', 1));
        $perPage = 25;

        $where = ['b.status <> \'deleted\''];
        $params = [];
        if (in_array($status, ['waiting', 'approved', 'hidden', 'deleted'], true)) {
            $where[] = 'cm.status = ?';
            $params[] = $status;
        } else {
            // 默认不展示已删除评论，删除后进入回收站
            $where[] = "cm.status <> 'deleted'";
        }
        if ($keyword !== '') {
            $where[] = '(cm.content LIKE ? OR b.title LIKE ?)';
            array_push($params, '%' . $keyword . '%', '%' . $keyword . '%');
        }
        $whereSql = implode(' AND ', $where);
        $total = (int) Database::value("SELECT COUNT(*) FROM comments cm JOIN books b ON b.id = cm.book_id WHERE {$whereSql}", $params);
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/admin/comments'), ['status' => $status, 'q' => $keyword, 'page' => null]);
        $rows = Database::all(
            "SELECT cm.*, b.title AS book_title, p.nickname, p.avatar FROM comments cm JOIN books b ON b.id = cm.book_id
             LEFT JOIN user_profiles p ON p.user_id = cm.user_id
             WHERE {$whereSql} ORDER BY cm.id DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );
        $this->adminView('comments', compact('rows', 'pager', 'status', 'keyword'));
    }

    public function commentAction(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.comments');
        $comment = Database::one('SELECT * FROM comments WHERE id = ?', [(int) $id]);
        if (!$comment) {
            abort(404, '评论不存在。');
        }
        $status = Request::str('status', '', 20);
        if (!in_array($status, ['approved', 'hidden', 'deleted'], true)) {
            Flash::add('error', '评论状态无效。');
            redirect('/admin/comments');
        }
        Database::update('comments', ['status' => $status], ['id' => (int) $comment['id']]);
        $openRecycle = Database::one(
            "SELECT id FROM recycle_items WHERE target_type = 'comment' AND target_id = ? AND restored_at IS NULL",
            [(int) $comment['id']]
        );
        if ($status === 'deleted' && !$openRecycle) {
            Database::insert('recycle_items', [
                'target_type' => 'comment',
                'target_id' => (int) $comment['id'],
                'title' => mb_substr((string) $comment['content'], 0, 120, 'UTF-8'),
                'owner_id' => (int) $comment['user_id'],
                'deleted_by' => Auth::id(),
                'deleted_at' => date('Y-m-d H:i:s'),
                'restore_deadline' => date('Y-m-d H:i:s', time() + 30 * 86400),
                'reason' => '后台删除评论',
                'restored_at' => null,
            ]);
        } elseif ($status !== 'deleted' && $openRecycle) {
            Database::update('recycle_items', ['restored_at' => date('Y-m-d H:i:s')], ['id' => (int) $openRecycle['id']]);
        }
        Logger::admin('comments', '评论处置', '评论 #' . $comment['id'] . ' → ' . status_label($status), 'comment', (int) $comment['id']);
        Flash::add('success', '评论状态已更新。');
        redirect('/admin/comments?status=' . Request::str('status_filter', 'all', 20));
    }
}
