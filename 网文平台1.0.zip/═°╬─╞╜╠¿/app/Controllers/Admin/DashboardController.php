<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Core\Auth;
use App\Core\Database;
use App\Services\AccountPurgeService;

class DashboardController extends BaseController
{
    public function index(): void
    {
        Auth::requirePermission('admin.dashboard');

        // 顺带清理已满 5 天冷静期的注销账号
        AccountPurgeService::purgeDue();

        $publicStatuses = "'approved','serializing','paused','finished'";
        $counts = [
            'users' => (int) Database::value("SELECT COUNT(*) FROM users WHERE status <> 'deleted'"),
            'books' => (int) Database::value("SELECT COUNT(*) FROM books WHERE status <> 'deleted'"),
            'online_books' => (int) Database::value("SELECT COUNT(*) FROM books WHERE status IN ({$publicStatuses})"),
            'chapters' => (int) Database::value("SELECT COUNT(*) FROM chapters c JOIN books b ON b.id = c.book_id WHERE b.status <> 'deleted' AND c.status <> 'recycle'"),
            'review_tasks' => (int) Database::value(
                "SELECT COUNT(*) FROM review_tasks rt WHERE rt.status IN ('waiting','assigned')
                 AND NOT EXISTS (SELECT 1 FROM books b WHERE rt.target_type = 'book' AND b.id = rt.target_id AND b.status = 'deleted')
                 AND NOT EXISTS (SELECT 1 FROM chapters c JOIN books b2 ON b2.id = c.book_id WHERE rt.target_type = 'chapter' AND c.id = rt.target_id AND b2.status = 'deleted')"
            ),
            'reports' => (int) Database::value("SELECT COUNT(*) FROM reports WHERE status IN ('received','reviewing')"),
            'author_applications' => (int) Database::value("SELECT COUNT(*) FROM author_applications WHERE status = 'pending'"),
            'comments_waiting' => (int) Database::value("SELECT COUNT(*) FROM comments cm JOIN books b ON b.id = cm.book_id WHERE cm.status = 'waiting' AND b.status <> 'deleted'"),
        ];

        $tasks = Database::all(
            "SELECT rt.*, b.title AS book_title, c.title AS chapter_title, a.pen_name
             FROM review_tasks rt
             LEFT JOIN books b ON rt.target_type = 'book' AND b.id = rt.target_id
             LEFT JOIN chapters c ON rt.target_type = 'chapter' AND c.id = rt.target_id
             LEFT JOIN authors a ON a.id = b.author_id
             WHERE rt.status IN ('waiting','assigned')
               AND NOT EXISTS (SELECT 1 FROM books b2 WHERE rt.target_type = 'book' AND b2.id = rt.target_id AND b2.status = 'deleted')
               AND NOT EXISTS (SELECT 1 FROM chapters c2 JOIN books b3 ON b3.id = c2.book_id WHERE rt.target_type = 'chapter' AND c2.id = rt.target_id AND b3.status = 'deleted')
             ORDER BY rt.priority ASC, rt.created_at ASC LIMIT 8"
        );

        $reports = Database::all(
            "SELECT r.*, p.nickname AS reporter_name FROM reports r
             LEFT JOIN user_profiles p ON p.user_id = r.reporter_id
             WHERE r.status IN ('received','reviewing') ORDER BY r.id DESC LIMIT 5"
        );

        $logs = Database::all(
            "SELECT l.*, p.nickname FROM admin_logs l LEFT JOIN user_profiles p ON p.user_id = l.admin_id ORDER BY l.id DESC LIMIT 6"
        );

        $trend = [];
        for ($i = 6; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime('-' . $i . ' days'));
            $trend[] = [
                'date' => $date,
                'users' => (int) Database::value('SELECT COUNT(*) FROM users WHERE DATE(created_at) = ?', [$date]),
                'reports' => (int) Database::value('SELECT COUNT(*) FROM reports WHERE DATE(created_at) = ?', [$date]),
            ];
        }

        $switches = Database::all('SELECT * FROM switches ORDER BY grp ASC, id ASC');
        $maxTrend = 1;
        foreach ($trend as $row) {
            $maxTrend = max($maxTrend, $row['users'], $row['reports']);
        }

        $this->adminView('dashboard', compact('counts', 'tasks', 'reports', 'logs', 'trend', 'switches', 'maxTrend'));
    }
}
