<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Logger;
use App\Core\Request;
use App\Services\AccountPurgeService;
use App\Services\UploadService;

class UserController extends BaseController
{
    public function index(): void
    {
        Auth::requirePermission('admin.users');
        AccountPurgeService::purgeDue();
        $keyword = Request::str('q', '', 60);
        $status = Request::str('status', 'all', 20);
        $page = max(1, Request::int('page', 1));
        $perPage = 20;

        $where = ['1 = 1'];
        $params = [];
        if ($keyword !== '') {
            $where[] = '(u.login_name LIKE ? OR u.phone LIKE ? OR u.email LIKE ? OR p.nickname LIKE ?)';
            $like = '%' . $keyword . '%';
            array_push($params, $like, $like, $like, $like);
        }
        if ($status !== 'all' && in_array($status, ['active', 'limited', 'locked', 'risk', 'deleting', 'inactive'], true)) {
            $where[] = 'u.status = ?';
            $params[] = $status;
        }
        $whereSql = implode(' AND ', $where);

        $primaryAdminId = $this->primaryAdminId();

        $total = (int) Database::value(
            "SELECT COUNT(*) FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE {$whereSql}",
            $params
        );
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/admin/users'), ['q' => $keyword, 'status' => $status, 'page' => null]);

        $rows = Database::all(
            "SELECT u.*, p.nickname, p.avatar,
             (SELECT GROUP_CONCAT(r.name ORDER BY r.id SEPARATOR ' / ') FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id) AS role_names,
             (SELECT COUNT(*) FROM user_roles ur2 JOIN roles r2 ON r2.id = ur2.role_id WHERE ur2.user_id = u.id AND r2.code = 'admin') AS is_admin
             FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id
             WHERE {$whereSql}
             ORDER BY u.id DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );

        $this->adminView('users', compact('rows', 'pager', 'keyword', 'status', 'primaryAdminId'));
    }

    /**
     * 手动清理已满冷静期的注销账号（页面访问时也会自动触发）。
     */
    public function purgeCancelled(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.users.manage');
        $result = AccountPurgeService::purgeDue();
        Logger::admin('users', '清理到期注销账号', '删除账号 ' . $result['users'] . ' 个，关联作品 ' . $result['books'] . ' 部');
        if ($result['users'] > 0) {
            Flash::add('success', '已清理 ' . $result['users'] . ' 个到期注销账号，相关作品、评论与文件已删除。');
        } else {
            Flash::add('info', '当前没有已满 5 天冷静期的注销账号。');
        }
        redirect('/admin/users');
    }

    public function show(string $id): void
    {
        Auth::requirePermission('admin.users');
        $userId = (int) $id;
        $user = Database::one(
            'SELECT u.*, p.nickname, p.avatar, p.bio, p.city, p.gender
             FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE u.id = ?',
            [$userId]
        );
        if (!$user) {
            abort(404, '用户不存在。');
        }
        $roles = Database::all('SELECT * FROM roles ORDER BY id ASC');
        $userRoles = array_map(
            static fn ($row) => (int) $row['role_id'],
            Database::all('SELECT role_id FROM user_roles WHERE user_id = ?', [$userId])
        );
        $author = Database::one('SELECT * FROM authors WHERE user_id = ?', [$userId]);
        $application = Database::one('SELECT * FROM author_applications WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$userId]);
        $identity = Database::one('SELECT * FROM user_identities WHERE user_id = ?', [$userId]);
        $books = $author
            ? Database::all("SELECT * FROM books WHERE author_id = ? AND status <> 'deleted' ORDER BY updated_at DESC LIMIT 10", [(int) $author['id']])
            : [];
        $reports = Database::all(
            'SELECT * FROM reports WHERE reporter_id = ? ORDER BY id DESC LIMIT 10',
            [$userId]
        );
        $logs = Database::all('SELECT * FROM admin_logs WHERE admin_id = ? ORDER BY id DESC LIMIT 10', [$userId]);
        $loginLogs = Database::all('SELECT * FROM login_logs WHERE user_id = ? ORDER BY id DESC LIMIT 10', [$userId]);
        $isAdminTarget = $this->isAdminAccount($userId);
        $primaryAdminId = $this->primaryAdminId();
        $isPrimaryTarget = $userId === $primaryAdminId;
        // 初始站长不可被任何人管理；其他站长角账号仅初始站长可管理
        $canManageTarget = !$isPrimaryTarget && (!$isAdminTarget || Auth::id() === $primaryAdminId);

        $this->adminView('user_detail', compact('user', 'roles', 'userRoles', 'author', 'application', 'identity', 'books', 'reports', 'logs', 'loginLogs', 'isAdminTarget', 'isPrimaryTarget', 'canManageTarget'));
    }

    public function updateStatus(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.users.manage');
        $userId = (int) $id;
        $status = Request::str('status', '', 20);
        $reason = Request::str('reason', '', 255);
        $allowed = ['active', 'limited', 'locked', 'risk', 'deleting'];
        if (!in_array($status, $allowed, true)) {
            Flash::add('error', '状态值无效。');
            redirect('/admin/users/' . $userId);
        }
        if ($userId === Auth::id() && $status !== 'active') {
            Flash::add('error', '不能限制当前登录账号。');
            redirect('/admin/users/' . $userId);
        }
        $user = Database::one('SELECT * FROM users WHERE id = ?', [$userId]);
        if (!$user) {
            abort(404, '用户不存在。');
        }
        $primaryAdminId = $this->primaryAdminId();
        if ($userId === $primaryAdminId) {
            Flash::add('error', '初始站长账号受系统保护，任何账号都不能调整其状态。');
            redirect('/admin/users/' . $userId);
        }
        if ($this->isAdminAccount($userId) && Auth::id() !== $primaryAdminId) {
            Flash::add('error', '该账号拥有站长角色，只有初始站长可以管理。');
            redirect('/admin/users/' . $userId);
        }
        Database::update('users', ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')], ['id' => $userId]);
        Logger::admin('users', '更新用户状态', '用户 ' . $user['login_name'] . ' 状态 ' . $user['status'] . ' → ' . $status . '，原因：' . $reason, 'user', $userId);
        notify_user($userId, '账号状态变更通知', '你的账号状态已调整为：' . status_label($status) . '。' . ($reason !== '' ? '说明：' . $reason : ''));
        Flash::add('success', '用户状态已更新。');
        redirect('/admin/users/' . $userId);
    }

    public function updateRoles(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.roles.manage');
        $userId = (int) $id;
        $user = Database::one('SELECT * FROM users WHERE id = ?', [$userId]);
        if (!$user) {
            abort(404, '用户不存在。');
        }
        if ($this->isAdminAccount($userId)) {
            $primaryAdminId = $this->primaryAdminId();
            if ($userId === $primaryAdminId) {
                Flash::add('error', '初始站长账号受系统保护，任何账号都不能调整其角色。');
                redirect('/admin/users/' . $userId);
            }
            if (Auth::id() !== $primaryAdminId) {
                Flash::add('error', '该账号拥有站长角色，只有初始站长可以管理。');
                redirect('/admin/users/' . $userId);
            }
        }
        $roleIds = array_values(array_unique(array_map('intval', (array) ($_POST['roles'] ?? []))));
        $validRoles = Database::all('SELECT id, code FROM roles');
        $validIds = array_map(static fn ($row) => (int) $row['id'], $validRoles);
        $roleIds = array_values(array_intersect($roleIds, $validIds));
        $roleCodes = [];
        foreach ($validRoles as $row) {
            if (in_array((int) $row['id'], $roleIds, true)) {
                $roleCodes[] = (string) $row['code'];
            }
        }

        if ($userId === Auth::id()) {
            $adminRoleId = (int) Database::value("SELECT id FROM roles WHERE code = 'admin'");
            if (!in_array($adminRoleId, $roleIds, true)) {
                Flash::add('error', '不能移除当前账号的站长角色。');
                redirect('/admin/users/' . $userId);
            }
        }
        if ($roleIds === []) {
            Flash::add('error', '至少保留一个角色。');
            redirect('/admin/users/' . $userId);
        }

        Database::transaction(function () use ($userId, $roleIds, $roleCodes, $user): void {
            Database::query('DELETE FROM user_roles WHERE user_id = ?', [$userId]);
            foreach ($roleIds as $roleId) {
                Database::insert('user_roles', ['user_id' => $userId, 'role_id' => $roleId]);
            }
            // 作家角色与作家档案双向同步：取消角色即撤销作家身份，勾选角色即开通
            $this->syncAuthorIdentity($userId, in_array('author', $roleCodes, true), (string) $user['login_name']);
        });
        Logger::admin('roles', '调整用户角色', '用户 ' . $user['login_name'] . ' 角色更新为 ID：' . implode(',', $roleIds), 'user', $userId);
        Flash::add('success', '用户角色已更新。');
        redirect('/admin/users/' . $userId);
    }

    /** 角色「认证作家」与 authors 档案保持一致，确保前台作家中心按角色生效 */
    private function syncAuthorIdentity(int $userId, bool $hasAuthorRole, string $loginName): void
    {
        $author = Database::one('SELECT * FROM authors WHERE user_id = ? LIMIT 1', [$userId]);

        if (!$hasAuthorRole) {
            if ($author && in_array((string) $author['status'], ['active', 'paused'], true)) {
                Database::update('authors', ['status' => 'revoked'], ['id' => (int) $author['id']]);
                notify_user($userId, '作家权限已取消', '你的作家权限已被站长取消，暂时无法进入作家中心。作品数据保留，如需恢复请联系站长。');
            }
            return;
        }

        if ($author) {
            if ((string) $author['status'] !== 'active') {
                Database::update('authors', ['status' => 'active'], ['id' => (int) $author['id']]);
                notify_user($userId, '作家权限已恢复', '你的作家权限已恢复，可以继续创作与提交审核。');
            }
            return;
        }

        // 没有作家档案时，用登录名生成唯一笔名并直接开通
        $base = mb_substr(trim($loginName) !== '' ? trim($loginName) : '作家', 0, 34, 'UTF-8');
        $penName = $base;
        $index = 1;
        while (Database::one('SELECT id FROM authors WHERE pen_name = ?', [$penName])) {
            $index++;
            $penName = $base . '-' . $index;
        }
        Database::insert('authors', [
            'user_id' => $userId,
            'pen_name' => $penName,
            'avatar' => null,
            'intro' => null,
            'status' => 'active',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        notify_user($userId, '作家权限已开通', '站长已为你开通作家权限，笔名：' . $penName . '。现在可以创建作品并提交审核。');
    }

    public function resetPassword(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.users.manage');
        $userId = (int) $id;
        $user = Database::one('SELECT * FROM users WHERE id = ?', [$userId]);
        if (!$user) {
            abort(404, '用户不存在。');
        }
        $primaryAdminId = $this->primaryAdminId();
        if ($userId === $primaryAdminId) {
            Flash::add('error', '初始站长账号受系统保护，请使用「忘记密码」或本人登录后在账号设置中修改。');
            redirect('/admin/users/' . $userId);
        }
        if ($this->isAdminAccount($userId) && Auth::id() !== $primaryAdminId) {
            Flash::add('error', '该账号拥有站长角色，只有初始站长可以管理。');
            redirect('/admin/users/' . $userId);
        }
        $password = (string) Request::post('password', '');
        $confirm = (string) Request::post('confirm_password', '');
        if (mb_strlen($password, 'UTF-8') < 8) {
            Flash::add('error', '新密码至少 8 个字符。');
            redirect('/admin/users/' . $userId);
        }
        if ($password !== $confirm) {
            Flash::add('error', '两次输入的新密码不一致。');
            redirect('/admin/users/' . $userId);
        }
        Database::update('users', [
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'updated_at' => date('Y-m-d H:i:s'),
        ], ['id' => $userId]);
        Logger::admin('users', '重置用户密码', '用户 ' . $user['login_name'] . ' 密码已重置', 'user', $userId);
        Flash::add('success', '已重置该用户密码，请线下告知本人。');
        redirect('/admin/users/' . $userId);
    }

    /** 删除用户（软删除：禁止登录，保留内容数据） */
    public function destroy(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.users.manage');
        $userId = (int) $id;
        $user = Database::one('SELECT * FROM users WHERE id = ?', [$userId]);
        if (!$user) {
            abort(404, '用户不存在。');
        }
        if ($userId === Auth::id()) {
            Flash::add('error', '不能删除当前登录账号。');
            redirect('/admin/users/' . $userId);
        }
        $primaryAdminId = $this->primaryAdminId();
        if ($userId === $primaryAdminId) {
            Flash::add('error', '初始站长账号受系统保护，不能删除。');
            redirect('/admin/users/' . $userId);
        }
        if ($this->isAdminAccount($userId) && Auth::id() !== $primaryAdminId) {
            Flash::add('error', '该账号拥有站长角色，只有初始站长可以删除。');
            redirect('/admin/users/' . $userId);
        }
        if ((string) $user['status'] === 'deleted') {
            Flash::add('error', '该账号已被删除。');
            redirect('/admin/users/' . $userId);
        }

        $avatar = (string) Database::value('SELECT avatar FROM user_profiles WHERE user_id = ?', [$userId]);
        Database::transaction(function () use ($userId, $user): void {
            Database::update('users', [
                'status' => 'deleted',
                'updated_at' => date('Y-m-d H:i:s'),
            ], ['id' => $userId]);
            Database::update('user_profiles', ['avatar' => null], ['user_id' => $userId]);
            Database::query('DELETE FROM user_roles WHERE user_id = ?', [$userId]);
            Logger::admin('users', '删除用户', '用户 ' . $user['login_name'] . ' 已被删除（软删除）', 'user', $userId);
        });
        if ($avatar !== '') {
            UploadService::delete($avatar);
        }
        Flash::add('success', '用户已删除，该账号立即退出且无法登录；作品与历史数据保留。');
        redirect('/admin/users');
    }

    public function authors(): void
    {
        Auth::requirePermission('admin.authors');
        $status = Request::str('status', 'pending', 20);
        if ($status === 'all') {
            $where = '1 = 1';
            $params = [];
        } elseif (in_array($status, ['pending', 'approved', 'rejected'], true)) {
            $where = 'aa.status = ?';
            $params = [$status];
        } else {
            $status = 'pending';
            $where = 'aa.status = ?';
            $params = ['pending'];
        }
        $rows = Database::all(
            "SELECT aa.*, p.nickname, p.avatar, u.login_name, u.status AS user_status
             FROM author_applications aa
             JOIN users u ON u.id = aa.user_id
             LEFT JOIN user_profiles p ON p.user_id = aa.user_id
             WHERE {$where} ORDER BY aa.id DESC LIMIT 100",
            $params
        );
        $this->adminView('authors', compact('rows', 'status'));
    }

    public function reviewAuthor(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.authors');
        $application = Database::one('SELECT * FROM author_applications WHERE id = ?', [(int) $id]);
        if (!$application || (string) $application['status'] !== 'pending') {
            Flash::add('error', '认证申请不存在或已处理。');
            redirect('/admin/authors');
        }
        $action = Request::str('action', '', 20);
        $remark = Request::str('remark', '', 255);
        $now = date('Y-m-d H:i:s');

        if ($action === 'approve') {
            if (Database::one('SELECT id FROM authors WHERE pen_name = ?', [$application['pen_name']])) {
                Flash::add('error', '笔名已被占用，无法通过。');
                redirect('/admin/authors');
            }
            Database::transaction(function () use ($application, $remark, $now): void {
                $authorId = Database::insert('authors', [
                    'user_id' => (int) $application['user_id'],
                    'pen_name' => $application['pen_name'],
                    'avatar' => null,
                    'intro' => $application['intro'],
                    'status' => 'active',
                    'created_at' => $now,
                ]);
                Database::update('author_applications', [
                    'status' => 'approved',
                    'remark' => $remark === '' ? null : $remark,
                    'reviewed_by' => Auth::id(),
                    'reviewed_at' => $now,
                ], ['id' => (int) $application['id']]);
                Database::update('user_identities', [
                    'status' => 'approved',
                    'remark' => $remark === '' ? null : $remark,
                    'reviewed_by' => Auth::id(),
                    'reviewed_at' => $now,
                ], ['user_id' => (int) $application['user_id']]);
                $roleId = (int) Database::value("SELECT id FROM roles WHERE code = 'author'");
                if ($roleId > 0) {
                    $exists = Database::one('SELECT user_id FROM user_roles WHERE user_id = ? AND role_id = ?', [(int) $application['user_id'], $roleId]);
                    if (!$exists) {
                        Database::insert('user_roles', ['user_id' => (int) $application['user_id'], 'role_id' => $roleId]);
                    }
                }
                Database::query(
                    "UPDATE review_tasks SET status = 'handled', handled_at = ? WHERE target_type = 'author' AND target_id = ?",
                    [$now, (int) $application['id']]
                );
                notify_user((int) $application['user_id'], '作家认证通过', '你的作家认证已通过，笔名：' . $application['pen_name'] . '。现在可以创建作品并提交审核。');
            });
            Logger::admin('authors', '通过作家认证', '申请编号 ' . $application['id'] . '，笔名 ' . $application['pen_name'], 'author_application', (int) $application['id']);
            Flash::add('success', '作家认证已通过。');
            redirect('/admin/authors');
        }

        Database::transaction(function () use ($application, $remark, $now): void {
            Database::update('author_applications', [
                'status' => 'rejected',
                'remark' => $remark === '' ? '材料不完整，请补充后重新提交。' : $remark,
                'reviewed_by' => Auth::id(),
                'reviewed_at' => $now,
            ], ['id' => (int) $application['id']]);
            Database::update('user_identities', [
                'status' => 'rejected',
                'remark' => $remark === '' ? '材料不完整' : $remark,
                'reviewed_by' => Auth::id(),
                'reviewed_at' => $now,
            ], ['user_id' => (int) $application['user_id']]);
            Database::query(
                "UPDATE review_tasks SET status = 'handled', handled_at = ? WHERE target_type = 'author' AND target_id = ?",
                [$now, (int) $application['id']]
            );
            notify_user((int) $application['user_id'], '作家认证未通过', '原因：' . ($remark === '' ? '材料不完整，请补充后重新提交。' : $remark));
        });
        Logger::admin('authors', '驳回作家认证', '申请编号 ' . $application['id'], 'author_application', (int) $application['id']);
        Flash::add('success', '认证申请已驳回。');
        redirect('/admin/authors');
    }

    public function roles(): void
    {
        Auth::requirePermission('admin.roles');
        $roles = Database::all(
            "SELECT r.*, (SELECT COUNT(*) FROM role_permissions rp WHERE rp.role_id = r.id) AS permission_count,
             (SELECT COUNT(*) FROM user_roles ur WHERE ur.role_id = r.id) AS user_count
             FROM roles r ORDER BY r.id ASC"
        );
        $permissions = Database::all('SELECT * FROM permissions ORDER BY module ASC, id ASC');
        $this->adminView('roles', compact('roles', 'permissions'));
    }

    public function roleEdit(string $id): void
    {
        Auth::requirePermission('admin.roles');
        $role = Database::one('SELECT * FROM roles WHERE id = ?', [(int) $id]);
        if (!$role) {
            abort(404, '角色不存在。');
        }
        $permissions = Database::all('SELECT * FROM permissions ORDER BY module ASC, id ASC');
        $selected = array_map(
            static fn ($row) => (int) $row['permission_id'],
            Database::all('SELECT permission_id FROM role_permissions WHERE role_id = ?', [(int) $role['id']])
        );
        $this->adminView('role_edit', compact('role', 'permissions', 'selected'));
    }

    public function roleSave(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.roles.manage');
        $role = Database::one('SELECT * FROM roles WHERE id = ?', [(int) $id]);
        if (!$role) {
            abort(404, '角色不存在。');
        }
        if ((string) $role['code'] === 'admin') {
            Flash::add('error', '站长角色保留全部权限，不允许修改。');
            redirect('/admin/roles/' . (int) $role['id'] . '/edit');
        }
        $permissionIds = array_values(array_unique(array_map('intval', (array) ($_POST['permissions'] ?? []))));
        $validIds = array_map(
            'intval',
            array_column(Database::all('SELECT id FROM permissions'), 'id')
        );
        $permissionIds = array_values(array_intersect($permissionIds, $validIds));

        Database::transaction(function () use ($role, $permissionIds): void {
            Database::query('DELETE FROM role_permissions WHERE role_id = ?', [(int) $role['id']]);
            foreach ($permissionIds as $permissionId) {
                Database::insert('role_permissions', ['role_id' => (int) $role['id'], 'permission_id' => $permissionId]);
            }
        });
        Logger::admin('roles', '更新角色权限', '角色 ' . $role['code'] . ' 权限数量 ' . count($permissionIds), 'role', (int) $role['id']);
        Flash::add('success', '角色权限已更新，相关后台权限缓存将在下次请求生效。');
        redirect('/admin/roles');
    }

    /** 目标账号是否拥有站长角色（受保护账号） */
    private function isAdminAccount(int $userId): bool
    {
        return (int) Database::value(
            "SELECT COUNT(*) FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ? AND r.code = 'admin'",
            [$userId]
        ) > 0;
    }

    /** 初始站长：最早获得站长角色的账号 */
    private function primaryAdminId(): int
    {
        return (int) Database::value(
            "SELECT MIN(ur.user_id) FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE r.code = 'admin'"
        );
    }
}
