<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Logger;
use App\Core\Request;
use App\Services\RankingService;
use App\Services\TaxonomySeeder;

class OperationController extends BaseController
{
    public function reports(): void
    {
        Auth::requirePermission('admin.reports');
        $status = Request::str('status', 'all', 20);
        $category = Request::str('category', 'all', 20);
        $page = max(1, Request::int('page', 1));
        $perPage = 20;

        $where = ['1 = 1'];
        $params = [];
        if (in_array($status, ['received', 'reviewing', 'handled', 'transferred', 'closed'], true)) {
            $where[] = 'r.status = ?';
            $params[] = $status;
        }
        if (in_array($category, ['violation', 'copyright', 'spam', 'minor', 'other'], true)) {
            $where[] = 'r.category = ?';
            $params[] = $category;
        }
        $whereSql = implode(' AND ', $where);
        $total = (int) Database::value("SELECT COUNT(*) FROM reports r WHERE {$whereSql}", $params);
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/admin/reports'), ['status' => $status, 'category' => $category, 'page' => null]);
        $rows = Database::all(
            "SELECT r.*, p.nickname AS reporter_name, p.avatar AS reporter_avatar FROM reports r
             LEFT JOIN user_profiles p ON p.user_id = r.reporter_id
             WHERE {$whereSql} ORDER BY r.id DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );
        $this->adminView('reports', compact('rows', 'pager', 'status', 'category'));
    }

    public function reportDetail(string $id): void
    {
        Auth::requirePermission('admin.reports');
        $report = Database::one('SELECT * FROM reports WHERE id = ?', [(int) $id]);
        if (!$report) {
            abort(404, '举报不存在。');
        }
        $reporter = Database::one(
            'SELECT u.login_name, u.phone, p.nickname, p.avatar FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE u.id = ?',
            [(int) $report['reporter_id']]
        );
        $target = $this->resolveTarget((string) $report['target_type'], (int) $report['target_id']);
        $actions = Database::all(
            'SELECT ra.*, p.nickname FROM report_actions ra LEFT JOIN user_profiles p ON p.user_id = ra.admin_id WHERE ra.report_id = ? ORDER BY ra.id DESC',
            [(int) $report['id']]
        );
        $this->adminView('report_detail', compact('report', 'reporter', 'target', 'actions'));
    }

    public function reportAct(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.reports.handle');
        $report = Database::one('SELECT * FROM reports WHERE id = ?', [(int) $id]);
        if (!$report) {
            abort(404, '举报不存在。');
        }
        $status = Request::str('status', '', 20);
        $result = Request::str('result', '', 255);
        $note = Request::str('note', '', 255);
        if (!in_array($status, ['reviewing', 'handled', 'transferred', 'closed'], true)) {
            Flash::add('error', '处置状态无效。');
            redirect('/admin/reports/' . (int) $report['id']);
        }

        $takeDown = Request::int('take_down') === 1;
        $now = date('Y-m-d H:i:s');

        Database::transaction(function () use ($report, $status, $result, $takeDown, $now, $note): void {
            Database::update('reports', [
                'status' => $status,
                'result' => $result === '' ? null : $result,
                'handled_by' => Auth::id(),
                'handled_at' => in_array($status, ['handled', 'transferred', 'closed'], true) ? $now : null,
            ], ['id' => (int) $report['id']]);

            Database::insert('report_actions', [
                'report_id' => (int) $report['id'],
                'admin_id' => Auth::id(),
                'action' => $status . ($takeDown ? ' + take_down' : ''),
                'note' => mb_substr($note, 0, 255, 'UTF-8'),
                'created_at' => $now,
            ]);

            if ($takeDown) {
                if ((string) $report['target_type'] === 'chapter') {
                    Database::update('chapters', ['status' => 'offline', 'updated_at' => $now], ['id' => (int) $report['target_id']]);
                } elseif (in_array((string) $report['target_type'], ['book', 'cover', 'summary'], true)) {
                    Database::update('books', ['status' => 'offline', 'updated_at' => $now], ['id' => (int) $report['target_id']]);
                } elseif ((string) $report['target_type'] === 'comment') {
                    Database::update('comments', ['status' => 'hidden'], ['id' => (int) $report['target_id']]);
                }
            }

            if ((int) $report['reporter_id'] > 0) {
                notify_user(
                    (int) $report['reporter_id'],
                    '举报处理进度更新',
                    '受理编号 JB' . str_pad((string) $report['id'], 6, '0', STR_PAD_LEFT) . '：' . report_status_label($status) . ($result !== '' ? '，' . $result : '')
                );
            }
        });

        Logger::admin('reports', '处置举报', '举报 #' . $report['id'] . ' → ' . $status . ($takeDown ? '（含限制展示）' : ''), 'report', (int) $report['id']);
        Flash::add('success', '举报处置已记录。');
        redirect('/admin/reports/' . (int) $report['id']);
    }

    private function resolveTarget(string $type, int $id): ?array
    {
        if (in_array($type, ['book', 'cover', 'summary'], true)) {
            $book = Database::one(
                'SELECT b.*, a.pen_name, c.name AS category_name FROM books b JOIN authors a ON a.id = b.author_id LEFT JOIN book_categories c ON c.id = b.category_id WHERE b.id = ?',
                [$id]
            );
            if ($book) {
                $book['preview'] = (string) $book['summary'];
            }
            return $book;
        }
        if ($type === 'chapter') {
            $chapter = Database::one(
                'SELECT c.*, b.title AS book_title, a.pen_name FROM chapters c JOIN books b ON b.id = c.book_id JOIN authors a ON a.id = b.author_id WHERE c.id = ?',
                [$id]
            );
            if ($chapter) {
                $contentRow = Database::one('SELECT content FROM chapter_contents WHERE chapter_id = ? ORDER BY version_no DESC LIMIT 1', [$id]);
                $chapter['preview'] = excerpt($contentRow['content'] ?? '', 400);
            }
            return $chapter;
        }
        if ($type === 'comment') {
            $comment = Database::one(
                'SELECT cm.*, p.nickname, b.title AS book_title FROM comments cm LEFT JOIN user_profiles p ON p.user_id = cm.user_id LEFT JOIN books b ON b.id = cm.book_id WHERE cm.id = ?',
                [$id]
            );
            if ($comment) {
                $comment['preview'] = (string) $comment['content'];
            }
            return $comment;
        }
        if ($type === 'user') {
            return Database::one(
                'SELECT u.id, u.login_name, u.status, p.nickname FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE u.id = ?',
                [$id]
            );
        }
        return null;
    }

    public function taxonomy(): void
    {
        Auth::requirePermission('admin.taxonomy');
        $categories = Database::all(
            "SELECT c.*, (SELECT COUNT(*) FROM books b WHERE b.category_id = c.id AND b.status <> 'deleted') AS book_count,
             (SELECT COUNT(*) FROM book_categories x WHERE x.parent_id = c.id) AS child_count
             FROM book_categories c ORDER BY c.parent_id ASC, c.sort ASC, c.id ASC"
        );
        $tags = Database::all(
            "SELECT t.*, (SELECT COUNT(*) FROM book_tag_map m JOIN books b ON b.id = m.book_id WHERE m.tag_id = t.id AND b.status <> 'deleted') AS book_count
             FROM tags t ORDER BY t.id ASC"
        );
        $parents = Database::all('SELECT * FROM book_categories WHERE parent_id = 0 ORDER BY sort ASC');
        $this->adminView('taxonomy', compact('categories', 'tags', 'parents'));
    }

    public function categorySave(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.taxonomy');
        $id = Request::int('id');
        $name = Request::str('name', '', 40);
        $code = Request::str('code', '', 40);
        $parentId = Request::int('parent_id');
        $sort = Request::int('sort');
        $status = Request::int('status') === 1 ? 1 : 0;
        $description = Request::str('description', '', 255);

        if ($name === '' || !preg_match('/^[a-z0-9_-]{2,40}$/', $code)) {
            Flash::add('error', '分类名称不能为空，编码需为 2-40 位小写字母、数字、下划线或短横线。');
            redirect('/admin/taxonomy');
        }
        $duplicate = Database::one('SELECT id FROM book_categories WHERE code = ? AND id <> ?', [$code, $id]);
        if ($duplicate) {
            Flash::add('error', '分类编码已存在。');
            redirect('/admin/taxonomy');
        }
        if ($id > 0 && $parentId === $id) {
            Flash::add('error', '分类不能以自身作为上级。');
            redirect('/admin/taxonomy');
        }

        if ($id > 0) {
            Database::update('book_categories', [
                'name' => $name,
                'code' => $code,
                'parent_id' => $parentId,
                'sort' => $sort,
                'status' => $status,
                'description' => $description === '' ? null : $description,
            ], ['id' => $id]);
            Logger::admin('taxonomy', '更新分类', $name . '（' . $code . '）', 'category', $id);
            Flash::add('success', '分类已更新，搜索索引与缓存将在下次重建时同步。');
        } else {
            $newId = Database::insert('book_categories', [
                'parent_id' => $parentId,
                'name' => $name,
                'code' => $code,
                'description' => $description === '' ? null : $description,
                'sort' => $sort,
                'status' => $status,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            Logger::admin('taxonomy', '新建分类', $name . '（' . $code . '）', 'category', $newId);
            Flash::add('success', '分类已创建。');
        }
        redirect('/admin/taxonomy');
    }

    public function categoryDelete(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.taxonomy');
        $id = Request::int('id');
        $category = Database::one('SELECT * FROM book_categories WHERE id = ?', [$id]);
        if (!$category) {
            abort(404, '分类不存在。');
        }
        $bookCount = (int) Database::value("SELECT COUNT(*) FROM books WHERE category_id = ? AND status <> 'deleted'", [$id]);
        $childCount = (int) Database::value('SELECT COUNT(*) FROM book_categories WHERE parent_id = ?', [$id]);
        if ($bookCount > 0 || $childCount > 0) {
            Flash::add('error', '分类下仍有作品或子分类，无法删除。');
            redirect('/admin/taxonomy');
        }
        Database::query('DELETE FROM book_categories WHERE id = ?', [$id]);
        Logger::admin('taxonomy', '删除分类', $category['name'], 'category', $id);
        Flash::add('success', '分类已删除。');
        redirect('/admin/taxonomy');
    }

    public function tagSave(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.taxonomy');
        $name = Request::str('name', '', 30);
        $code = Request::str('code', '', 30);
        if ($name === '' || !preg_match('/^[a-z0-9_-]{2,30}$/', $code)) {
            Flash::add('error', '标签名称不能为空，编码需为小写字母、数字、下划线或短横线。');
            redirect('/admin/taxonomy');
        }
        if (Database::one('SELECT id FROM tags WHERE name = ? OR code = ?', [$name, $code])) {
            Flash::add('error', '标签名称或编码已存在。');
            redirect('/admin/taxonomy');
        }
        $id = Database::insert('tags', [
            'name' => $name,
            'code' => $code,
            'status' => 1,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        Logger::admin('taxonomy', '新建标签', $name, 'tag', $id);
        Flash::add('success', '标签已创建。');
        redirect('/admin/taxonomy');
    }

    public function tagDelete(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.taxonomy');
        $id = Request::int('id');
        $tag = Database::one('SELECT * FROM tags WHERE id = ?', [$id]);
        if (!$tag) {
            abort(404, '标签不存在。');
        }
        $used = (int) Database::value('SELECT COUNT(*) FROM book_tag_map WHERE tag_id = ?', [$id]);
        if ($used > 0) {
            Flash::add('error', '标签已被作品引用，无法删除。');
            redirect('/admin/taxonomy');
        }
        Database::query('DELETE FROM tags WHERE id = ?', [$id]);
        Logger::admin('taxonomy', '删除标签', $tag['name'], 'tag', $id);
        Flash::add('success', '标签已删除。');
        redirect('/admin/taxonomy');
    }

    /**
     * 一键补充官方预置分类与标签（幂等，已存在项自动跳过）。
     */
    public function taxonomyPreset(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.taxonomy');
        $result = TaxonomySeeder::run();
        Logger::admin('taxonomy', '补充预置分类标签', '新增分类 ' . $result['categories'] . ' 个，标签 ' . $result['tags'] . ' 个');
        if ($result['categories'] === 0 && $result['tags'] === 0) {
            Flash::add('success', '预置分类与标签已完整，无需补充。');
        } else {
            Flash::add('success', '已补充 ' . $result['categories'] . ' 个分类、' . $result['tags'] . ' 个标签。');
        }
        redirect('/admin/taxonomy');
    }

    public function recommend(): void
    {
        Auth::requirePermission('admin.ops');
        $rows = Database::all(
            "SELECT r.*, b.title, b.cover, b.status AS book_status, a.pen_name
             FROM recommendations r JOIN books b ON b.id = r.book_id JOIN authors a ON a.id = b.author_id
             ORDER BY r.slot ASC, r.weight DESC, r.id DESC"
        );
        $books = Database::all(
            "SELECT b.id, b.title, b.cover, a.pen_name FROM books b JOIN authors a ON a.id = b.author_id
             WHERE b.status IN ('approved','serializing','paused','finished') ORDER BY b.updated_at DESC LIMIT 60"
        );
        $slots = [
            'home_hero' => '首页首屏',
            'home_spotlight' => '编辑精选',
            'category_feature' => '分类精选',
            'home_new' => '新作推荐',
        ];
        $this->adminView('recommend', compact('rows', 'books', 'slots'));
    }

    public function recommendSave(): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.ops');
        $slot = Request::str('slot', 'home_hero', 40);
        $bookId = Request::int('book_id');
        $weight = Request::int('weight');
        $startAt = $this->parseDateTime(Request::str('start_at', '', 30));
        $endAt = $this->parseDateTime(Request::str('end_at', '', 30));
        $book = Database::one("SELECT * FROM books WHERE id = ? AND status IN ('approved','serializing','paused','finished')", [$bookId]);
        if (!$book) {
            Flash::add('error', '请选择已公开的作品。');
            redirect('/admin/recommend');
        }
        $id = Database::insert('recommendations', [
            'slot' => $slot,
            'book_id' => $bookId,
            'weight' => $weight,
            'start_at' => $startAt,
            'end_at' => $endAt,
            'status' => 1,
            'created_by' => Auth::id(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        Logger::admin('ops', '新增推荐位', '《' . $book['title'] . '》→ ' . $slot, 'recommendation', $id);
        Flash::add('success', '推荐位已添加。');
        redirect('/admin/recommend');
    }

    public function recommendToggle(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.ops');
        $row = Database::one('SELECT r.*, b.title FROM recommendations r JOIN books b ON b.id = r.book_id WHERE r.id = ?', [(int) $id]);
        if (!$row) {
            abort(404, '推荐项不存在。');
        }
        $status = (int) $row['status'] === 1 ? 0 : 1;
        Database::update('recommendations', ['status' => $status], ['id' => (int) $row['id']]);
        Logger::admin('ops', '切换推荐状态', '《' . $row['title'] . '》推荐状态 → ' . ($status === 1 ? '上线' : '下线'), 'recommendation', (int) $row['id']);
        Flash::add('success', '推荐状态已更新。');
        redirect('/admin/recommend');
    }

    public function rankings(): void
    {
        Auth::requirePermission('admin.ops');
        $rankings = Database::all('SELECT * FROM rankings ORDER BY id ASC');
        $latest = [];
        foreach ($rankings as $ranking) {
            $date = Database::value('SELECT MAX(period_date) FROM ranking_results WHERE ranking_id = ?', [(int) $ranking['id']]);
            $latest[(int) $ranking['id']] = [
                'date' => $date,
                'count' => $date ? (int) Database::value('SELECT COUNT(*) FROM ranking_results WHERE ranking_id = ? AND period_date = ?', [(int) $ranking['id'], $date]) : 0,
            ];
        }
        $results = RankingService::latestResults((int) ($rankings[0]['id'] ?? 0), 10);
        $this->adminView('rankings', compact('rankings', 'latest', 'results'));
    }

    public function rankingRefresh(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.ops');
        $result = RankingService::refresh((int) $id);
        Logger::admin('ops', '刷新榜单快照', (string) $result['message'], 'ranking', (int) $id);
        Flash::add(($result['ok'] ?? false) ? 'success' : 'error', (string) $result['message']);
        redirect('/admin/rankings');
    }

    public function announcements(): void
    {
        Auth::requirePermission('admin.ops');
        $status = Request::str('status', 'all', 20);
        $where = '1 = 1';
        $params = [];
        if (in_array($status, ['draft', 'published', 'offline'], true)) {
            $where = 'status = ?';
            $params[] = $status;
        }
        $rows = Database::all("SELECT * FROM announcements WHERE {$where} ORDER BY id DESC LIMIT 100", $params);
        $this->adminView('announcements', compact('rows', 'status'));
    }

    public function announcementForm(string $id = '0'): void
    {
        Auth::requirePermission('admin.ops');
        $item = null;
        if ((int) $id > 0) {
            $item = Database::one('SELECT * FROM announcements WHERE id = ?', [(int) $id]);
            if (!$item) {
                abort(404, '公告不存在。');
            }
        }
        $this->adminView('announcement_form', compact('item'));
    }

    public function announcementSave(string $id = '0'): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.ops');
        $title = Request::str('title', '', 120);
        $summary = Request::str('summary', '', 255);
        $content = Request::str('content', '', 10000);
        $scope = Request::str('scope', 'site', 20);
        $status = Request::str('status', 'draft', 20);
        $startAt = $this->parseDateTime(Request::str('start_at', '', 30));
        $endAt = $this->parseDateTime(Request::str('end_at', '', 30));

        if ($title === '') {
            Flash::add('error', '公告标题不能为空。');
            redirect('/admin/announcements/create');
        }
        if (!in_array($scope, ['site', 'author', 'admin'], true)) {
            $scope = 'site';
        }
        if (!in_array($status, ['draft', 'published', 'offline'], true)) {
            $status = 'draft';
        }
        $now = date('Y-m-d H:i:s');
        if ((int) $id > 0) {
            Database::update('announcements', [
                'title' => $title,
                'summary' => $summary === '' ? null : $summary,
                'content' => $content,
                'scope' => $scope,
                'status' => $status,
                'start_at' => $startAt,
                'end_at' => $endAt,
                'updated_at' => $now,
            ], ['id' => (int) $id]);
            Logger::admin('ops', '更新公告', $title, 'announcement', (int) $id);
            Flash::add('success', '公告已更新。');
        } else {
            $newId = Database::insert('announcements', [
                'title' => $title,
                'summary' => $summary === '' ? null : $summary,
                'content' => $content,
                'scope' => $scope,
                'status' => $status,
                'start_at' => $startAt,
                'end_at' => $endAt,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            Logger::admin('ops', '新建公告', $title, 'announcement', $newId);
            Flash::add('success', '公告已创建。');
        }
        redirect('/admin/announcements');
    }

    public function announcementStatus(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.ops');
        $item = Database::one('SELECT * FROM announcements WHERE id = ?', [(int) $id]);
        if (!$item) {
            abort(404, '公告不存在。');
        }
        $status = Request::str('status', 'published', 20);
        if (!in_array($status, ['draft', 'published', 'offline'], true)) {
            $status = 'draft';
        }
        Database::update('announcements', ['status' => $status, 'updated_at' => date('Y-m-d H:i:s')], ['id' => (int) $item['id']]);
        Logger::admin('ops', '公告状态变更', $item['title'] . ' → ' . $status, 'announcement', (int) $item['id']);
        Flash::add('success', '公告状态已更新。');
        redirect('/admin/announcements');
    }

    public function activities(): void
    {
        Auth::requirePermission('admin.ops');
        $status = Request::str('status', 'all', 20);
        $where = '1 = 1';
        $params = [];
        if (in_array($status, ['draft', 'published', 'offline'], true)) {
            $where = 'status = ?';
            $params[] = $status;
        }
        $rows = Database::all("SELECT * FROM activities WHERE {$where} ORDER BY id DESC LIMIT 100", $params);
        $this->adminView('activities', compact('rows', 'status'));
    }

    public function activityForm(string $id = '0'): void
    {
        Auth::requirePermission('admin.ops');
        $item = null;
        if ((int) $id > 0) {
            $item = Database::one('SELECT * FROM activities WHERE id = ?', [(int) $id]);
            if (!$item) {
                abort(404, '活动不存在。');
            }
        }
        $this->adminView('activity_form', compact('item'));
    }

    public function activitySave(string $id = '0'): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.ops');
        $title = Request::str('title', '', 120);
        $summary = Request::str('summary', '', 255);
        $content = Request::str('content', '', 10000);
        $cover = Request::str('cover', '', 255);
        $status = Request::str('status', 'draft', 20);
        $startAt = $this->parseDateTime(Request::str('start_at', '', 30));
        $endAt = $this->parseDateTime(Request::str('end_at', '', 30));
        if ($title === '') {
            Flash::add('error', '活动标题不能为空。');
            redirect('/admin/activities/create');
        }
        if (!in_array($status, ['draft', 'published', 'offline'], true)) {
            $status = 'draft';
        }
        if ((int) $id > 0) {
            Database::update('activities', [
                'title' => $title,
                'summary' => $summary === '' ? null : $summary,
                'content' => $content,
                'cover' => $cover === '' ? null : $cover,
                'start_at' => $startAt,
                'end_at' => $endAt,
                'status' => $status,
            ], ['id' => (int) $id]);
            Logger::admin('ops', '更新活动', $title, 'activity', (int) $id);
            Flash::add('success', '活动已更新。');
        } else {
            $newId = Database::insert('activities', [
                'title' => $title,
                'summary' => $summary === '' ? null : $summary,
                'content' => $content,
                'cover' => $cover === '' ? null : $cover,
                'start_at' => $startAt,
                'end_at' => $endAt,
                'status' => $status,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            Logger::admin('ops', '新建活动', $title, 'activity', $newId);
            Flash::add('success', '活动已创建。');
        }
        redirect('/admin/activities');
    }

    public function activityStatus(string $id): void
    {
        $this->requirePost();
        Auth::requirePermission('admin.ops');
        $item = Database::one('SELECT * FROM activities WHERE id = ?', [(int) $id]);
        if (!$item) {
            abort(404, '活动不存在。');
        }
        $status = Request::str('status', 'published', 20);
        if (!in_array($status, ['draft', 'published', 'offline'], true)) {
            $status = 'draft';
        }
        Database::update('activities', ['status' => $status], ['id' => (int) $item['id']]);
        Logger::admin('ops', '活动状态变更', $item['title'] . ' → ' . $status, 'activity', (int) $item['id']);
        Flash::add('success', '活动状态已更新。');
        redirect('/admin/activities');
    }

    private function parseDateTime(string $value): ?string
    {
        if ($value === '') {
            return null;
        }
        $ts = strtotime(str_replace('T', ' ', $value));
        return $ts === false ? null : date('Y-m-d H:i:s', $ts);
    }
}
