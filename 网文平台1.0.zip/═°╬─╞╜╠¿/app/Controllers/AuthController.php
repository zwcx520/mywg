<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Request;
use App\Core\Switches;

class AuthController extends BaseController
{
    public function showLogin(): void
    {
        if (Auth::check()) {
            redirect(Auth::can('admin.access') ? '/admin' : '/user');
        }
        $next = $this->safeNext();
        $this->view('auth/login', ['next' => $next, 'pageTitle' => '登录'], 'auth');
    }

    public function login(): void
    {
        $this->requirePost();
        $login = Request::str('login', '', 120);
        $password = (string) Request::post('password', '');
        $next = $this->safeNext();

        $failCount = (int) Database::value(
            "SELECT COUNT(*) FROM login_logs WHERE ip = ? AND result = 'fail' AND created_at >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
            [Request::ip()]
        );
        if ($failCount >= 10) {
            Flash::add('error', '尝试次数过多，请稍后再试。');
            redirect('/login');
        }

        if ($login === '' || $password === '') {
            Flash::add('error', '请填写账号与密码。');
            redirect('/login' . ($next !== '' ? '?next=' . urlencode($next) : ''));
        }

        $result = Auth::attempt($login, $password);
        if (!($result['ok'] ?? false)) {
            Flash::add('error', (string) $result['message']);
            redirect('/login' . ($next !== '' ? '?next=' . urlencode($next) : ''));
        }

        $user = Auth::user();
        $target = $next;
        if ($target === '') {
            $target = Auth::can('admin.access') ? '/admin' : '/user';
        }
        Flash::add('success', '欢迎回来，' . ($user['nickname'] ?? $user['login_name']) . '。');
        redirect($target);
    }

    public function showRegister(): void
    {
        if (Auth::check()) {
            redirect('/user');
        }
        if (!Switches::enabled('register_open')) {
            abort(403, '注册通道暂未开放。');
        }
        $this->view('auth/register', ['pageTitle' => '注册'], 'auth');
    }

    public function register(): void
    {
        $this->requirePost();
        if (!Switches::enabled('register_open')) {
            abort(403, '注册通道暂未开放。');
        }

        $loginName = Request::str('login_name', '', 32);
        $nickname = Request::str('nickname', '', 40);
        $phone = Request::str('phone', '', 20);
        $email = Request::str('email', '', 120);
        $password = (string) Request::post('password', '');
        $confirm = (string) Request::post('password_confirm', '');
        $agree = (string) Request::post('agree', '');

        $errors = [];
        if (!preg_match('/^[A-Za-z0-9_\x{4e00}-\x{9fa5}]{3,20}$/u', $loginName)) {
            $errors[] = '登录名需为 3-20 位中文、字母、数字或下划线。';
        }
        if (mb_strlen($nickname, 'UTF-8') < 2 || mb_strlen($nickname, 'UTF-8') > 20) {
            $errors[] = '昵称长度需为 2-20 个字符。';
        }
        if ($phone === '' && $email === '') {
            $errors[] = '手机号与邮箱至少填写一项。';
        }
        if ($phone !== '' && !preg_match('/^1[3-9]\d{9}$/', $phone)) {
            $errors[] = '手机号格式不正确。';
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = '邮箱格式不正确。';
        }
        if (mb_strlen($password, 'UTF-8') < 8) {
            $errors[] = '密码至少 8 位。';
        }
        if ($password !== $confirm) {
            $errors[] = '两次输入的密码不一致。';
        }
        if ($agree !== '1') {
            $errors[] = '请阅读并同意用户协议与隐私规则。';
        }

        if (Database::one('SELECT id FROM users WHERE login_name = ?', [$loginName])) {
            $errors[] = '该登录名已被使用。';
        }
        if ($phone !== '' && Database::one('SELECT id FROM users WHERE phone = ?', [$phone])) {
            $errors[] = '该手机号已被注册。';
        }
        if ($email !== '' && Database::one('SELECT id FROM users WHERE email = ?', [$email])) {
            $errors[] = '该邮箱已被注册。';
        }

        if ($errors !== []) {
            Flash::add('error', implode(' ', $errors));
            redirect('/register');
        }

        $now = date('Y-m-d H:i:s');
        $userId = Database::transaction(function () use ($loginName, $nickname, $phone, $email, $password, $now): int {
            $id = Database::insert('users', [
                'login_name' => $loginName,
                'phone' => $phone === '' ? null : $phone,
                'email' => $email === '' ? null : $email,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'status' => 'active',
                'register_ip' => Request::ip(),
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            Database::insert('user_profiles', [
                'user_id' => $id,
                'nickname' => $nickname,
                'avatar' => null,
                'bio' => null,
                'gender' => null,
                'city' => null,
            ]);
            Database::insert('user_settings', [
                'user_id' => $id,
                'font_size' => 18,
                'line_height' => 2,
                'theme' => 'light',
                'reading_mode' => 'scroll',
                'updated_at' => $now,
            ]);
            $roleId = (int) Database::value("SELECT id FROM roles WHERE code = 'reader'");
            if ($roleId > 0) {
                Database::insert('user_roles', ['user_id' => $id, 'role_id' => $roleId]);
            }
            Database::insert('consents', [
                'user_id' => $id,
                'doc_type' => 'user_agreement',
                'version' => 'v1.0',
                'created_at' => $now,
            ]);
            return $id;
        });

        $user = Database::one('SELECT * FROM users WHERE id = ?', [$userId]);
        if ($user) {
            Auth::login($user);
        }
        Flash::add('success', '注册成功，欢迎来到' . setting('site_name', '墨韵文阁') . '。');
        redirect('/user');
    }

    public function showForgot(): void
    {
        $sent = false;
        $demoLink = '';
        $this->view('auth/forgot', compact('sent', 'demoLink') + ['pageTitle' => '找回密码'], 'auth');
    }

    public function forgot(): void
    {
        $this->requirePost();
        $login = Request::str('login', '', 120);
        $user = Database::one(
            'SELECT * FROM users WHERE login_name = ? OR phone = ? OR email = ? LIMIT 1',
            [$login, $login, $login]
        );

        $sent = true;
        $demoLink = '';
        if ($user) {
            $token = bin2hex(random_bytes(32));
            Database::insert('password_resets', [
                'user_id' => (int) $user['id'],
                'token' => $token,
                'expires_at' => date('Y-m-d H:i:s', time() + 1800),
                'used' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $link = url('/reset-password?token=' . $token);
            $logDir = APP_ROOT . '/storage/logs';
            if (!is_dir($logDir)) {
                @mkdir($logDir, 0775, true);
            }
            @file_put_contents(
                $logDir . '/mail.log',
                '[' . date('Y-m-d H:i:s') . '] 找回密码 ' . $user['login_name'] . ' ' . $link . PHP_EOL,
                FILE_APPEND
            );
            if (\App\Core\Config::get('demo_mode')) {
                $demoLink = $link;
            }
        }

        $this->view('auth/forgot', compact('sent', 'demoLink') + ['pageTitle' => '找回密码'], 'auth');
    }

    public function showReset(): void
    {
        $token = Request::str('token', '', 64);
        $record = $this->validResetToken($token);
        if (!$record) {
            abort(404, '重置链接无效或已过期。');
        }
        $this->view('auth/reset', ['token' => $token, 'pageTitle' => '设置新密码'], 'auth');
    }

    public function resetPassword(): void
    {
        $this->requirePost();
        $token = Request::str('token', '', 64);
        $password = (string) Request::post('password', '');
        $confirm = (string) Request::post('password_confirm', '');
        $record = $this->validResetToken($token);
        if (!$record) {
            abort(404, '重置链接无效或已过期。');
        }
        if (mb_strlen($password, 'UTF-8') < 8 || $password !== $confirm) {
            Flash::add('error', '密码至少 8 位且两次输入需一致。');
            redirect('/reset-password?token=' . urlencode($token));
        }

        $now = date('Y-m-d H:i:s');
        Database::transaction(function () use ($record, $password, $now): void {
            Database::update('users', [
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'updated_at' => $now,
            ], ['id' => (int) $record['user_id']]);
            Database::update('password_resets', ['used' => 1], ['id' => (int) $record['id']]);
        });

        Flash::add('success', '密码已更新，请使用新密码登录。');
        redirect('/login');
    }

    private function validResetToken(string $token): ?array
    {
        if ($token === '') {
            return null;
        }
        return Database::one(
            'SELECT * FROM password_resets WHERE token = ? AND used = 0 AND expires_at >= NOW() LIMIT 1',
            [$token]
        );
    }

    public function logout(): void
    {
        $this->requirePost();
        Auth::logout();
        Flash::add('success', '已安全退出登录。');
        redirect('/');
    }

    private function safeNext(): string
    {
        $next = (string) (Request::input('next', '') ?: '');
        if ($next === '' || !str_starts_with($next, '/') || str_starts_with($next, '//') || str_contains($next, '\\')) {
            return '';
        }
        return $next;
    }
}
