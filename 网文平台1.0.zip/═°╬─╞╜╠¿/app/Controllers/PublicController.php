<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\Request;
use App\Core\Switches;
use App\Services\AccountPurgeService;
use App\Services\RankingService;

class PublicController extends BaseController
{
    public function home(): void
    {
        AccountPurgeService::purgeDueThrottled();
        $publicStatuses = "'approved','serializing','paused','finished'";

        $categories = Database::all('SELECT * FROM book_categories WHERE status = 1 AND parent_id = 0 ORDER BY sort ASC, id ASC');
        foreach ($categories as &$category) {
            $category['books'] = Database::all(
                "SELECT b.*, a.pen_name FROM books b JOIN authors a ON a.id = b.author_id
                 WHERE b.status IN ({$publicStatuses})
                 AND (b.category_id = ? OR b.category_id IN (SELECT id FROM book_categories WHERE parent_id = ?))
                 ORDER BY b.updated_at DESC LIMIT 4",
                [(int) $category['id'], (int) $category['id']]
            );
        }
        unset($category);

        // 首页轮播：优先取首页大图推荐位，不足时用精选/热门作品补齐
        $heroSlides = Database::all(
            "SELECT b.*, a.pen_name, c.name AS category_name
             FROM recommendations r
             JOIN books b ON b.id = r.book_id
             JOIN authors a ON a.id = b.author_id
             LEFT JOIN book_categories c ON c.id = b.category_id
             WHERE r.slot = 'home_hero' AND r.status = 1
               AND (r.start_at IS NULL OR r.start_at <= NOW())
               AND (r.end_at IS NULL OR r.end_at >= NOW())
               AND b.status IN ({$publicStatuses})
             ORDER BY r.weight DESC, r.id DESC LIMIT 5"
        );
        if ($heroSlides === []) {
            $heroSlides = Database::all(
                "SELECT b.*, a.pen_name, c.name AS category_name
                 FROM books b JOIN authors a ON a.id = b.author_id
                 LEFT JOIN book_categories c ON c.id = b.category_id
                 WHERE b.status IN ({$publicStatuses})
                 ORDER BY b.is_featured DESC, b.view_count DESC, b.id DESC LIMIT 5"
            );
        }

        // 轮播统计：已发布章节数只统计各自作品，而不是全站
        if ($heroSlides !== []) {
            $heroIds = array_map(static fn (array $book): int => (int) $book['id'], $heroSlides);
            $marks = implode(', ', array_fill(0, count($heroIds), '?'));
            $chapterCounts = Database::all(
                "SELECT book_id, COUNT(*) AS total FROM chapters
                 WHERE status = 'published' AND book_id IN ({$marks}) GROUP BY book_id",
                $heroIds
            );
            $countMap = [];
            foreach ($chapterCounts as $row) {
                $countMap[(int) $row['book_id']] = (int) $row['total'];
            }
            foreach ($heroSlides as &$heroSlide) {
                $heroSlide['published_chapters'] = $countMap[(int) $heroSlide['id']] ?? 0;
            }
            unset($heroSlide);
        }

        $spotlight = Database::all(
            "SELECT b.*, a.pen_name FROM recommendations r
             JOIN books b ON b.id = r.book_id JOIN authors a ON a.id = b.author_id
             WHERE r.slot = 'home_spotlight' AND r.status = 1
               AND (r.start_at IS NULL OR r.start_at <= NOW())
               AND (r.end_at IS NULL OR r.end_at >= NOW())
               AND b.status IN ({$publicStatuses})
             ORDER BY r.weight DESC LIMIT 4"
        );
        if ($spotlight === []) {
            $spotlight = Database::all(
                "SELECT b.*, a.pen_name FROM books b JOIN authors a ON a.id = b.author_id
                 WHERE b.status IN ({$publicStatuses}) ORDER BY b.published_at DESC, b.id DESC LIMIT 4"
            );
        }

        $newBooks = Database::all(
            "SELECT b.*, a.pen_name, c.name AS category_name FROM books b
             JOIN authors a ON a.id = b.author_id
             LEFT JOIN book_categories c ON c.id = b.category_id
             WHERE b.status IN ({$publicStatuses}) ORDER BY b.published_at DESC, b.id DESC LIMIT 8"
        );

        $top = RankingService::compute('total', 0, 6)['books'];
        $rankingDefs = Database::all('SELECT * FROM rankings WHERE status = 1 ORDER BY id ASC LIMIT 8');

        $latestChapters = Database::all(
            "SELECT ch.id, ch.title, ch.chapter_no, ch.published_at, ch.is_paid, b.title AS book_title, b.id AS book_id, a.pen_name
             FROM chapters ch JOIN books b ON b.id = ch.book_id JOIN authors a ON a.id = b.author_id
             WHERE ch.status = 'published' AND b.status IN ({$publicStatuses})
             ORDER BY ch.published_at DESC LIMIT 8"
        );

        $announcements = Database::all(
            "SELECT * FROM announcements WHERE status = 'published'
             AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at >= NOW())
             ORDER BY id DESC LIMIT 3"
        );

        $activities = Database::all(
            "SELECT * FROM activities WHERE status = 'published'
             AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at >= NOW())
             ORDER BY id DESC LIMIT 3"
        );

        $stats = [
            'books' => (int) Database::value("SELECT COUNT(*) FROM books WHERE status IN ({$publicStatuses})"),
            'authors' => (int) Database::value("SELECT COUNT(*) FROM authors WHERE status = 'active'"),
        ];

        $this->view('public/home', compact(
            'categories', 'heroSlides', 'spotlight', 'newBooks', 'top', 'rankingDefs',
            'latestChapters', 'announcements', 'activities', 'stats'
        ));
    }

    public function category(string $id = '0'): void
    {
        $categoryId = (int) $id;
        $categories = Database::all('SELECT * FROM book_categories WHERE status = 1 ORDER BY sort ASC, id ASC');
        $selected = null;
        if ($categoryId > 0) {
            foreach ($categories as $category) {
                if ((int) $category['id'] === $categoryId) {
                    $selected = $category;
                    break;
                }
            }
            if (!$selected) {
                abort(404, '分类不存在或已下线。');
            }
        }

        $this->renderBrowse([
            'mode' => 'category',
            'heading' => $selected ? $selected['name'] : '全部分类',
            'subheading' => $selected ? (string) ($selected['description'] ?? '') : '在字里行间，寻找与你心意相通的故事。',
            'categoryId' => $categoryId,
            'basePath' => $categoryId > 0 ? '/category/' . $categoryId : '/category',
            'categories' => $categories,
            'selected' => $selected,
        ]);
    }

    public function search(): void
    {
        if (!Switches::enabled('search_open')) {
            abort(404, '站内搜索暂未开放。');
        }
        $keyword = Request::str('q', '', 60);
        $categories = Database::all('SELECT * FROM book_categories WHERE status = 1 ORDER BY sort ASC, id ASC');
        $this->renderBrowse([
            'mode' => 'search',
            'heading' => $keyword === '' ? '找书' : '搜索“' . $keyword . '”',
            'subheading' => '支持书名、作者笔名、简介与标签检索，章节正文不参与公开全文搜索。',
            'categoryId' => 0,
            'basePath' => '/search',
            'categories' => $categories,
            'selected' => null,
            'keyword' => $keyword,
        ]);
    }

    private function renderBrowse(array $options): void
    {
        $publicStatuses = "'approved','serializing','paused','finished'";
        $page = max(1, Request::int('page', 1));
        $sort = Request::str('sort', 'updated', 20);
        $status = Request::str('status', 'all', 20);
        $words = Request::str('words', 'all', 20);
        $updated = Request::str('updated', 'all', 20);
        $selectedTags = array_values(array_filter(array_map('intval', (array) ($_GET['tags'] ?? []))));

        $allowedSorts = ['updated', 'new', 'heat', 'favorite', 'rating'];
        if (!in_array($sort, $allowedSorts, true)) {
            $sort = 'updated';
        }

        $where = ["b.status IN ({$publicStatuses})"];
        $params = [];

        if ((int) $options['categoryId'] > 0) {
            $where[] = '(b.category_id = ? OR b.category_id IN (SELECT id FROM book_categories WHERE parent_id = ?))';
            $params[] = (int) $options['categoryId'];
            $params[] = (int) $options['categoryId'];
        }

        if ($status === 'serializing' || $status === 'finished' || $status === 'paused') {
            $where[] = 'b.status = ?';
            $params[] = $status;
        }

        if ($words === 'lt30') {
            $where[] = 'b.word_count < 300000';
        } elseif ($words === '30to100') {
            $where[] = 'b.word_count >= 300000 AND b.word_count <= 1000000';
        } elseif ($words === 'gt100') {
            $where[] = 'b.word_count > 1000000';
        }

        if ($updated === '7') {
            $where[] = 'b.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
        } elseif ($updated === '30') {
            $where[] = 'b.updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        }

        foreach ($selectedTags as $tagId) {
            $where[] = 'EXISTS (SELECT 1 FROM book_tag_map tm WHERE tm.book_id = b.id AND tm.tag_id = ?)';
            $params[] = $tagId;
        }

        if (($options['mode'] ?? '') === 'search') {
            $keyword = (string) ($options['keyword'] ?? '');
            if ($keyword !== '') {
                $like = '%' . $keyword . '%';
                $where[] = '(b.title LIKE ? OR b.summary LIKE ? OR EXISTS (SELECT 1 FROM authors a2 WHERE a2.id = b.author_id AND a2.pen_name LIKE ?) OR EXISTS (SELECT 1 FROM book_tag_map tm2 JOIN tags t2 ON t2.id = tm2.tag_id WHERE tm2.book_id = b.id AND t2.name LIKE ?))';
                array_push($params, $like, $like, $like, $like);
            }
        }

        $whereSql = implode(' AND ', $where);
        $tagList = Database::all('SELECT * FROM tags WHERE status = 1 ORDER BY id ASC');

        $countSql = 'SELECT COUNT(*) FROM books b WHERE ' . $whereSql;
        $total = (int) Database::value($countSql, $params);

        $perPage = 16;
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url($options['basePath']), array_merge($_GET, ['page' => null]));

        $orderSql = match ($sort) {
            'new' => 'b.published_at DESC, b.id DESC',
            'heat' => '(b.view_count + b.favorite_count * 3 + b.rating_count * 2) DESC',
            'favorite' => 'b.favorite_count DESC, b.view_count DESC',
            'rating' => 'b.rating DESC, b.rating_count DESC',
            default => 'b.updated_at DESC',
        };

        $books = Database::all(
            "SELECT b.*, a.pen_name, c.name AS category_name,
             (SELECT GROUP_CONCAT(t.name ORDER BY t.id SEPARATOR ' · ') FROM book_tag_map tm JOIN tags t ON t.id = tm.tag_id WHERE tm.book_id = b.id LIMIT 1) AS tag_names
             FROM books b JOIN authors a ON a.id = b.author_id
             LEFT JOIN book_categories c ON c.id = b.category_id
             WHERE {$whereSql}
             ORDER BY {$orderSql}
             LIMIT {$perPage} OFFSET {$pager['offset']}",
            $params
        );

        $filters = [
            'sort' => $sort,
            'status' => $status,
            'words' => $words,
            'updated' => $updated,
            'tags' => $selectedTags,
        ];

        $this->view('public/browse', array_merge($options, [
            'books' => $books,
            'pager' => $pager,
            'tags' => $tagList,
            'filters' => $filters,
            'keyword' => $options['keyword'] ?? '',
        ]));
    }

    public function ranking(string $code = 'total'): void
    {
        $rankings = Database::all('SELECT * FROM rankings WHERE status = 1 ORDER BY id ASC');
        $categoryId = Request::int('cat', 0);
        $computed = RankingService::compute($code, $categoryId, 30);
        $ranking = $computed['ranking'];
        if (!$ranking) {
            abort(404, '榜单不存在。');
        }

        $categories = Database::all('SELECT * FROM book_categories WHERE status = 1 AND parent_id = 0 ORDER BY sort ASC');
        $formula = match ((string) $ranking['type']) {
            'favorite' => '按有效收藏数排序，收藏关联去重后计数。',
            'read' => '按有效阅读量排序，同一会话对同一章节只计一次。',
            'new' => '仅收录发布 30 天内的作品，按发布时间排序。',
            'finished' => '仅收录已完结作品，按评分与评分人数排序。',
            'rating' => '仅统计有效账号的有效评分，样本低于阈值不入榜。',
            default => '热度 = 阅读量 + 收藏量 × 3 + 评分人数 × 2，规则公开可解释。',
        };

        $this->view('public/ranking', [
            'rankings' => $rankings,
            'ranking' => $ranking,
            'books' => $computed['books'],
            'categories' => $categories,
            'categoryId' => $categoryId,
            'formula' => $formula,
        ]);
    }

    public function book(string $id): void
    {
        $bookId = (int) $id;
        $publicStatuses = "'approved','serializing','paused','finished'";
        $book = Database::one(
            "SELECT b.*, a.pen_name, COALESCE(NULLIF(a.avatar, ''), p.avatar) AS author_avatar, a.intro AS author_intro, a.user_id AS author_user_id, a.id AS author_record_id, c.name AS category_name
             FROM books b JOIN authors a ON a.id = b.author_id
             LEFT JOIN user_profiles p ON p.user_id = a.user_id
             LEFT JOIN book_categories c ON c.id = b.category_id
             WHERE b.id = ? AND b.status IN ({$publicStatuses}) LIMIT 1",
            [$bookId]
        );
        if (!$book) {
            abort(404, '作品不存在或暂未公开。');
        }

        if (isset($_SESSION['book_viewed'][$bookId])) {
            // 同一会话只计一次
        } else {
            $_SESSION['book_viewed'][$bookId] = true;
            Database::query('UPDATE books SET view_count = view_count + 1 WHERE id = ?', [$bookId]);
            $book['view_count'] = (int) $book['view_count'] + 1;
        }

        $latestChapters = Database::all(
            "SELECT id, title, chapter_no, published_at, is_paid, word_count FROM chapters
             WHERE book_id = ? AND status = 'published' ORDER BY chapter_no DESC LIMIT 8",
            [$bookId]
        );

        $chapterCount = (int) Database::value("SELECT COUNT(*) FROM chapters WHERE book_id = ? AND status = 'published'", [$bookId]);

        $tags = Database::all(
            'SELECT t.name FROM book_tag_map tm JOIN tags t ON t.id = tm.tag_id WHERE tm.book_id = ? ORDER BY t.id',
            [$bookId]
        );

        $commentTotal = (int) Database::value("SELECT COUNT(*) FROM comments WHERE book_id = ? AND status = 'approved' AND parent_id IS NULL", [$bookId]);
        $page = max(1, Request::int('page', 1));
        $perPage = 8;
        $pager = \App\Core\Paginator::make($commentTotal, $perPage, $page, url('/book/' . $bookId), ['page' => null]);
        $comments = Database::all(
            "SELECT cm.*, p.nickname, p.avatar FROM comments cm
             LEFT JOIN user_profiles p ON p.user_id = cm.user_id
             WHERE cm.book_id = ? AND cm.status = 'approved' AND cm.parent_id IS NULL
             ORDER BY cm.created_at DESC LIMIT {$perPage} OFFSET {$pager['offset']}",
            [$bookId]
        );
        foreach ($comments as &$comment) {
            $comment['replies'] = Database::all(
                "SELECT cm.*, p.nickname FROM comments cm LEFT JOIN user_profiles p ON p.user_id = cm.user_id
                 WHERE cm.parent_id = ? AND cm.status = 'approved' ORDER BY cm.created_at ASC LIMIT 3",
                [(int) $comment['id']]
            );
        }
        unset($comment);

        $similar = Database::all(
            "SELECT b.*, a.pen_name FROM books b JOIN authors a ON a.id = b.author_id
             WHERE b.category_id = ? AND b.id <> ? AND b.status IN ({$publicStatuses})
             ORDER BY b.view_count DESC LIMIT 4",
            [(int) $book['category_id'], $bookId]
        );

        $authorBooks = Database::all(
            "SELECT b.* FROM books b WHERE b.author_id = ? AND b.id <> ? AND b.status IN ({$publicStatuses}) ORDER BY b.updated_at DESC LIMIT 4",
            [(int) $book['author_id'], $bookId]
        );

        $userRating = 0;
        $inShelf = false;
        if (\App\Core\Auth::check()) {
            $ratingRow = Database::one('SELECT score FROM ratings WHERE user_id = ? AND book_id = ?', [\App\Core\Auth::id(), $bookId]);
            $userRating = $ratingRow ? (int) $ratingRow['score'] : 0;
            $shelfRow = Database::one('SELECT id FROM bookshelf WHERE user_id = ? AND book_id = ?', [\App\Core\Auth::id(), $bookId]);
            $inShelf = $shelfRow !== null;
        }

        $this->view('public/book', [
            'book' => $book,
            'latestChapters' => $latestChapters,
            'chapterCount' => $chapterCount,
            'tags' => $tags,
            'comments' => $comments,
            'commentPager' => $pager,
            'commentTotal' => $commentTotal,
            'similar' => $similar,
            'authorBooks' => $authorBooks,
            'userRating' => $userRating,
            'inShelf' => $inShelf,
        ]);
    }

    public function catalog(string $id): void
    {
        $bookId = (int) $id;
        $publicStatuses = "'approved','serializing','paused','finished'";
        $book = Database::one(
            "SELECT b.*, a.pen_name, c.name AS category_name FROM books b JOIN authors a ON a.id = b.author_id
             LEFT JOIN book_categories c ON c.id = b.category_id
             WHERE b.id = ? AND b.status IN ({$publicStatuses}) LIMIT 1",
            [$bookId]
        );
        if (!$book) {
            abort(404, '作品不存在或暂未公开。');
        }

        $volumes = Database::all(
            "SELECT * FROM volumes WHERE book_id = ? AND status IN ('public','hidden') ORDER BY sort ASC, id ASC",
            [$bookId]
        );
        foreach ($volumes as &$volume) {
            $volume['chapters'] = Database::all(
                "SELECT id, title, chapter_no, word_count, is_paid, published_at FROM chapters
                 WHERE volume_id = ? AND status = 'published' ORDER BY chapter_no ASC",
                [(int) $volume['id']]
            );
        }
        unset($volume);

        $total = (int) Database::value("SELECT COUNT(*) FROM chapters WHERE book_id = ? AND status = 'published'", [$bookId]);
        $last = Database::one("SELECT id, title FROM chapters WHERE book_id = ? AND status = 'published' ORDER BY chapter_no DESC LIMIT 1", [$bookId]);

        $this->view('public/catalog', [
            'book' => $book,
            'volumes' => $volumes,
            'total' => $total,
            'last' => $last,
        ]);
    }

    public function chapter(string $id): void
    {
        $chapterId = (int) $id;
        $publicStatuses = "'approved','serializing','paused','finished'";
        $chapter = Database::one(
            "SELECT ch.*, b.title AS book_title, b.id AS book_id, b.status AS book_status, b.author_id, a.pen_name, a.user_id AS author_user_id
             FROM chapters ch JOIN books b ON b.id = ch.book_id JOIN authors a ON a.id = b.author_id
             WHERE ch.id = ? AND ch.status = 'published' AND b.status IN ({$publicStatuses}) LIMIT 1",
            [$chapterId]
        );
        if (!$chapter) {
            abort(404, '章节不存在或暂未开放阅读。');
        }

        $contentRow = Database::one(
            'SELECT content FROM chapter_contents WHERE chapter_id = ? ORDER BY version_no DESC LIMIT 1',
            [$chapterId]
        );
        $content = $contentRow ? (string) $contentRow['content'] : '';

        if (empty($_SESSION['chapter_viewed'][$chapterId])) {
            $_SESSION['chapter_viewed'][$chapterId] = true;
            Database::query('UPDATE chapters SET read_count = read_count + 1 WHERE id = ?', [$chapterId]);
            Database::query('UPDATE books SET view_count = view_count + 1 WHERE id = ?', [(int) $chapter['book_id']]);
        }

        if (\App\Core\Auth::check()) {
            $userId = \App\Core\Auth::id();
            $exists = Database::one('SELECT id FROM reading_history WHERE user_id = ? AND book_id = ?', [$userId, (int) $chapter['book_id']]);
            if ($exists) {
                Database::update('reading_history', [
                    'chapter_id' => $chapterId,
                    'read_at' => date('Y-m-d H:i:s'),
                ], ['id' => (int) $exists['id']]);
            } else {
                Database::insert('reading_history', [
                    'user_id' => $userId,
                    'book_id' => (int) $chapter['book_id'],
                    'chapter_id' => $chapterId,
                    'read_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }

        $prev = Database::one(
            "SELECT id, title, chapter_no FROM chapters WHERE book_id = ? AND status = 'published' AND chapter_no < ? ORDER BY chapter_no DESC LIMIT 1",
            [(int) $chapter['book_id'], (int) $chapter['chapter_no']]
        );
        $next = Database::one(
            "SELECT id, title, chapter_no FROM chapters WHERE book_id = ? AND status = 'published' AND chapter_no > ? ORDER BY chapter_no ASC LIMIT 1",
            [(int) $chapter['book_id'], (int) $chapter['chapter_no']]
        );

        $volumes = Database::all(
            "SELECT * FROM volumes WHERE book_id = ? AND status IN ('public','hidden') ORDER BY sort ASC",
            [(int) $chapter['book_id']]
        );
        foreach ($volumes as &$volume) {
            $volume['chapters'] = Database::all(
                "SELECT id, title, chapter_no FROM chapters WHERE volume_id = ? AND status = 'published' ORDER BY chapter_no ASC",
                [(int) $volume['id']]
            );
        }
        unset($volume);

        $prefs = ['font_size' => 18, 'line_height' => 2, 'theme' => 'light', 'reading_mode' => 'scroll'];
        if (\App\Core\Auth::check()) {
            $saved = Database::one('SELECT * FROM user_settings WHERE user_id = ?', [\App\Core\Auth::id()]);
            if ($saved) {
                $prefs = [
                    'font_size' => (int) $saved['font_size'],
                    'line_height' => (int) $saved['line_height'],
                    'theme' => (string) $saved['theme'],
                    'reading_mode' => (string) $saved['reading_mode'],
                ];
            }
        }

        $book = [
            'id' => (int) $chapter['book_id'],
            'title' => $chapter['book_title'],
            'author_id' => (int) $chapter['author_id'],
            'pen_name' => $chapter['pen_name'],
            'status' => $chapter['book_status'],
        ];

        $paidNote = (int) $chapter['is_paid'] === 1
            ? '本章标注为付费章节 · 商业化功能关闭期间免费开放阅读'
            : null;

        $this->view('public/chapter', [
            'chapter' => $chapter,
            'book' => $book,
            'content' => $content,
            'prev' => $prev,
            'next' => $next,
            'volumes' => $volumes,
            'prefs' => $prefs,
            'paidNote' => $paidNote,
        ]);
    }

    public function announcements(): void
    {
        $page = max(1, Request::int('page', 1));
        $perPage = 10;
        $total = (int) Database::value(
            "SELECT COUNT(*) FROM announcements WHERE status = 'published' AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at >= NOW())"
        );
        $pager = \App\Core\Paginator::make($total, $perPage, $page, url('/announcements'), ['page' => null]);
        $items = Database::all(
            "SELECT * FROM announcements WHERE status = 'published'
             AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at >= NOW())
             ORDER BY id DESC LIMIT {$perPage} OFFSET {$pager['offset']}"
        );
        $this->view('public/announcements', ['items' => $items, 'pager' => $pager]);
    }

    public function announcement(string $id): void
    {
        $item = Database::one("SELECT * FROM announcements WHERE id = ? AND status = 'published' LIMIT 1", [(int) $id]);
        if (!$item) {
            abort(404, '公告不存在或已下线。');
        }
        $this->view('public/announcement', ['item' => $item]);
    }

    public function activities(): void
    {
        $items = Database::all(
            "SELECT * FROM activities WHERE status = 'published'
             AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at >= NOW())
             ORDER BY id DESC"
        );
        $this->view('public/activities', ['items' => $items]);
    }

    public function activity(string $id): void
    {
        $item = Database::one("SELECT * FROM activities WHERE id = ? AND status = 'published' LIMIT 1", [(int) $id]);
        if (!$item) {
            abort(404, '活动不存在或已下线。');
        }
        $this->view('public/activity', ['item' => $item]);
    }

    public function about(): void
    {
        $this->view('public/about', []);
    }
}
