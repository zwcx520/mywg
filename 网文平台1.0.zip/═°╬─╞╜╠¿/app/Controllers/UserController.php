<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Request;
use App\Core\Switches;
use App\Services\ModerationService;
use App\Services\UploadService;

class UserController extends BaseController
{
    public function center(): void
    {
        Auth::requireLogin();
        $userId = Auth::id();

        $publicStatuses = "'approved','serializing','paused','finished'";
        $stats = [
            'shelf' => (int) Database::value("SELECT COUNT(*) FROM bookshelf s JOIN books b ON b.id = s.book_id WHERE s.user_id = ? AND b.status IN ({$publicStatuses})", [$userId]),
            'history' => (int) Database::value("SELECT COUNT(*) FROM reading_history rh JOIN books b ON b.id = rh.book_id WHERE rh.user_id = ? AND b.status IN ({$publicStatuses})", [$userId]),
            'comments' => (int) Database::value("SELECT COUNT(*) FROM comments WHERE user_id = ? AND status <> 'deleted'", [$userId]),
            'notices' => (int) Database::value('SELECT COUNT(*) FROM notices WHERE user_id = ? AND is_read = 0', [$userId]),
        ];

        $history = Database::all(
            "SELECT rh.*, b.title, b.cover, c.title AS chapter_title, a.pen_name
             FROM reading_history rh JOIN books b ON b.id = rh.book_id
             LEFT JOIN chapters c ON c.id = rh.chapter_id
             LEFT JOIN authors a ON a.id = b.author_id
             WHERE rh.user_id = ? AND b.status IN ({$publicStatuses}) ORDER BY rh.read_at DESC LIMIT 4",
            [$userId]
        );

        $notices = Database::all('SELECT * FROM notices WHERE user_id = ? ORDER BY id DESC LIMIT 4', [$userId]);
        $author = $this->currentAuthor();

        $this->view('user/center', compact('stats', 'history', 'notices', 'author'), 'account');
    }

    public function bookshelf(): void
    {
        Auth::requireLogin();
        $rows = Database::all(
            "SELECT s.*, b.title, b.cover, b.summary, b.status, b.word_count, b.updated_at, b.id AS book_id,
             a.pen_name, (SELECT COUNT(*) FROM chapters c WHERE c.book_id = b.id AND c.status = 'published') AS chapter_count
             FROM bookshelf s JOIN books b ON b.id = s.book_id LEFT JOIN authors a ON a.id = b.author_id
             WHERE s.user_id = ? AND b.status IN ('approved','serializing','paused','finished')
             ORDER BY s.is_top DESC, s.created_at DESC",
            [Auth::id()]
        );
        $groups = [];
        foreach ($rows as $row) {
            $groups[(string) $row['group_name']][] = $row;
        }
        $this->view('user/bookshelf', ['groups' => $groups, 'rows' => $rows], 'account');
    }

    public function shelfAdd(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $bookId = Request::int('book_id');
        $book = Database::one("SELECT id FROM books WHERE id = ? AND status IN ('approved','serializing','paused','finished')", [$bookId]);
        if (!$book) {
            Flash::add('error', '作品不存在或暂未公开。');
            redirect('/');
        }
        $existing = Database::one('SELECT id FROM bookshelf WHERE user_id = ? AND book_id = ?', [Auth::id(), $bookId]);
        if ($existing) {
            Flash::add('info', '该作品已在书架中。');
        } else {
            $group = Request::str('group_name', '默认分组', 30);
            Database::insert('bookshelf', [
                'user_id' => Auth::id(),
                'book_id' => $bookId,
                'group_name' => $group === '' ? '默认分组' : $group,
                'is_top' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            Database::query('UPDATE books SET favorite_count = favorite_count + 1 WHERE id = ?', [$bookId]);
            Flash::add('success', '已加入书架。');
        }
        redirect('/book/' . $bookId);
    }

    public function shelfRemove(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $bookId = Request::int('book_id');
        $row = Database::one('SELECT id FROM bookshelf WHERE user_id = ? AND book_id = ?', [Auth::id(), $bookId]);
        if ($row) {
            Database::query('DELETE FROM bookshelf WHERE id = ?', [(int) $row['id']]);
            Database::query('UPDATE books SET favorite_count = GREATEST(favorite_count - 1, 0) WHERE id = ?', [$bookId]);
            Flash::add('success', '已从书架移除。');
        }
        redirect('/user/bookshelf');
    }

    public function history(): void
    {
        Auth::requireLogin();
        $rows = Database::all(
            "SELECT rh.*, b.title, b.cover, c.title AS chapter_title, c.id AS chapter_id, a.pen_name
             FROM reading_history rh JOIN books b ON b.id = rh.book_id
             LEFT JOIN chapters c ON c.id = rh.chapter_id LEFT JOIN authors a ON a.id = b.author_id
             WHERE rh.user_id = ? AND b.status IN ('approved','serializing','paused','finished')
             ORDER BY rh.read_at DESC LIMIT 100",
            [Auth::id()]
        );
        $this->view('user/history', ['rows' => $rows], 'account');
    }

    public function historyDelete(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $id = Request::int('id');
        Database::query('DELETE FROM reading_history WHERE id = ? AND user_id = ?', [$id, Auth::id()]);
        Flash::add('success', '已删除该条阅读记录。');
        redirect('/user/history');
    }

    public function historyClear(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        Database::query('DELETE FROM reading_history WHERE user_id = ?', [Auth::id()]);
        Flash::add('success', '阅读历史已清空。');
        redirect('/user/history');
    }

    public function comments(): void
    {
        Auth::requireLogin();
        $rows = Database::all(
            "SELECT cm.*, b.title AS book_title, b.id AS book_id FROM comments cm
             LEFT JOIN books b ON b.id = cm.book_id
             WHERE cm.user_id = ? AND cm.status <> 'deleted' AND b.id IS NOT NULL AND b.status <> 'deleted'
             ORDER BY cm.id DESC LIMIT 100",
            [Auth::id()]
        );
        $this->view('user/comments', ['rows' => $rows], 'account');
    }

    public function commentDelete(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $id = Request::int('id');
        $comment = Database::one('SELECT * FROM comments WHERE id = ? AND user_id = ?', [$id, Auth::id()]);
        if ($comment) {
            $openRecycle = Database::one(
                "SELECT id FROM recycle_items WHERE target_type = 'comment' AND target_id = ? AND restored_at IS NULL",
                [$id]
            );
            Database::update('comments', ['status' => 'deleted'], ['id' => $id]);
            if (!$openRecycle) {
                Database::insert('recycle_items', [
                    'target_type' => 'comment',
                    'target_id' => $id,
                    'title' => mb_substr((string) $comment['content'], 0, 120, 'UTF-8'),
                    'owner_id' => (int) $comment['user_id'],
                    'deleted_by' => (int) $comment['user_id'],
                    'deleted_at' => date('Y-m-d H:i:s'),
                    'restore_deadline' => date('Y-m-d H:i:s', time() + 30 * 86400),
                    'reason' => '用户删除评论',
                    'restored_at' => null,
                ]);
            }
            Flash::add('success', '评论已删除。');
        }
        redirect('/user/comments');
    }

    public function postComment(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $bookId = Request::int('book_id');
        $content = Request::str('content', '', 500);
        $parentId = Request::int('parent_id');
        $back = $this->safeBack('/book/' . $bookId);

        $book = Database::one("SELECT id FROM books WHERE id = ? AND status IN ('approved','serializing','paused','finished')", [$bookId]);
        if (!$book) {
            Flash::add('error', '作品不存在或暂未公开。');
            redirect($back);
        }
        if (mb_strlen($content, 'UTF-8') < 2) {
            Flash::add('error', '评论内容太短。');
            redirect($back);
        }
        $recent = (int) Database::value(
            'SELECT COUNT(*) FROM comments WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)',
            [Auth::id()]
        );
        if ($recent >= 5) {
            Flash::add('error', '评论过于频繁，请稍后再试。');
            redirect($back);
        }

        $chapterId = Request::int('chapter_id');
        if ($chapterId > 0) {
            $chapter = Database::one('SELECT id FROM chapters WHERE id = ? AND book_id = ?', [$chapterId, $bookId]);
            if (!$chapter) {
                $chapterId = 0;
            }
        }

        if ($parentId > 0) {
            $parent = Database::one('SELECT id FROM comments WHERE id = ? AND book_id = ? AND parent_id IS NULL', [$parentId, $bookId]);
            if (!$parent) {
                $parentId = 0;
            }
        }

        $status = 'approved';
        $risk = ModerationService::scan($content);
        if (Switches::enabled('comment_pre_review') || $risk === 'high') {
            $status = 'waiting';
        }

        Database::insert('comments', [
            'book_id' => $bookId,
            'chapter_id' => $chapterId > 0 ? $chapterId : null,
            'user_id' => Auth::id(),
            'parent_id' => $parentId > 0 ? $parentId : null,
            'content' => $content,
            'status' => $status,
            'like_count' => 0,
            'ip' => Request::ip(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Flash::add($status === 'approved' ? 'success' : 'info', $status === 'approved' ? '评论已发布。' : '评论已提交，进入审核队列。');
        redirect($back);
    }

    public function likeComment(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $commentId = Request::int('comment_id');
        $back = $this->safeBack('/');
        $comment = Database::one("SELECT * FROM comments WHERE id = ? AND status = 'approved'", [$commentId]);
        if (!$comment) {
            redirect($back);
        }
        $exists = Database::one('SELECT user_id FROM comment_likes WHERE user_id = ? AND comment_id = ?', [Auth::id(), $commentId]);
        if ($exists) {
            Database::query('DELETE FROM comment_likes WHERE user_id = ? AND comment_id = ?', [Auth::id(), $commentId]);
            Database::query('UPDATE comments SET like_count = GREATEST(like_count - 1, 0) WHERE id = ?', [$commentId]);
        } else {
            Database::insert('comment_likes', [
                'user_id' => Auth::id(),
                'comment_id' => $commentId,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            Database::query('UPDATE comments SET like_count = like_count + 1 WHERE id = ?', [$commentId]);
        }
        redirect($back);
    }

    public function rate(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $bookId = Request::int('book_id');
        $score = max(1, min(10, Request::int('score', 8)));
        $book = Database::one("SELECT id FROM books WHERE id = ? AND status IN ('approved','serializing','paused','finished')", [$bookId]);
        if (!$book) {
            abort(404, '作品不存在。');
        }

        $now = date('Y-m-d H:i:s');
        $existing = Database::one('SELECT id FROM ratings WHERE user_id = ? AND book_id = ?', [Auth::id(), $bookId]);
        if ($existing) {
            Database::update('ratings', ['score' => $score, 'updated_at' => $now], ['id' => (int) $existing['id']]);
        } else {
            Database::insert('ratings', [
                'user_id' => Auth::id(),
                'book_id' => $bookId,
                'score' => $score,
                'updated_at' => $now,
            ]);
        }

        $avg = Database::one('SELECT AVG(score) AS avg_score, COUNT(*) AS cnt FROM ratings WHERE book_id = ?', [$bookId]);
        Database::update('books', [
            'rating' => round((float) ($avg['avg_score'] ?? 0), 1),
            'rating_count' => (int) ($avg['cnt'] ?? 0),
        ], ['id' => $bookId]);

        Flash::add('success', '感谢你的评分：' . $score . ' 分。');
        redirect('/book/' . $bookId . '#comments');
    }

    public function reportForm(): void
    {
        Auth::requireLogin('/login');

        $targetType = Request::str('target_type', '', 20);
        $targetId = Request::int('target_id');
        $allowed = ['book', 'chapter', 'comment', 'user', 'cover', 'summary'];

        if (in_array($targetType, $allowed, true) && $targetId > 0) {
            $target = $this->resolveTarget($targetType, $targetId);
            if (!$target) {
                abort(404, '举报对象不存在。');
            }
            $this->view('user/report', [
                'targetType' => $targetType,
                'targetId' => $targetId,
                'target' => $target,
                'books' => [],
                'keyword' => '',
                'back' => $this->safeBack('/book/' . ($targetType === 'book' ? $targetId : ($target['book_id'] ?? $targetId))),
            ]);
            return;
        }

        // 未指定举报对象时，提供站内作品检索入口
        $keyword = Request::str('q', '', 50);
        $books = [];
        if ($keyword !== '') {
            $books = Database::all(
                "SELECT b.id, b.title, b.cover, b.status, a.pen_name
                 FROM books b JOIN authors a ON a.id = b.author_id
                 WHERE b.status IN ('approved', 'serializing', 'paused', 'finished')
                   AND (b.title LIKE ? OR a.pen_name LIKE ?)
                 ORDER BY b.view_count DESC LIMIT 12",
                ['%' . $keyword . '%', '%' . $keyword . '%']
            );
        }

        $this->view('user/report', [
            'targetType' => '',
            'targetId' => 0,
            'target' => null,
            'books' => $books,
            'keyword' => $keyword,
            'back' => '/',
        ]);
    }

    public function reportSubmit(): void
    {
        $this->requirePost();
        Auth::requireLogin('/login');
        $targetType = Request::str('target_type', '', 20);
        $targetId = Request::int('target_id');
        $category = Request::str('category', 'other', 20);
        $description = Request::str('description', '', 500);
        $back = $this->safeBack('/');

        $allowedTypes = ['book', 'chapter', 'comment', 'user', 'cover', 'summary'];
        $allowedCategories = ['violation', 'copyright', 'spam', 'minor', 'other'];
        if (!in_array($targetType, $allowedTypes, true) || $targetId <= 0) {
            abort(404, '举报对象无效。');
        }
        if (!in_array($category, $allowedCategories, true)) {
            $category = 'other';
        }
        $target = $this->resolveTarget($targetType, $targetId);
        if (!$target) {
            abort(404, '举报对象不存在。');
        }

        $recent = (int) Database::value(
            'SELECT COUNT(*) FROM reports WHERE reporter_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)',
            [Auth::id()]
        );
        if ($recent >= 3) {
            Flash::add('error', '举报提交过于频繁，请稍后再试。');
            redirect($back);
        }

        $reportId = Database::insert('reports', [
            'reporter_id' => Auth::id(),
            'target_type' => $targetType,
            'target_id' => $targetId,
            'category' => $category,
            'description' => $description,
            'status' => 'received',
            'result' => null,
            'handled_by' => null,
            'handled_at' => null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Flash::add('success', '举报已受理，受理编号：JB' . str_pad((string) $reportId, 6, '0', STR_PAD_LEFT) . '。我们不会向被举报人展示举报人信息。');
        if (Auth::check()) {
            notify_user(Auth::id(), '举报已受理', '受理编号 JB' . str_pad((string) $reportId, 6, '0', STR_PAD_LEFT) . '，可在举报记录中查看处理状态。');
            redirect('/user/reports');
        }
        redirect($back);
    }

    private function resolveTarget(string $type, int $id): ?array
    {
        return match ($type) {
            'book', 'cover', 'summary' => Database::one('SELECT id, title, author_id FROM books WHERE id = ?', [$id]),
            'chapter' => Database::one('SELECT c.id, c.title, c.book_id, b.title AS book_title FROM chapters c JOIN books b ON b.id = c.book_id WHERE c.id = ?', [$id]),
            'comment' => Database::one('SELECT id, content, book_id, user_id FROM comments WHERE id = ?', [$id]),
            'user' => Database::one('SELECT u.id, p.nickname FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id WHERE u.id = ?', [$id]),
            default => null,
        };
    }

    public function reports(): void
    {
        Auth::requireLogin();
        $rows = Database::all(
            'SELECT * FROM reports WHERE reporter_id = ? ORDER BY id DESC LIMIT 100',
            [Auth::id()]
        );
        $this->view('user/reports', ['rows' => $rows], 'account');
    }

    public function settings(): void
    {
        Auth::requireLogin();
        $userId = Auth::id();
        // 兼容历史账号：若没有资料行则补建，避免编辑资料时更新 0 行、看起来“保存无效”
        $profile = Database::one('SELECT user_id FROM user_profiles WHERE user_id = ?', [$userId]);
        if (!$profile) {
            $loginName = (string) (Auth::user()['login_name'] ?? '读者');
            Database::insert('user_profiles', [
                'user_id' => $userId,
                'nickname' => mb_substr($loginName, 0, 20, 'UTF-8'),
                'avatar' => null,
                'bio' => null,
                'gender' => null,
                'city' => null,
            ]);
        }
        $user = Database::one(
            'SELECT u.*, p.nickname, p.avatar, p.bio, p.gender, p.city
             FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id
             WHERE u.id = ? LIMIT 1',
            [$userId]
        );
        $settings = Database::one('SELECT * FROM user_settings WHERE user_id = ?', [$userId]);
        $this->view('user/settings', ['userRow' => $user, 'settings' => $settings], 'account');
    }

    public function saveSettings(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $userId = Auth::id();

        $nickname = Request::str('nickname', '', 20);
        $bio = Request::str('bio', '', 255);
        $gender = Request::str('gender', '', 10);
        $city = Request::str('city', '', 40);
        $fontSize = max(14, min(26, Request::int('font_size', 18)));
        $lineHeight = Request::int('line_height', 2);
        if (!in_array($lineHeight, [2, 3, 4], true)) {
            $lineHeight = 2;
        }
        $theme = Request::str('theme', 'light', 12);
        if (!in_array($theme, ['light', 'sepia', 'night'], true)) {
            $theme = 'light';
        }
        $readingMode = Request::str('reading_mode', 'scroll', 12);
        if (!in_array($readingMode, ['scroll', 'paged'], true)) {
            $readingMode = 'scroll';
        }
        if (mb_strlen($nickname, 'UTF-8') < 2) {
            Flash::add('error', '昵称至少 2 个字符。');
            redirect('/user/settings');
        }

        $oldAvatar = (string) (Auth::user()['avatar'] ?? '');
        $avatar = null;
        $file = Request::file('avatar');
        if ($file !== null) {
            try {
                $avatar = UploadService::image($file, 'avatar');
            } catch (\Throwable $e) {
                Flash::add('error', $e->getMessage());
                redirect('/user/settings');
            }
        }

        $now = date('Y-m-d H:i:s');
        $profileData = [
            'nickname' => $nickname,
            'bio' => $bio === '' ? null : $bio,
            'gender' => $gender === '' ? null : $gender,
            'city' => $city === '' ? null : $city,
        ];
        if ($avatar !== null) {
            $profileData['avatar'] = $avatar;
        }
        $profileExists = Database::one('SELECT user_id FROM user_profiles WHERE user_id = ?', [$userId]);
        if ($profileExists) {
            Database::update('user_profiles', $profileData, ['user_id' => $userId]);
        } else {
            Database::insert('user_profiles', array_merge(['user_id' => $userId, 'avatar' => $avatar], $profileData));
        }

        $settingsExists = Database::one('SELECT user_id FROM user_settings WHERE user_id = ?', [$userId]);
        if ($settingsExists) {
            Database::update('user_settings', [
                'font_size' => $fontSize,
                'line_height' => $lineHeight,
                'theme' => $theme,
                'reading_mode' => $readingMode,
                'updated_at' => $now,
            ], ['user_id' => $userId]);
        } else {
            Database::insert('user_settings', [
                'user_id' => $userId,
                'font_size' => $fontSize,
                'line_height' => $lineHeight,
                'theme' => $theme,
                'reading_mode' => $readingMode,
                'updated_at' => $now,
            ]);
        }

        if ($avatar !== null && $oldAvatar !== '' && $oldAvatar !== $avatar) {
            UploadService::delete($oldAvatar);
        }

        Flash::add('success', '账户与阅读偏好已保存。');
        redirect('/user/settings');
    }

    public function changePassword(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $current = (string) Request::post('current_password', '');
        $password = (string) Request::post('new_password', '');
        $confirm = (string) Request::post('confirm_password', '');
        $user = Database::one('SELECT * FROM users WHERE id = ?', [Auth::id()]);
        if (!$user || !password_verify($current, (string) $user['password_hash'])) {
            Flash::add('error', '当前密码不正确。');
            redirect('/user/settings');
        }
        if (mb_strlen($password, 'UTF-8') < 8) {
            Flash::add('error', '新密码至少 8 个字符。');
            redirect('/user/settings');
        }
        if ($password !== $confirm) {
            Flash::add('error', '两次输入的新密码不一致。');
            redirect('/user/settings');
        }
        Database::update('users', [
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'updated_at' => date('Y-m-d H:i:s'),
        ], ['id' => Auth::id()]);
        Flash::add('success', '密码已更新，请使用新密码登录。');
        redirect('/user/settings');
    }

    public function notices(): void
    {
        Auth::requireLogin();
        $rows = Database::all('SELECT * FROM notices WHERE user_id = ? ORDER BY id DESC LIMIT 100', [Auth::id()]);
        $this->view('user/notices', ['rows' => $rows], 'account');
    }

    public function readNotices(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        Database::query('UPDATE notices SET is_read = 1 WHERE user_id = ?', [Auth::id()]);
        Flash::add('success', '通知已全部标记为已读。');
        redirect('/user/notices');
    }

    public function cancelAccount(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $isAdmin = (int) Database::value(
            "SELECT COUNT(*) FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ? AND r.code = 'admin'",
            [Auth::id()]
        );
        if ($isAdmin > 0) {
            Flash::add('error', '站长账号受系统保护，不能自助注销。');
            redirect('/user/settings');
        }
        Database::update('users', ['status' => 'deleting', 'updated_at' => date('Y-m-d H:i:s')], ['id' => Auth::id()]);
        Auth::logout();
        Flash::add('info', '账号注销申请已提交，进入 5 天冷静期。冷静期内无法登录，可联系站长恢复；到期后账号及相关作品、评论、上传文件将被永久删除。');
        redirect('/');
    }

    private function safeBack(string $fallback = '/'): string
    {
        $back = (string) Request::input('back', '');
        if ($back === '' || !str_starts_with($back, '/') || str_starts_with($back, '//') || str_contains($back, '\\')) {
            return $fallback;
        }
        return $back;
    }
}
