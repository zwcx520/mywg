<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Flash;
use App\Core\Request;
use App\Services\ModerationService;
use App\Services\RecycleService;
use App\Services\UploadService;

class AuthorController extends BaseController
{
    public function applyForm(): void
    {
        Auth::requireLogin();
        $author = $this->currentAuthor();
        $hasAuthorRole = Auth::hasRole('author') || Auth::hasRole('admin');
        if ($author && (string) $author['status'] === 'active' && $hasAuthorRole) {
            redirect('/author');
        }
        $application = Database::one(
            'SELECT * FROM author_applications WHERE user_id = ? ORDER BY id DESC LIMIT 1',
            [Auth::id()]
        );
        $this->view('author/apply', ['author' => $author, 'application' => $application], 'account');
    }

    public function apply(): void
    {
        $this->requirePost();
        Auth::requireLogin();
        $author = $this->currentAuthor();
        if ($author) {
            $hasAuthorRole = Auth::hasRole('author') || Auth::hasRole('admin');
            if (!$hasAuthorRole || (string) $author['status'] === 'revoked') {
                Flash::add('error', '你的作家资格已被取消，如需恢复请联系站长。');
                redirect('/author/apply');
            }
            redirect('/author');
        }
        $pending = Database::one("SELECT id FROM author_applications WHERE user_id = ? AND status = 'pending'", [Auth::id()]);
        if ($pending) {
            Flash::add('info', '认证申请正在审核中，请耐心等待。');
            redirect('/author/apply');
        }

        $penName = Request::str('pen_name', '', 40);
        $intro = Request::str('intro', '', 500);
        $realName = Request::str('real_name', '', 40);
        $idNo = Request::str('id_no', '', 32);
        $phone = Request::str('phone', '', 20);
        $material = Request::str('material', '', 255);

        $errors = [];
        if (mb_strlen($penName, 'UTF-8') < 2 || mb_strlen($penName, 'UTF-8') > 20) {
            $errors[] = '笔名长度需为 2-20 个字符。';
        }
        if (!preg_match('/^[\x{4e00}-\x{9fa5}A-Za-z0-9]{2,40}$/u', $penName)) {
            $errors[] = '笔名仅支持中文、字母与数字。';
        }
        if (mb_strlen($realName, 'UTF-8') < 2) {
            $errors[] = '请填写真实姓名。';
        }
        if (!preg_match('/^[0-9Xx]{15,18}$/', $idNo)) {
            $errors[] = '证件号码格式不正确。';
        }
        if ($phone !== '' && !preg_match('/^1[3-9]\d{9}$/', $phone)) {
            $errors[] = '手机号格式不正确。';
        }
        if (Database::one('SELECT id FROM authors WHERE pen_name = ?', [$penName])) {
            $errors[] = '该笔名已被使用。';
        }
        if (Database::one("SELECT id FROM author_applications WHERE pen_name = ? AND status = 'pending'", [$penName])) {
            $errors[] = '该笔名正在审核中。';
        }
        if ($errors !== []) {
            Flash::add('error', implode(' ', $errors));
            redirect('/author/apply');
        }

        $now = date('Y-m-d H:i:s');
        $applicationId = Database::transaction(function () use ($penName, $intro, $realName, $idNo, $phone, $material, $now): int {
            $id = Database::insert('author_applications', [
                'user_id' => Auth::id(),
                'pen_name' => $penName,
                'intro' => $intro === '' ? null : $intro,
                'real_name' => $realName,
                'id_no' => $idNo,
                'phone' => $phone === '' ? null : $phone,
                'material' => $material === '' ? null : $material,
                'status' => 'pending',
                'remark' => null,
                'reviewed_by' => null,
                'reviewed_at' => null,
                'created_at' => $now,
            ]);
            Database::insert('review_tasks', [
                'target_type' => 'author',
                'target_id' => $id,
                'version_no' => 0,
                'priority' => 2,
                'status' => 'waiting',
                'assignee_id' => null,
                'created_at' => $now,
                'handled_at' => null,
            ]);
            $identity = Database::one('SELECT id FROM user_identities WHERE user_id = ?', [Auth::id()]);
            if ($identity) {
                Database::update('user_identities', [
                    'real_name' => $realName,
                    'id_no' => $idNo,
                    'phone' => $phone === '' ? null : $phone,
                    'material' => $material === '' ? null : $material,
                    'status' => 'pending',
                    'remark' => null,
                    'reviewed_by' => null,
                    'reviewed_at' => null,
                ], ['id' => (int) $identity['id']]);
            } else {
                Database::insert('user_identities', [
                    'user_id' => Auth::id(),
                    'real_name' => $realName,
                    'id_no' => $idNo,
                    'phone' => $phone === '' ? null : $phone,
                    'material' => $material === '' ? null : $material,
                    'status' => 'pending',
                    'remark' => null,
                    'reviewed_by' => null,
                    'reviewed_at' => null,
                    'created_at' => $now,
                ]);
            }
            return $id;
        });

        Flash::add('success', '作家认证申请已提交，审核编号 ZJ' . str_pad((string) $applicationId, 6, '0', STR_PAD_LEFT) . '。实名材料仅用于身份核验，审核员不会查看证件原图。');
        redirect('/author/apply');
    }

    public function dashboard(): void
    {
        $author = $this->requireAuthor();
        $authorId = (int) $author['id'];

        $works = Database::all(
            'SELECT b.*, (SELECT COUNT(*) FROM chapters c WHERE c.book_id = b.id) AS chapter_count
             FROM books b WHERE b.author_id = ? AND b.status <> ? ORDER BY b.updated_at DESC LIMIT 4',
            [$authorId, 'deleted']
        );

        $stats = [
            'works' => (int) Database::value("SELECT COUNT(*) FROM books WHERE author_id = ? AND status <> 'deleted'", [$authorId]),
            'published' => (int) Database::value(
                "SELECT COUNT(*) FROM chapters c JOIN books b ON b.id = c.book_id WHERE b.author_id = ? AND b.status <> 'deleted' AND c.status = 'published'",
                [$authorId]
            ),
            'pending' => (int) Database::value(
                "SELECT COUNT(*) FROM review_tasks rt JOIN chapters c ON c.id = rt.target_id JOIN books b ON b.id = c.book_id
                 WHERE rt.target_type = 'chapter' AND rt.status IN ('waiting','assigned') AND b.status <> 'deleted' AND b.author_id = ?",
                [$authorId]
            ),
            'words' => (int) Database::value("SELECT COALESCE(SUM(word_count), 0) FROM books WHERE author_id = ? AND status <> 'deleted'", [$authorId]),
        ];

        $notices = Database::all('SELECT * FROM notices WHERE user_id = ? ORDER BY id DESC LIMIT 4', [Auth::id()]);
        $announcements = Database::all(
            "SELECT * FROM announcements WHERE scope IN ('site','author') AND status = 'published'
             AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at >= NOW())
             ORDER BY id DESC LIMIT 3"
        );

        $this->view('author/dashboard', [
            'author' => $author,
            'works' => $works,
            'stats' => $stats,
            'notices' => $notices,
            'announcements' => $announcements,
        ], 'account');
    }

    public function works(): void
    {
        $author = $this->requireAuthor();
        $rows = Database::all(
            "SELECT b.*, c.name AS category_name,
             (SELECT COUNT(*) FROM chapters ch WHERE ch.book_id = b.id AND ch.status = 'published') AS published_count,
             (SELECT COUNT(*) FROM chapters ch WHERE ch.book_id = b.id) AS chapter_count
             FROM books b LEFT JOIN book_categories c ON c.id = b.category_id
             WHERE b.author_id = ? AND b.status <> 'deleted' ORDER BY b.updated_at DESC",
            [(int) $author['id']]
        );
        $this->view('author/works', ['author' => $author, 'rows' => $rows], 'account');
    }

    public function workCreateForm(): void
    {
        $author = $this->requireAuthor();
        $categories = Database::all('SELECT * FROM book_categories WHERE status = 1 ORDER BY sort ASC, id ASC');
        $tags = Database::all('SELECT * FROM tags WHERE status = 1 ORDER BY id ASC');
        $this->view('author/work_form', [
            'author' => $author,
            'book' => null,
            'categories' => $categories,
            'tags' => $tags,
            'selectedTags' => [],
        ], 'account');
    }

    public function workCreate(): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();

        $title = Request::str('title', '', 80);
        $categoryId = Request::int('category_id');
        $summary = Request::str('summary', '', 1000);
        $copyright = Request::str('copyright_note', '', 255);
        $tagIds = array_values(array_filter(array_map('intval', (array) ($_POST['tags'] ?? []))));

        $errors = [];
        if (mb_strlen($title, 'UTF-8') < 2 || mb_strlen($title, 'UTF-8') > 60) {
            $errors[] = '书名长度需为 2-60 个字符。';
        }
        $category = Database::one('SELECT id FROM book_categories WHERE id = ? AND status = 1', [$categoryId]);
        if (!$category) {
            $errors[] = '请选择有效分类。';
        }
        if (mb_strlen($summary, 'UTF-8') < 20) {
            $errors[] = '简介至少 20 个字符。';
        }
        if ($errors !== []) {
            Flash::add('error', implode(' ', $errors));
            redirect('/author/work/create');
        }

        $now = date('Y-m-d H:i:s');
        $bookCode = $this->generateBookCode();
        $bookId = Database::insert('books', [
            'book_code' => $bookCode,
            'author_id' => (int) $author['id'],
            'category_id' => $categoryId,
            'title' => $title,
            'cover' => null,
            'summary' => $summary,
            'copyright_note' => $copyright === '' ? null : $copyright,
            'status' => 'draft',
            'editor_id' => null,
            'review_note' => null,
            'word_count' => 0,
            'view_count' => 0,
            'favorite_count' => 0,
            'rating' => 0,
            'rating_count' => 0,
            'is_featured' => 0,
            'published_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $this->syncTags($bookId, $tagIds);

        // 封面以作品 ID 命名，重复上传直接覆盖同一文件
        $file = Request::file('cover_file');
        if ($file !== null) {
            try {
                $cover = UploadService::image($file, 'cover', (string) $bookId);
                Database::update('books', ['cover' => $cover], ['id' => $bookId]);
            } catch (\Throwable $e) {
                Flash::add('warning', '作品已创建，但封面保存失败：' . $e->getMessage());
            }
        }

        Flash::add('success', '作品已创建，请完善分卷与章节后提交审核。');
        redirect('/author/work/' . $bookId . '/edit');
    }

    public function workEdit(string $id): void
    {
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);
        $categories = Database::all('SELECT * FROM book_categories WHERE status = 1 ORDER BY sort ASC, id ASC');
        $tags = Database::all('SELECT * FROM tags WHERE status = 1 ORDER BY id ASC');
        $selectedTags = array_map(
            static fn ($row) => (int) $row['tag_id'],
            Database::all('SELECT tag_id FROM book_tag_map WHERE book_id = ?', [(int) $book['id']])
        );
        $volumes = Database::all(
            "SELECT v.*, (SELECT COUNT(*) FROM chapters c WHERE c.volume_id = v.id) AS chapter_count
             FROM volumes v WHERE v.book_id = ? AND v.status <> 'recycle' ORDER BY v.sort ASC, v.id ASC",
            [(int) $book['id']]
        );
        $this->view('author/work_form', [
            'author' => $author,
            'book' => $book,
            'categories' => $categories,
            'tags' => $tags,
            'selectedTags' => $selectedTags,
            'volumes' => $volumes,
        ], 'account');
    }

    public function workUpdate(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);

        $title = Request::str('title', '', 80);
        $categoryId = Request::int('category_id');
        $summary = Request::str('summary', '', 1000);
        $copyright = Request::str('copyright_note', '', 255);
        $cover = (string) ($book['cover'] ?? '');
        $tagIds = array_values(array_filter(array_map('intval', (array) ($_POST['tags'] ?? []))));

        if (mb_strlen($title, 'UTF-8') < 2 || mb_strlen($summary, 'UTF-8') < 20) {
            Flash::add('error', '书名与简介不能为空，简介至少 20 个字符。');
            redirect('/author/work/' . (int) $book['id'] . '/edit');
        }
        $category = Database::one('SELECT id FROM book_categories WHERE id = ? AND status = 1', [$categoryId]);
        if (!$category) {
            Flash::add('error', '请选择有效分类。');
            redirect('/author/work/' . (int) $book['id'] . '/edit');
        }

        $file = Request::file('cover_file');
        if ($file !== null) {
            try {
                $cover = UploadService::image($file, 'cover', (string) $book['id']);
            } catch (\Throwable $e) {
                Flash::add('error', $e->getMessage());
                redirect('/author/work/' . (int) $book['id'] . '/edit');
            }
        } elseif (Request::int('remove_cover') === 1) {
            $cover = '';
        }

        $oldCover = (string) ($book['cover'] ?? '');
        Database::update('books', [
            'title' => $title,
            'category_id' => $categoryId,
            'summary' => $summary,
            'copyright_note' => $copyright === '' ? null : $copyright,
            'cover' => $cover === '' ? null : $cover,
            'updated_at' => date('Y-m-d H:i:s'),
        ], ['id' => (int) $book['id']]);
        $this->syncTags((int) $book['id'], $tagIds);

        // 封面被替换或清空时，同步删除用户上传目录里的旧封面
        if ($oldCover !== '' && $oldCover !== $cover) {
            UploadService::delete($oldCover);
        }

        Flash::add('success', '作品资料已保存。');
        redirect('/author/work/' . (int) $book['id'] . '/edit');
    }

    public function workSubmit(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);

        if (!in_array((string) $book['status'], ['draft', 'rejected'], true)) {
            Flash::add('error', '当前作品状态不能提交审核。');
            redirect('/author/work/' . (int) $book['id'] . '/edit');
        }
        $chapterCount = (int) Database::value('SELECT COUNT(*) FROM chapters WHERE book_id = ? AND status <> ?', [(int) $book['id'], 'recycle']);
        if ($chapterCount <= 0) {
            Flash::add('error', '请至少创建一章内容后再提交作品审核。');
            redirect('/author/work/' . (int) $book['id'] . '/edit');
        }

        $now = date('Y-m-d H:i:s');
        Database::transaction(function () use ($book, $now): void {
            Database::update('books', [
                'status' => 'reviewing',
                'review_note' => null,
                'updated_at' => $now,
            ], ['id' => (int) $book['id']]);
            Database::insert('review_tasks', [
                'target_type' => 'book',
                'target_id' => (int) $book['id'],
                'version_no' => 0,
                'priority' => 2,
                'status' => 'waiting',
                'assignee_id' => null,
                'created_at' => $now,
                'handled_at' => null,
            ]);
        });

        Flash::add('success', '作品已提交审核，审核期间仍可补充章节草稿。');
        redirect('/author/works');
    }

    public function workDelete(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);
        if ((string) $book['status'] === 'reviewing') {
            Flash::add('error', '审核中的作品不能删除。');
            redirect('/author/works');
        }

        Database::transaction(function () use ($book): void {
            Database::update('books', [
                'status' => 'deleted',
                'updated_at' => date('Y-m-d H:i:s'),
            ], ['id' => (int) $book['id']]);
            // 作品删除后，关联的推荐位一并清理
            Database::query('DELETE FROM recommendations WHERE book_id = ?', [(int) $book['id']]);
            // 作品删除后，关联的待审核任务一并结束，避免后台继续显示
            Database::query(
                "UPDATE review_tasks SET status = 'handled', handled_at = ?
                 WHERE status IN ('waiting','assigned')
                   AND ((target_type = 'book' AND target_id = ?)
                        OR (target_type = 'chapter' AND target_id IN (SELECT id FROM chapters WHERE book_id = ?)))",
                [date('Y-m-d H:i:s'), (int) $book['id'], (int) $book['id']]
            );
            Database::insert('recycle_items', [
                'target_type' => 'book',
                'target_id' => (int) $book['id'],
                'title' => $book['title'],
                'owner_id' => Auth::id(),
                'deleted_by' => Auth::id(),
                'deleted_at' => date('Y-m-d H:i:s'),
                'restore_deadline' => date('Y-m-d H:i:s', time() + 30 * 86400),
                'reason' => '作者删除作品',
                'restored_at' => null,
            ]);
        });

        Flash::add('success', '作品已移入回收站，30 天内可恢复。');
        redirect('/author/works');
    }

    public function volumes(string $id): void
    {
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);
        $volumes = Database::all(
            "SELECT v.*, (SELECT COUNT(*) FROM chapters c WHERE c.volume_id = v.id) AS chapter_count
             FROM volumes v WHERE v.book_id = ? AND v.status <> 'recycle' ORDER BY v.sort ASC, v.id ASC",
            [(int) $book['id']]
        );
        $this->view('author/volumes', ['author' => $author, 'book' => $book, 'volumes' => $volumes], 'account');
    }

    public function volumeCreate(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);
        $title = Request::str('title', '', 80);
        if (mb_strlen($title, 'UTF-8') < 1) {
            Flash::add('error', '请填写分卷名称。');
            redirect('/author/work/' . (int) $book['id'] . '/volumes');
        }
        $maxSort = (int) Database::value('SELECT COALESCE(MAX(sort), 0) FROM volumes WHERE book_id = ?', [(int) $book['id']]);
        Database::insert('volumes', [
            'book_id' => (int) $book['id'],
            'title' => $title,
            'sort' => $maxSort + 1,
            'status' => 'public',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        Flash::add('success', '分卷已创建。');
        redirect('/author/work/' . (int) $book['id'] . '/volumes');
    }

    public function volumeUpdate(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $volume = Database::one(
            'SELECT v.* FROM volumes v JOIN books b ON b.id = v.book_id WHERE v.id = ? AND b.author_id = ?',
            [(int) $id, (int) $author['id']]
        );
        if (!$volume) {
            abort(404, '分卷不存在。');
        }
        $title = Request::str('title', '', 80);
        $status = Request::str('status', 'public', 20);
        if (!in_array($status, ['public', 'hidden'], true)) {
            $status = 'public';
        }
        if ($title !== '') {
            Database::update('volumes', ['title' => $title, 'status' => $status], ['id' => (int) $volume['id']]);
            Flash::add('success', '分卷已更新。');
        }
        redirect('/author/work/' . (int) $volume['book_id'] . '/volumes');
    }

    public function volumeDelete(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $volume = Database::one(
            'SELECT v.* FROM volumes v JOIN books b ON b.id = v.book_id WHERE v.id = ? AND b.author_id = ?',
            [(int) $id, (int) $author['id']]
        );
        if (!$volume) {
            abort(404, '分卷不存在。');
        }
        $chapterCount = (int) Database::value('SELECT COUNT(*) FROM chapters WHERE volume_id = ?', [(int) $volume['id']]);
        if ($chapterCount > 0) {
            Flash::add('error', '分卷下仍有章节，无法删除。');
            redirect('/author/work/' . (int) $volume['book_id'] . '/volumes');
        }
        Database::update('volumes', ['status' => 'recycle'], ['id' => (int) $volume['id']]);
        Database::insert('recycle_items', [
            'target_type' => 'volume',
            'target_id' => (int) $volume['id'],
            'title' => $volume['title'],
            'owner_id' => Auth::id(),
            'deleted_by' => Auth::id(),
            'deleted_at' => date('Y-m-d H:i:s'),
            'restore_deadline' => date('Y-m-d H:i:s', time() + 30 * 86400),
            'reason' => '作者删除分卷',
            'restored_at' => null,
        ]);
        Flash::add('success', '分卷已移入回收站。');
        redirect('/author/work/' . (int) $volume['book_id'] . '/volumes');
    }

    public function chapters(string $id): void
    {
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);
        $volumes = Database::all(
            "SELECT * FROM volumes WHERE book_id = ? AND status <> 'recycle' ORDER BY sort ASC, id ASC",
            [(int) $book['id']]
        );
        // 历史数据若存在编号空缺，进入章节管理时自动补齐为 1..N
        $activeCount = (int) Database::value("SELECT COUNT(*) FROM chapters WHERE book_id = ? AND status <> 'recycle'", [(int) $book['id']]);
        $activeMax = (int) Database::value("SELECT COALESCE(MAX(chapter_no), 0) FROM chapters WHERE book_id = ? AND status <> 'recycle'", [(int) $book['id']]);
        if ($activeMax !== $activeCount) {
            RecycleService::resequenceChapters((int) $book['id']);
        }
        $chapters = Database::all(
            "SELECT c.*, v.title AS volume_title,
             (SELECT COUNT(*) FROM review_tasks rt WHERE rt.target_type = 'chapter' AND rt.target_id = c.id AND rt.status IN ('waiting','assigned')) AS review_waiting
             FROM chapters c LEFT JOIN volumes v ON v.id = c.volume_id
             WHERE c.book_id = ? AND c.status <> 'recycle' ORDER BY c.chapter_no ASC",
            [(int) $book['id']]
        );
        $this->view('author/chapters', [
            'author' => $author,
            'book' => $book,
            'volumes' => $volumes,
            'chapters' => $chapters,
        ], 'account');
    }

    public function chapterCreate(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $book = $this->ownedBook((int) $id, (int) $author['id']);
        $title = Request::str('title', '', 120);
        if (mb_strlen($title, 'UTF-8') < 1) {
            Flash::add('error', '请填写章节标题。');
            redirect('/author/work/' . (int) $book['id'] . '/chapters');
        }
        $volumeId = Request::int('volume_id');
        $volume = Database::one('SELECT id FROM volumes WHERE id = ? AND book_id = ?', [$volumeId, (int) $book['id']]);
        if (!$volume) {
            $volume = Database::one('SELECT id FROM volumes WHERE book_id = ? AND status <> ? ORDER BY sort ASC LIMIT 1', [(int) $book['id'], 'recycle']);
            if (!$volume) {
                $volumeId = Database::insert('volumes', [
                    'book_id' => (int) $book['id'],
                    'title' => '第一卷',
                    'sort' => 1,
                    'status' => 'public',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            } else {
                $volumeId = (int) $volume['id'];
            }
        } else {
            $volumeId = (int) $volume['id'];
        }

        $maxNo = (int) Database::value('SELECT COALESCE(MAX(chapter_no), 0) FROM chapters WHERE book_id = ?', [(int) $book['id']]);
        $now = date('Y-m-d H:i:s');
        $chapterId = Database::transaction(function () use ($book, $volumeId, $maxNo, $title, $now): int {
            $id = Database::insert('chapters', [
                'book_id' => (int) $book['id'],
                'volume_id' => $volumeId,
                'chapter_no' => $maxNo + 1,
                'title' => $title,
                'status' => 'draft',
                'is_paid' => 0,
                'price' => 0,
                'trial_percent' => 0,
                'word_count' => 0,
                'read_count' => 0,
                'review_note' => null,
                'published_at' => null,
                'scheduled_at' => null,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
            // 新建章节后统一重排，保证编号 1..N 连续无空缺
            RecycleService::resequenceChapters((int) $book['id']);
            return $id;
        });

        Flash::add('success', '章节已创建，开始写作吧。');
        redirect('/author/chapter/' . $chapterId . '/edit');
    }

    public function chapterEdit(string $id): void
    {
        $author = $this->requireAuthor();
        $chapter = $this->ownedChapter((int) $id, (int) $author['id']);
        $volumes = Database::all(
            "SELECT * FROM volumes WHERE book_id = ? AND status <> 'recycle' ORDER BY sort ASC",
            [(int) $chapter['book_id']]
        );
        $draft = Database::one('SELECT * FROM chapter_drafts WHERE chapter_id = ?', [(int) $chapter['id']]);
        $latestVersion = Database::one(
            'SELECT * FROM chapter_versions WHERE chapter_id = ? ORDER BY version_no DESC LIMIT 1',
            [(int) $chapter['id']]
        );
        $published = Database::one(
            'SELECT * FROM chapter_contents WHERE chapter_id = ? ORDER BY version_no DESC LIMIT 1',
            [(int) $chapter['id']]
        );
        $content = (string) ($draft['content'] ?? ($latestVersion['content'] ?? ($published['content'] ?? '')));

        $versions = Database::all(
            'SELECT version_no, kind, word_count, created_at FROM chapter_versions WHERE chapter_id = ? ORDER BY version_no DESC LIMIT 10',
            [(int) $chapter['id']]
        );
        $waiting = Database::one(
            "SELECT * FROM review_tasks WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned') ORDER BY id DESC LIMIT 1",
            [(int) $chapter['id']]
        );
        $latestReview = Database::one(
            'SELECT * FROM chapter_reviews WHERE chapter_id = ? ORDER BY id DESC LIMIT 1',
            [(int) $chapter['id']]
        );

        $editable = !$waiting && in_array((string) $chapter['status'], ['draft', 'rejected', 'published'], true);

        if (!isset($_SESSION['editor_tokens'])) {
            $_SESSION['editor_tokens'] = [];
        }
        if (empty($_SESSION['editor_tokens'][(int) $chapter['id']])) {
            $_SESSION['editor_tokens'][(int) $chapter['id']] = bin2hex(random_bytes(8));
        }
        $editorToken = (string) $_SESSION['editor_tokens'][(int) $chapter['id']];

        $this->view('author/chapter_edit', [
            'author' => $author,
            'chapter' => $chapter,
            'volumes' => $volumes,
            'content' => $content,
            'versions' => $versions,
            'waiting' => $waiting,
            'latestReview' => $latestReview,
            'editable' => $editable,
            'editorToken' => $editorToken,
        ], 'account');
    }

    public function chapterSave(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $chapter = $this->ownedChapter((int) $id, (int) $author['id']);
        if (!$this->canEditChapter($chapter)) {
            Flash::add('error', '当前章节状态不可编辑。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }

        $title = Request::str('title', '', 120);
        $content = (string) Request::post('content', '');
        $volumeId = Request::int('volume_id');
        $isPaid = Request::int('is_paid') === 1 ? 1 : 0;
        $price = $isPaid === 1 ? min(100, max(0, (float) Request::post('price', 0))) : 0;
        $trial = min(100, max(0, Request::int('trial_percent')));
        $scheduledAt = $this->parseSchedule(Request::str('scheduled_at', '', 30));
        $token = Request::str('editor_token', '', 40);

        if ($title === '' || mb_strlen($content, 'UTF-8') > 300000) {
            Flash::add('error', '章节标题不能为空，正文长度不可超过 30 万字符。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }
        $volume = Database::one('SELECT id FROM volumes WHERE id = ? AND book_id = ?', [$volumeId, (int) $chapter['book_id']]);
        if (!$volume) {
            Flash::add('error', '请选择有效分卷。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }

        $draft = Database::one('SELECT * FROM chapter_drafts WHERE chapter_id = ?', [(int) $chapter['id']]);
        if ($draft && $draft['editor_token'] !== null && $draft['editor_token'] !== '' && $draft['editor_token'] !== $token) {
            Flash::add('error', '检测到另一设备正在编辑该章节，本次保存已生成冲突快照，请先恢复最新版本后再保存。');
            $this->insertSnapshot((int) $chapter['id'], $content, '冲突快照', $token);
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }

        $wordCount = word_count_text($content);
        $now = date('Y-m-d H:i:s');
        Database::transaction(function () use ($chapter, $title, $content, $volumeId, $isPaid, $price, $trial, $scheduledAt, $token, $draft, $wordCount, $now): void {
            Database::update('chapters', [
                'title' => $title,
                'volume_id' => $volumeId,
                'is_paid' => $isPaid,
                'price' => $price,
                'trial_percent' => $trial,
                'scheduled_at' => $scheduledAt,
                'word_count' => $wordCount,
                'updated_at' => $now,
                'status' => $chapter['status'] === 'rejected' ? 'draft' : $chapter['status'],
            ], ['id' => (int) $chapter['id']]);

            if ($draft) {
                Database::update('chapter_drafts', [
                    'content' => $content,
                    'editor_token' => $token,
                    'version_no' => (int) $draft['version_no'] + 1,
                    'updated_at' => $now,
                ], ['chapter_id' => (int) $chapter['id']]);
            } else {
                Database::insert('chapter_drafts', [
                    'chapter_id' => (int) $chapter['id'],
                    'content' => $content,
                    'editor_token' => $token,
                    'version_no' => 1,
                    'updated_at' => $now,
                ]);
            }

            $this->insertSnapshot((int) $chapter['id'], $content, '手动保存', $token);
        });

        Flash::add('success', '草稿已保存。');
        redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
    }

    public function chapterSubmit(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $chapter = $this->ownedChapter((int) $id, (int) $author['id']);
        if (!$this->canEditChapter($chapter)) {
            Flash::add('error', '当前章节不可提交审核。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }

        $waiting = Database::one(
            "SELECT id FROM review_tasks WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned')",
            [(int) $chapter['id']]
        );
        if ($waiting) {
            Flash::add('info', '该章节已有版本在审核队列中。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }

        $title = Request::str('title', '', 120);
        $content = (string) Request::post('content', '');
        $volumeId = Request::int('volume_id');
        $isPaid = Request::int('is_paid') === 1 ? 1 : 0;
        $price = $isPaid === 1 ? min(100, max(0, (float) Request::post('price', 0))) : 0;
        $trial = min(100, max(0, Request::int('trial_percent')));
        $scheduledInput = Request::str('scheduled_at', '', 30);
        $scheduledAt = $this->parseSchedule($scheduledInput);

        if ($title === '') {
            Flash::add('error', '请填写章节标题。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }
        if (word_count_text($content) < 50) {
            Flash::add('error', '正文至少需要 50 个字符才能提交审核。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }
        if ($scheduledInput !== '' && $scheduledAt === null) {
            Flash::add('error', '定时发布时间需晚于当前时间。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }
        $volume = Database::one('SELECT id FROM volumes WHERE id = ? AND book_id = ?', [$volumeId, (int) $chapter['book_id']]);
        if (!$volume) {
            Flash::add('error', '请选择有效分卷。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }
        $book = Database::one('SELECT * FROM books WHERE id = ?', [(int) $chapter['book_id']]);
        if (!$book || !book_is_public((string) $book['status'])) {
            Flash::add('error', '作品尚未通过审核，无法提交章节审核。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }

        $nextVersion = (int) Database::value('SELECT COALESCE(MAX(version_no), 0) FROM chapter_versions WHERE chapter_id = ?', [(int) $chapter['id']]) + 1;
        $wordCount = word_count_text($content);
        $priority = ModerationService::scan($content) === 'high' ? 1 : 2;
        $now = date('Y-m-d H:i:s');
        $newStatus = (string) $chapter['status'] === 'published' ? 'published' : 'pending';

        Database::transaction(function () use ($chapter, $title, $content, $volumeId, $isPaid, $price, $trial, $scheduledAt, $nextVersion, $wordCount, $priority, $now, $newStatus): void {
            Database::insert('chapter_versions', [
                'chapter_id' => (int) $chapter['id'],
                'version_no' => $nextVersion,
                'kind' => 'submit',
                'content' => $content,
                'word_count' => $wordCount,
                'created_by' => Auth::id(),
                'created_at' => $now,
            ]);

            Database::update('chapters', [
                'title' => $title,
                'volume_id' => $volumeId,
                'is_paid' => $isPaid,
                'price' => $price,
                'trial_percent' => $trial,
                'scheduled_at' => $scheduledAt,
                'word_count' => $wordCount,
                'status' => $newStatus,
                'review_note' => null,
                'updated_at' => $now,
            ], ['id' => (int) $chapter['id']]);

            $draft = Database::one('SELECT * FROM chapter_drafts WHERE chapter_id = ?', [(int) $chapter['id']]);
            $draftData = [
                'content' => $content,
                'version_no' => $nextVersion,
                'updated_at' => $now,
            ];
            if ($draft) {
                Database::update('chapter_drafts', $draftData, ['chapter_id' => (int) $chapter['id']]);
            } else {
                Database::insert('chapter_drafts', array_merge($draftData, ['chapter_id' => (int) $chapter['id'], 'editor_token' => null]));
            }

            Database::insert('review_tasks', [
                'target_type' => 'chapter',
                'target_id' => (int) $chapter['id'],
                'version_no' => $nextVersion,
                'priority' => $priority,
                'status' => 'waiting',
                'assignee_id' => null,
                'created_at' => $now,
                'handled_at' => null,
            ]);
        });

        Flash::add('success', '章节已提交审核，审核期间该版本锁定编辑。');
        redirect('/author/work/' . (int) $chapter['book_id'] . '/chapters');
    }

    public function chapterAutosave(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $chapter = $this->ownedChapter((int) $id, (int) $author['id']);
        if (!$this->canEditChapter($chapter)) {
            json_response(['ok' => false, 'message' => '当前章节不可编辑'], 403);
        }

        $content = (string) Request::post('content', '');
        if (word_count_text($content) > 300000) {
            json_response(['ok' => false, 'message' => '正文超出长度限制'], 422);
        }
        $token = Request::str('editor_token', '', 40);
        $draft = Database::one('SELECT * FROM chapter_drafts WHERE chapter_id = ?', [(int) $chapter['id']]);
        $now = date('Y-m-d H:i:s');

        if ($draft && $draft['editor_token'] !== null && $draft['editor_token'] !== '' && $draft['editor_token'] !== $token) {
            $this->insertSnapshot((int) $chapter['id'], $content, '自动保存冲突快照', $token);
            json_response(['ok' => false, 'conflict' => true, 'message' => '检测到其他设备编辑，已保存冲突快照'], 409);
        }

        if ($draft) {
            Database::update('chapter_drafts', [
                'content' => $content,
                'editor_token' => $token === '' ? $draft['editor_token'] : $token,
                'version_no' => (int) $draft['version_no'] + 1,
                'updated_at' => $now,
            ], ['chapter_id' => (int) $chapter['id']]);
        } else {
            Database::insert('chapter_drafts', [
                'chapter_id' => (int) $chapter['id'],
                'content' => $content,
                'editor_token' => $token,
                'version_no' => 1,
                'updated_at' => $now,
            ]);
        }
        $this->insertSnapshot((int) $chapter['id'], $content, '自动保存', $token);

        json_response(['ok' => true, 'saved_at' => $now, 'message' => '自动保存成功']);
    }

    public function chapterRestore(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $chapter = $this->ownedChapter((int) $id, (int) $author['id']);
        if (!$this->canEditChapter($chapter)) {
            Flash::add('error', '当前章节不可恢复历史版本。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }
        $versionNo = Request::int('version_no');
        $version = Database::one('SELECT * FROM chapter_versions WHERE chapter_id = ? AND version_no = ?', [(int) $chapter['id'], $versionNo]);
        if (!$version) {
            Flash::add('error', '找不到该历史版本。');
            redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
        }
        $draft = Database::one('SELECT * FROM chapter_drafts WHERE chapter_id = ?', [(int) $chapter['id']]);
        $now = date('Y-m-d H:i:s');
        if ($draft) {
            Database::update('chapter_drafts', [
                'content' => (string) $version['content'],
                'version_no' => (int) $draft['version_no'] + 1,
                'updated_at' => $now,
            ], ['chapter_id' => (int) $chapter['id']]);
        } else {
            Database::insert('chapter_drafts', [
                'chapter_id' => (int) $chapter['id'],
                'content' => (string) $version['content'],
                'editor_token' => null,
                'version_no' => $versionNo,
                'updated_at' => $now,
            ]);
        }
        $this->insertSnapshot((int) $chapter['id'], (string) $version['content'], '恢复历史版本', '');
        Flash::add('success', '已将版本 v' . $versionNo . ' 恢复到编辑草稿。');
        redirect('/author/chapter/' . (int) $chapter['id'] . '/edit');
    }

    public function chapterDelete(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $chapter = $this->ownedChapter((int) $id, (int) $author['id']);
        if ((string) $chapter['status'] === 'recycle') {
            Flash::add('error', '该章节已在回收站中。');
            redirect('/author/work/' . (int) $chapter['book_id'] . '/chapters');
        }
        $now = date('Y-m-d H:i:s');
        $originalNo = (int) $chapter['chapter_no'];
        Database::transaction(function () use ($chapter, $now, $originalNo): void {
            // 先把章节编号移出正常区间，腾出位置给后续章节补位
            RecycleService::parkChapter((int) $chapter['id']);
            Database::update('chapters', ['status' => 'recycle', 'updated_at' => $now], ['id' => (int) $chapter['id']]);
            Database::query('DELETE FROM schedules WHERE chapter_id = ?', [(int) $chapter['id']]);
            Database::query(
                "UPDATE review_tasks SET status = 'handled', handled_at = ?
                 WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned')",
                [$now, (int) $chapter['id']]
            );
            Database::insert('recycle_items', [
                'target_type' => 'chapter',
                'target_id' => (int) $chapter['id'],
                'title' => $chapter['title'],
                'owner_id' => Auth::id(),
                'deleted_by' => Auth::id(),
                'deleted_at' => $now,
                'restore_deadline' => date('Y-m-d H:i:s', time() + 30 * 86400),
                'reason' => '作者删除章节（原序 ' . $originalNo . '）',
                'restored_at' => null,
            ]);
            // 剩余章节依次前移，编号保持连续
            RecycleService::resequenceChapters((int) $chapter['book_id']);
        });
        Flash::add('success', '章节已移入回收站。');
        redirect('/author/work/' . (int) $chapter['book_id'] . '/chapters');
    }

    public function stats(): void
    {
        $author = $this->requireAuthor();
        $authorId = (int) $author['id'];
        $books = Database::all(
            "SELECT b.id, b.title, b.status, b.word_count, b.view_count, b.favorite_count, b.rating, b.rating_count,
             (SELECT COUNT(*) FROM chapters c WHERE c.book_id = b.id AND c.status = 'published') AS chapter_count,
             (SELECT COALESCE(SUM(c.read_count), 0) FROM chapters c WHERE c.book_id = b.id) AS chapter_reads,
             (SELECT COUNT(*) FROM comments cm WHERE cm.book_id = b.id AND cm.status = 'approved') AS comment_count
             FROM books b WHERE b.author_id = ? AND b.status <> 'deleted' ORDER BY b.updated_at DESC",
            [$authorId]
        );
        $totals = [
            'views' => 0,
            'favorites' => 0,
            'reads' => 0,
            'comments' => 0,
            'words' => 0,
        ];
        foreach ($books as $book) {
            $totals['views'] += (int) $book['view_count'];
            $totals['favorites'] += (int) $book['favorite_count'];
            $totals['reads'] += (int) $book['chapter_reads'];
            $totals['comments'] += (int) $book['comment_count'];
            $totals['words'] += (int) $book['word_count'];
        }
        $this->view('author/stats', ['author' => $author, 'books' => $books, 'totals' => $totals], 'account');
    }

    public function recycle(): void
    {
        $author = $this->requireAuthor();
        $items = Database::all(
            "SELECT * FROM recycle_items WHERE owner_id = ? AND restored_at IS NULL ORDER BY id DESC LIMIT 100",
            [Auth::id()]
        );
        $this->view('author/recycle', ['author' => $author, 'items' => $items], 'account');
    }

    public function recycleRestore(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $item = Database::one('SELECT * FROM recycle_items WHERE id = ? AND owner_id = ? AND restored_at IS NULL', [(int) $id, Auth::id()]);
        if (!$item) {
            abort(404, '回收项不存在。');
        }
        if ($item['restore_deadline'] !== null && strtotime((string) $item['restore_deadline']) < time()) {
            Flash::add('error', '该回收项已超过恢复期限。');
            redirect('/author/recycle');
        }

        $now = date('Y-m-d H:i:s');
        $targetType = (string) $item['target_type'];
        if ($targetType === 'book') {
            Database::update('books', ['status' => 'draft', 'updated_at' => $now], ['id' => (int) $item['target_id']]);
        } elseif ($targetType === 'chapter') {
            Database::update('chapters', ['status' => 'draft', 'updated_at' => $now], ['id' => (int) $item['target_id']]);
            $chapter = Database::one('SELECT id, book_id FROM chapters WHERE id = ?', [(int) $item['target_id']]);
            if ($chapter) {
                RecycleService::restoreChapterAt(
                    (int) $chapter['book_id'],
                    (int) $chapter['id'],
                    RecycleService::parsePosition($item['reason'] ?? null)
                );
            }
        } elseif ($targetType === 'volume') {
            Database::update('volumes', ['status' => 'public'], ['id' => (int) $item['target_id']]);
        }
        Database::update('recycle_items', ['restored_at' => $now], ['id' => (int) $item['id']]);

        Flash::add('success', '回收项已恢复。');
        redirect('/author/recycle');
    }

    /** 作者从回收站彻底删除（真正移除数据） */
    public function recyclePurge(string $id): void
    {
        $this->requirePost();
        $author = $this->requireAuthor();
        $item = Database::one('SELECT * FROM recycle_items WHERE id = ? AND owner_id = ?', [(int) $id, Auth::id()]);
        if (!$item) {
            abort(404, '回收项不存在。');
        }

        $targetId = (int) $item['target_id'];
        $type = (string) $item['target_type'];
        $cover = '';
        try {
            Database::transaction(function () use ($item, $targetId, $type, $author, &$cover): void {
                if ($type === 'book') {
                    $owned = Database::one('SELECT id FROM books WHERE id = ? AND author_id = ?', [$targetId, (int) $author['id']]);
                    if (!$owned) {
                        throw new \RuntimeException('作品不属于当前账号。');
                    }
                    $cover = RecycleService::purgeBook($targetId);
                } elseif ($type === 'chapter') {
                    $owned = Database::one(
                        'SELECT c.id FROM chapters c JOIN books b ON b.id = c.book_id WHERE c.id = ? AND b.author_id = ?',
                        [$targetId, (int) $author['id']]
                    );
                    if (!$owned) {
                        throw new \RuntimeException('章节不属于当前账号。');
                    }
                    RecycleService::purgeChapter($targetId);
                } elseif ($type === 'volume') {
                    $owned = Database::one(
                        'SELECT v.id FROM volumes v JOIN books b ON b.id = v.book_id WHERE v.id = ? AND b.author_id = ?',
                        [$targetId, (int) $author['id']]
                    );
                    if (!$owned) {
                        throw new \RuntimeException('分卷不属于当前账号。');
                    }
                    RecycleService::purgeVolume($targetId);
                }
                Database::query('DELETE FROM recycle_items WHERE id = ?', [(int) $item['id']]);
            });
            if ($cover !== '') {
                UploadService::delete($cover);
            }
            Flash::add('success', '内容已彻底删除。');
        } catch (\Throwable $e) {
            Flash::add('error', '删除失败：' . $e->getMessage());
        }
        redirect('/author/recycle');
    }

    private function canEditChapter(array $chapter): bool
    {
        $waiting = Database::one(
            "SELECT id FROM review_tasks WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned')",
            [(int) $chapter['id']]
        );
        if ($waiting) {
            return false;
        }
        return in_array((string) $chapter['status'], ['draft', 'rejected', 'published'], true);
    }

    private function parseSchedule(string $value): ?string
    {
        if ($value === '') {
            return null;
        }
        $ts = strtotime(str_replace('T', ' ', $value));
        if ($ts === false || $ts < time() + 60) {
            return null;
        }
        return date('Y-m-d H:i:s', $ts);
    }

    private function insertSnapshot(int $chapterId, string $content, string $label, string $token): void
    {
        try {
            Database::insert('chapter_snapshots', [
                'chapter_id' => $chapterId,
                'content' => $content,
                'summary' => mb_substr($label . ' · ' . excerpt($content, 60), 0, 255, 'UTF-8'),
                'version_no' => 0,
                'device' => mb_substr($token, 0, 80),
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $keepId = (int) Database::value(
                'SELECT id FROM chapter_snapshots WHERE chapter_id = ? ORDER BY id DESC LIMIT 1 OFFSET 19',
                [$chapterId]
            );
            if ($keepId > 0) {
                Database::query('DELETE FROM chapter_snapshots WHERE chapter_id = ? AND id < ?', [$chapterId, $keepId]);
            }
        } catch (\Throwable $e) {
            // 快照失败不回滚主流程
        }
    }

    private function syncTags(int $bookId, array $tagIds): void
    {
        Database::query('DELETE FROM book_tag_map WHERE book_id = ?', [$bookId]);
        if ($tagIds === []) {
            return;
        }
        $valid = Database::all(
            'SELECT id FROM tags WHERE status = 1 AND id IN (' . implode(',', array_map('intval', $tagIds)) . ')'
        );
        foreach ($valid as $tag) {
            Database::insert('book_tag_map', ['book_id' => $bookId, 'tag_id' => (int) $tag['id']]);
        }
    }

    private function generateBookCode(): string
    {
        for ($i = 0; $i < 10; $i++) {
            $code = 'B' . date('ymd') . strtoupper(bin2hex(random_bytes(2)));
            if (!Database::one('SELECT id FROM books WHERE book_code = ?', [$code])) {
                return $code;
            }
        }
        return 'B' . date('ymdHis') . random_int(10, 99);
    }
}
