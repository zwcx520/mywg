<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Switches;

class ReviewService
{
    public static function approveBook(int $bookId, int $reviewerId, string $reason = ''): array
    {
        $book = Database::one('SELECT * FROM books WHERE id = ? LIMIT 1', [$bookId]);
        if (!$book) {
            return ['ok' => false, 'message' => '作品不存在'];
        }
        if (!in_array((string) $book['status'], ['reviewing', 'rejected'], true)) {
            return ['ok' => false, 'message' => '当前作品状态不支持审核通过'];
        }

        $now = date('Y-m-d H:i:s');
        Database::transaction(function () use ($bookId, $book, $reviewerId, $reason, $now): void {
            Database::update('books', [
                'status' => 'approved',
                'editor_id' => $reviewerId,
                'review_note' => null,
                'published_at' => $book['published_at'] ?: $now,
                'updated_at' => $now,
            ], ['id' => $bookId]);

            Database::update('volumes', ['status' => 'public'], ['book_id' => $bookId, 'status' => 'draft']);

            Database::insert('book_reviews', [
                'book_id' => $bookId,
                'reviewer_id' => $reviewerId,
                'action' => 'approve',
                'reason' => mb_substr($reason, 0, 255, 'UTF-8'),
                'created_at' => $now,
            ]);

            Database::query(
                "UPDATE review_tasks SET status = 'handled', handled_at = ? WHERE target_type = 'book' AND target_id = ? AND status IN ('waiting','assigned')",
                [$now, $bookId]
            );

            $author = Database::one('SELECT user_id FROM authors WHERE id = ? LIMIT 1', [(int) $book['author_id']]);
            if ($author) {
                notify_user((int) $author['user_id'], '作品审核通过：《' . $book['title'] . '》', '作品已通过审核，现在可以提交章节审核并发布。');
            }
        });

        return ['ok' => true, 'message' => '作品审核已通过'];
    }

    public static function rejectBook(int $bookId, int $reviewerId, string $reason): array
    {
        $book = Database::one('SELECT * FROM books WHERE id = ? LIMIT 1', [$bookId]);
        if (!$book) {
            return ['ok' => false, 'message' => '作品不存在'];
        }
        if ((string) $book['status'] !== 'reviewing') {
            return ['ok' => false, 'message' => '只有审核中的作品可以驳回'];
        }
        $now = date('Y-m-d H:i:s');
        Database::transaction(function () use ($bookId, $book, $reviewerId, $reason, $now): void {
            Database::update('books', [
                'status' => 'rejected',
                'editor_id' => $reviewerId,
                'review_note' => mb_substr($reason, 0, 255, 'UTF-8'),
                'updated_at' => $now,
            ], ['id' => $bookId]);

            Database::insert('book_reviews', [
                'book_id' => $bookId,
                'reviewer_id' => $reviewerId,
                'action' => 'reject',
                'reason' => mb_substr($reason, 0, 255, 'UTF-8'),
                'created_at' => $now,
            ]);

            Database::query(
                "UPDATE review_tasks SET status = 'handled', handled_at = ? WHERE target_type = 'book' AND target_id = ? AND status IN ('waiting','assigned')",
                [$now, $bookId]
            );

            $author = Database::one('SELECT user_id FROM authors WHERE id = ? LIMIT 1', [(int) $book['author_id']]);
            if ($author) {
                notify_user((int) $author['user_id'], '作品审核未通过：《' . $book['title'] . '》', '驳回原因：' . $reason);
            }
        });

        return ['ok' => true, 'message' => '作品已驳回'];
    }

    public static function approveChapter(int $chapterId, int $reviewerId, string $reasonCode = '', string $note = ''): array
    {
        $chapter = Database::one(
            'SELECT c.*, b.status AS book_status, b.title AS book_title, b.author_id
             FROM chapters c JOIN books b ON b.id = c.book_id WHERE c.id = ? LIMIT 1',
            [$chapterId]
        );
        if (!$chapter) {
            return ['ok' => false, 'message' => '章节不存在'];
        }
        if (!book_is_public((string) $chapter['book_status'])) {
            return ['ok' => false, 'message' => '作品尚未通过审核，无法发布章节'];
        }
        if (!in_array((string) $chapter['status'], ['pending', 'published'], true)) {
            return ['ok' => false, 'message' => '当前章节不在待审核状态'];
        }

        $task = Database::one(
            "SELECT * FROM review_tasks WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned') ORDER BY id DESC LIMIT 1",
            [$chapterId]
        );
        if (!$task) {
            return ['ok' => false, 'message' => '找不到待审核任务'];
        }
        $versionNo = (int) $task['version_no'];
        $version = Database::one('SELECT * FROM chapter_versions WHERE chapter_id = ? AND version_no = ? LIMIT 1', [$chapterId, $versionNo]);
        if (!$version) {
            return ['ok' => false, 'message' => '找不到提交审核的正文版本'];
        }

        $now = date('Y-m-d H:i:s');
        $scheduledAt = $chapter['scheduled_at'];
        $futureSchedule = (string) $chapter['status'] === 'pending'
            && $scheduledAt !== null && strtotime((string) $scheduledAt) !== false
            && strtotime((string) $scheduledAt) > time() && Switches::enabled('scheduled_publish');

        if ($futureSchedule) {
            Database::transaction(function () use ($chapterId, $chapter, $reviewerId, $versionNo, $note, $now, $scheduledAt): void {
                Database::update('chapters', [
                    'status' => 'scheduled',
                    'updated_at' => $now,
                ], ['id' => $chapterId]);

                Database::insert('schedules', [
                    'chapter_id' => $chapterId,
                    'run_at' => $scheduledAt,
                    'status' => 'pending',
                    'idempotency_key' => 'chapter:' . $chapterId . ':v' . $versionNo,
                    'executed_at' => null,
                    'note' => '审核通过后进入定时队列',
                ]);

                Database::insert('chapter_reviews', [
                    'chapter_id' => $chapterId,
                    'version_no' => $versionNo,
                    'reviewer_id' => $reviewerId,
                    'action' => 'approve',
                    'reason_code' => 'scheduled',
                    'reason' => '审核通过，定时发布',
                    'note' => mb_substr($note, 0, 500, 'UTF-8'),
                    'created_at' => $now,
                ]);

                Database::query(
                    "UPDATE review_tasks SET status = 'handled', handled_at = ? WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned')",
                    [$now, $chapterId]
                );

                $author = Database::one('SELECT user_id FROM authors WHERE id = ? LIMIT 1', [(int) $chapter['author_id']]);
                if ($author) {
                    notify_user((int) $author['user_id'], '章节审核通过，等待定时发布', '章节《' . $chapter['title'] . '》将在 ' . $scheduledAt . ' 自动发布。');
                }
            });

            return ['ok' => true, 'message' => '审核通过，章节已进入定时发布队列'];
        }

        $publish = PublishService::publishChapter($chapterId, $versionNo);
        if (!($publish['ok'] ?? false)) {
            return $publish;
        }

        Database::transaction(function () use ($chapterId, $reviewerId, $versionNo, $note, $now): void {
            Database::insert('chapter_reviews', [
                'chapter_id' => $chapterId,
                'version_no' => $versionNo,
                'reviewer_id' => $reviewerId,
                'action' => 'approve',
                'reason_code' => 'publish',
                'reason' => '通过并发布',
                'note' => mb_substr($note, 0, 500, 'UTF-8'),
                'created_at' => $now,
            ]);
            Database::query(
                "UPDATE review_tasks SET status = 'handled', handled_at = ? WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned')",
                [$now, $chapterId]
            );
        });

        return ['ok' => true, 'message' => '章节已通过审核并发布'];
    }

    public static function rejectChapter(int $chapterId, int $reviewerId, string $reason): array
    {
        $chapter = Database::one(
            'SELECT c.*, b.author_id FROM chapters c JOIN books b ON b.id = c.book_id WHERE c.id = ? LIMIT 1',
            [$chapterId]
        );
        if (!$chapter) {
            return ['ok' => false, 'message' => '章节不存在'];
        }
        if ((string) $chapter['status'] !== 'pending' && (string) $chapter['status'] !== 'published') {
            return ['ok' => false, 'message' => '当前章节不在待审核状态'];
        }
        $task = Database::one(
            "SELECT * FROM review_tasks WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned') ORDER BY id DESC LIMIT 1",
            [$chapterId]
        );
        $versionNo = $task ? (int) $task['version_no'] : 0;
        $now = date('Y-m-d H:i:s');
        $wasPublished = (string) $chapter['status'] === 'published';

        Database::transaction(function () use ($chapterId, $chapter, $reviewerId, $reason, $versionNo, $now, $wasPublished): void {
            if ($wasPublished) {
                Database::update('chapters', [
                    'review_note' => mb_substr($reason, 0, 255, 'UTF-8'),
                    'updated_at' => $now,
                ], ['id' => $chapterId]);
            } else {
                Database::update('chapters', [
                    'status' => 'rejected',
                    'review_note' => mb_substr($reason, 0, 255, 'UTF-8'),
                    'updated_at' => $now,
                ], ['id' => $chapterId]);
            }

            Database::insert('chapter_reviews', [
                'chapter_id' => $chapterId,
                'version_no' => $versionNo,
                'reviewer_id' => $reviewerId,
                'action' => 'reject',
                'reason_code' => 'content',
                'reason' => mb_substr($reason, 0, 255, 'UTF-8'),
                'note' => null,
                'created_at' => $now,
            ]);

            Database::query(
                "UPDATE review_tasks SET status = 'handled', handled_at = ? WHERE target_type = 'chapter' AND target_id = ? AND status IN ('waiting','assigned')",
                [$now, $chapterId]
            );

            $author = Database::one('SELECT user_id FROM authors WHERE id = ? LIMIT 1', [(int) $chapter['author_id']]);
            if ($author) {
                notify_user((int) $author['user_id'], '章节审核未通过：《' . $chapter['title'] . '》', '驳回原因：' . $reason);
            }
        });

        return ['ok' => true, 'message' => '章节已驳回'];
    }
}
