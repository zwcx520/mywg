<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/**
 * 回收站服务
 *
 * - 章节编号始终保持在作品内连续（1..N），删除/恢复/新建都会重排；
 * - 回收站里的章节编号会被移到安全区间，避免占用 (book_id, chapter_no) 唯一键；
 * - 「彻底删除」会真正移除数据库记录及其全部关联数据。
 */
final class RecycleService
{
    /** 回收站章节占用的大编号起始值 */
    private const PARKED_BASE = 9000000;

    /** 重排时的临时编号起始值 */
    private const TEMP_BASE = 3000000;

    /** 把待删除章节移出正常编号区间 */
    public static function parkChapter(int $chapterId): void
    {
        Database::update('chapters', ['chapter_no' => self::PARKED_BASE + $chapterId], ['id' => $chapterId]);
    }

    /** 将作品内所有未删除章节重排为 1..N 连续编号 */
    public static function resequenceChapters(int $bookId): void
    {
        self::parkRecycled($bookId);
        self::writeNos(self::activeChapterIds($bookId));
    }

    /** 恢复章节：按原序号插回并重排整部作品 */
    public static function restoreChapterAt(int $bookId, int $chapterId, int $position): void
    {
        self::parkRecycled($bookId);
        $ids = array_values(array_filter(
            self::activeChapterIds($bookId),
            static fn (int $id): bool => $id !== $chapterId
        ));
        $position = $position > 0 ? min($position, count($ids) + 1) : count($ids) + 1;
        array_splice($ids, $position - 1, 0, [$chapterId]);
        self::writeNos($ids);
    }

    /** 把历史遗留的回收站章节统一移出正常编号区间，避免重排时唯一键冲突 */
    private static function parkRecycled(int $bookId): void
    {
        Database::query(
            "UPDATE chapters SET chapter_no = ? + id WHERE book_id = ? AND status = 'recycle' AND chapter_no < ?",
            [self::PARKED_BASE, $bookId, self::PARKED_BASE]
        );
    }

    /** 从回收站原因里解析原序号 */
    public static function parsePosition(?string $reason): int
    {
        if ($reason !== null && preg_match('/原序\s*(\d+)/u', $reason, $matches) === 1) {
            return max(1, (int) $matches[1]);
        }
        return 0;
    }

    /** @return int[] */
    private static function activeChapterIds(int $bookId): array
    {
        return array_map(
            static fn (array $row): int => (int) $row['id'],
            Database::all(
                "SELECT id FROM chapters WHERE book_id = ? AND status <> 'recycle' ORDER BY chapter_no ASC, id ASC",
                [$bookId]
            )
        );
    }

    /** @param int[] $ids 按最终顺序排列的章节 ID */
    private static function writeNos(array $ids): void
    {
        // 两阶段更新，避免 (book_id, chapter_no) 唯一键在重排过程中冲突
        foreach ($ids as $index => $chapterId) {
            Database::update('chapters', ['chapter_no' => self::TEMP_BASE + $index], ['id' => $chapterId]);
        }
        foreach ($ids as $index => $chapterId) {
            Database::update('chapters', ['chapter_no' => $index + 1], ['id' => $chapterId]);
        }
    }

    /** 彻底删除作品及其全部关联数据，返回原封面路径（由调用方删除文件） */
    public static function purgeBook(int $bookId): string
    {
        $cover = (string) (Database::value('SELECT cover FROM books WHERE id = ?', [$bookId]) ?? '');
        $chapterIds = self::ids('SELECT id FROM chapters WHERE book_id = ?', [$bookId]);
        $volumeIds = self::ids('SELECT id FROM volumes WHERE book_id = ?', [$bookId]);
        $commentIds = self::ids('SELECT id FROM comments WHERE book_id = ?', [$bookId]);

        if ($commentIds !== []) {
            self::deleteIn('comment_likes', 'comment_id', $commentIds);
        }
        Database::query('DELETE FROM comments WHERE book_id = ?', [$bookId]);

        if ($chapterIds !== []) {
            foreach (['chapter_drafts', 'chapter_contents', 'chapter_snapshots', 'chapter_versions', 'chapter_reviews', 'schedules'] as $table) {
                self::deleteIn($table, 'chapter_id', $chapterIds);
            }
            self::deleteIn('review_tasks', 'target_id', $chapterIds, "target_type = 'chapter' AND");
            self::deleteIn('recycle_items', 'target_id', $chapterIds, "target_type = 'chapter' AND");
        }
        self::deleteIn('review_tasks', 'target_id', [$bookId], "target_type = 'book' AND");
        self::deleteIn('recycle_items', 'target_id', [$bookId], "target_type = 'book' AND");
        if ($volumeIds !== []) {
            self::deleteIn('recycle_items', 'target_id', $volumeIds, "target_type = 'volume' AND");
        }
        if ($commentIds !== []) {
            self::deleteIn('recycle_items', 'target_id', $commentIds, "target_type = 'comment' AND");
        }

        foreach (['book_tag_map', 'book_reviews', 'bookshelf', 'reading_history', 'ratings', 'recommendations', 'ranking_results'] as $table) {
            Database::query('DELETE FROM `' . $table . '` WHERE book_id = ?', [$bookId]);
        }
        Database::query("DELETE FROM stat_daily WHERE dim_type = 'book' AND dim_id = ?", [$bookId]);

        Database::query('DELETE FROM chapters WHERE book_id = ?', [$bookId]);
        Database::query('DELETE FROM volumes WHERE book_id = ?', [$bookId]);
        Database::query('DELETE FROM books WHERE id = ?', [$bookId]);

        return $cover;
    }

    /** 彻底删除章节及其全部关联数据 */
    public static function purgeChapter(int $chapterId): void
    {
        $commentIds = self::ids('SELECT id FROM comments WHERE chapter_id = ?', [$chapterId]);
        if ($commentIds !== []) {
            self::deleteIn('comment_likes', 'comment_id', $commentIds);
            self::deleteIn('recycle_items', 'target_id', $commentIds, "target_type = 'comment' AND");
        }
        Database::query('DELETE FROM comments WHERE chapter_id = ?', [$chapterId]);

        foreach (['chapter_drafts', 'chapter_contents', 'chapter_snapshots', 'chapter_versions', 'chapter_reviews', 'schedules'] as $table) {
            Database::query('DELETE FROM `' . $table . '` WHERE chapter_id = ?', [$chapterId]);
        }
        self::deleteIn('review_tasks', 'target_id', [$chapterId], "target_type = 'chapter' AND");
        self::deleteIn('recycle_items', 'target_id', [$chapterId], "target_type = 'chapter' AND");
        Database::query('DELETE FROM chapters WHERE id = ?', [$chapterId]);
    }

    /** 彻底删除分卷 */
    public static function purgeVolume(int $volumeId): void
    {
        self::deleteIn('recycle_items', 'target_id', [$volumeId], "target_type = 'volume' AND");
        Database::query('DELETE FROM volumes WHERE id = ?', [$volumeId]);
    }

    /** @return int[] */
    private static function ids(string $sql, array $params): array
    {
        return array_map(static fn (array $row): int => (int) $row['id'], Database::all($sql, $params));
    }

    /** @param int[] $ids */
    private static function deleteIn(string $table, string $column, array $ids, string $extra = ''): void
    {
        if ($ids === []) {
            return;
        }
        $marks = implode(', ', array_fill(0, count($ids), '?'));
        Database::query(
            'DELETE FROM `' . $table . '` WHERE ' . $extra . ' `' . $column . '` IN (' . $marks . ')',
            array_values($ids)
        );
    }
}
