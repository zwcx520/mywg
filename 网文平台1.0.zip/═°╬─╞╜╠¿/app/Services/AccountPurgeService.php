<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/**
 * 注销账号到期清理。
 * 用户提交注销后进入 5 天冷静期，冷静期内不可登录，站长可改为 active 恢复；
 * 到期后由后台访问或手动清理触发，永久删除账号及其作品、评论与上传文件。
 */
class AccountPurgeService
{
    /** 冷静期天数 */
    public const COOLDOWN_DAYS = 5;

    /**
     * 清理所有已满冷静期的注销账号。
     * 站长账号（admin 角色）永不删除，避免误删管理账号。
     */
    public static function purgeDue(): array
    {
        $rows = Database::all(
            "SELECT u.id, u.login_name FROM users u
             WHERE u.status = 'deleting'
               AND u.updated_at <= DATE_SUB(NOW(), INTERVAL " . self::COOLDOWN_DAYS . " DAY)
               AND NOT EXISTS (
                   SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id
                   WHERE ur.user_id = u.id AND r.code = 'admin'
               )
             ORDER BY u.id ASC"
        );

        $users = 0;
        $books = 0;
        foreach ($rows as $row) {
            $result = self::purgeUser((int) $row['id'], (string) $row['login_name']);
            if ($result !== null) {
                $users++;
                $books += $result['books'];
            }
        }
        return ['users' => $users, 'books' => $books];
    }

    /**
     * 前台/后台通用：最多每小时执行一次到期清理，避免每次请求都扫表。
     */
    public static function purgeDueThrottled(int $seconds = 3600): array
    {
        $lock = APP_ROOT . '/storage/account_purge.lock';
        if (is_file($lock) && time() - (int) filemtime($lock) < $seconds) {
            return ['users' => 0, 'books' => 0];
        }
        @touch($lock);
        return self::purgeDue();
    }

    /** 冷静期剩余天数（用于后台展示） */
    public static function remainingDays(string $updatedAt): int
    {
        $start = strtotime($updatedAt);
        if ($start === false) {
            return self::COOLDOWN_DAYS;
        }
        $left = self::COOLDOWN_DAYS * 86400 - (time() - $start);
        return max(0, (int) ceil($left / 86400));
    }

    /**
     * 永久删除单个用户及其关联数据与文件。
     */
    public static function purgeUser(int $userId, string $loginName = ''): ?array
    {
        $user = Database::one('SELECT id, login_name FROM users WHERE id = ?', [$userId]);
        if (!$user) {
            return null;
        }
        $loginName = (string) $user['login_name'];

        $authorId = (int) Database::value('SELECT id FROM authors WHERE user_id = ?', [$userId]);

        $bookIds = [];
        if ($authorId > 0) {
            $bookIds = array_map('intval', array_column(
                Database::all('SELECT id FROM books WHERE author_id = ?', [$authorId]),
                'id'
            ));
        }

        $chapterIds = [];
        $covers = [];
        if ($bookIds !== []) {
            $in = self::ids($bookIds);
            $chapterIds = array_map('intval', array_column(
                Database::all("SELECT id FROM chapters WHERE book_id IN ({$in})"),
                'id'
            ));
            $covers = array_map('strval', array_column(
                Database::all("SELECT cover FROM books WHERE id IN ({$in}) AND cover IS NOT NULL AND cover <> ''"),
                'cover'
            ));
        }

        // 本人的评论 + 他人对本人评论的回复 + 作品下的评论
        $ownCommentIds = array_map('intval', array_column(
            Database::all('SELECT id FROM comments WHERE user_id = ?', [$userId]),
            'id'
        ));
        $commentIds = $ownCommentIds;
        if ($ownCommentIds !== []) {
            $commentIds = array_merge($commentIds, array_map('intval', array_column(
                Database::all('SELECT id FROM comments WHERE parent_id IN (' . self::ids($ownCommentIds) . ')'),
                'id'
            )));
        }
        if ($bookIds !== []) {
            $commentIds = array_merge($commentIds, array_map('intval', array_column(
                Database::all('SELECT id FROM comments WHERE book_id IN (' . self::ids($bookIds) . ')'),
                'id'
            )));
        }
        $commentIds = array_values(array_unique($commentIds));

        // 相关举报单（本人提交、针对本人、针对被删内容）
        $reportConds = ['reporter_id = ?', "(target_type = 'user' AND target_id = ?)"];
        $reportParams = [$userId, $userId];
        if ($commentIds !== []) {
            $reportConds[] = "target_type = 'comment' AND target_id IN (" . self::ids($commentIds) . ')';
        }
        if ($bookIds !== []) {
            $reportConds[] = "target_type = 'book' AND target_id IN (" . self::ids($bookIds) . ')';
        }
        if ($chapterIds !== []) {
            $reportConds[] = "target_type = 'chapter' AND target_id IN (" . self::ids($chapterIds) . ')';
        }
        $reportIds = array_map('intval', array_column(
            Database::all('SELECT id FROM reports WHERE (' . implode(' OR ', $reportConds) . ')', $reportParams),
            'id'
        ));

        Database::transaction(static function () use ($userId, $bookIds, $chapterIds, $commentIds, $reportIds, $authorId): void {
            if ($commentIds !== []) {
                Database::query('DELETE FROM comment_likes WHERE comment_id IN (' . self::ids($commentIds) . ')');
            }
            Database::query('DELETE FROM comment_likes WHERE user_id = ?', [$userId]);

            if ($bookIds !== []) {
                Database::query('DELETE FROM comments WHERE book_id IN (' . self::ids($bookIds) . ')');
            }
            if ($commentIds !== []) {
                Database::query('DELETE FROM comments WHERE id IN (' . self::ids($commentIds) . ')');
            }
            Database::query('DELETE FROM comments WHERE user_id = ?', [$userId]);

            if ($reportIds !== []) {
                Database::query('DELETE FROM report_actions WHERE report_id IN (' . self::ids($reportIds) . ')');
                Database::query('DELETE FROM reports WHERE id IN (' . self::ids($reportIds) . ')');
            }

            if ($chapterIds !== []) {
                $cIn = self::ids($chapterIds);
                Database::query("DELETE FROM schedules WHERE chapter_id IN ({$cIn})");
                Database::query("DELETE FROM chapter_drafts WHERE chapter_id IN ({$cIn})");
                Database::query("DELETE FROM chapter_contents WHERE chapter_id IN ({$cIn})");
                Database::query("DELETE FROM chapter_snapshots WHERE chapter_id IN ({$cIn})");
                Database::query("DELETE FROM chapter_versions WHERE chapter_id IN ({$cIn})");
                Database::query("DELETE FROM chapter_reviews WHERE chapter_id IN ({$cIn})");
            }

            if ($commentIds !== []) {
                Database::query('DELETE FROM review_tasks WHERE target_type = \'comment\' AND target_id IN (' . self::ids($commentIds) . ')');
            }
            if ($bookIds !== []) {
                $bIn = self::ids($bookIds);
                Database::query("DELETE FROM book_reviews WHERE book_id IN ({$bIn})");
                Database::query("DELETE FROM book_tag_map WHERE book_id IN ({$bIn})");
                Database::query("DELETE FROM recommendations WHERE book_id IN ({$bIn})");
                Database::query("DELETE FROM ranking_results WHERE book_id IN ({$bIn})");
                Database::query("DELETE FROM volumes WHERE book_id IN ({$bIn})");
                Database::query("DELETE FROM chapters WHERE book_id IN ({$bIn})");
                Database::query("DELETE FROM books WHERE id IN ({$bIn})");

                $taskConds = ["target_type = 'book' AND target_id IN ({$bIn})"];
                if ($chapterIds !== []) {
                    $taskConds[] = "target_type = 'chapter' AND target_id IN (" . self::ids($chapterIds) . ')';
                }
                Database::query('DELETE FROM review_tasks WHERE (' . implode(' OR ', $taskConds) . ')');
            }

            $recycleConds = ['owner_id = ?'];
            $recycleParams = [$userId];
            if ($bookIds !== []) {
                $recycleConds[] = "target_type = 'book' AND target_id IN (" . self::ids($bookIds) . ')';
            }
            if ($chapterIds !== []) {
                $recycleConds[] = "target_type = 'chapter' AND target_id IN (" . self::ids($chapterIds) . ')';
            }
            if ($commentIds !== []) {
                $recycleConds[] = "target_type = 'comment' AND target_id IN (" . self::ids($commentIds) . ')';
            }
            Database::query('DELETE FROM recycle_items WHERE (' . implode(' OR ', $recycleConds) . ')', $recycleParams);

            // 用户侧数据
            foreach ([
                'ratings', 'bookshelf', 'reading_history', 'notices', 'consents',
                'password_resets', 'login_logs', 'user_identities',
                'author_applications', 'user_settings', 'user_profiles', 'user_roles',
            ] as $table) {
                Database::query("DELETE FROM {$table} WHERE user_id = ?", [$userId]);
            }
            if ($authorId > 0) {
                Database::query('DELETE FROM authors WHERE id = ?', [$authorId]);
            }
            Database::query('DELETE FROM users WHERE id = ?', [$userId]);
        });

        // 文件在事务提交后删除：作品封面 + 按登录名归档的整个上传目录
        foreach ($covers as $cover) {
            UploadService::delete($cover);
        }
        UploadService::purgeOwnerFolder($loginName);

        return ['books' => count($bookIds)];
    }

    private static function ids(array $ids): string
    {
        return implode(',', array_map('intval', $ids));
    }
}
