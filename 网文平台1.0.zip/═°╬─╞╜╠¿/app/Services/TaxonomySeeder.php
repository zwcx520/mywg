<?php
declare(strict_types=1);

namespace App\Services;

use PDO;

/**
 * 官方预置分类与标签
 *
 * 单一数据源：安装时自动写入，后台也可一键补充到已安装站点。
 * 全部使用 INSERT IGNORE，按 code 幂等，不会覆盖站长自建内容，也不会改动已有 ID。
 */
class TaxonomySeeder
{
    /**
     * 分类数据：[名称, 编码, 上级编码（顶级为空）, 描述, 排序]
     * 顶级分类排在子分类之前，保证父级先入库。
     *
     * @return array<int, array{0:string,1:string,2:string,3:string,4:int}>
     */
    public static function categories(): array
    {
        return [
            /* ---------- 新增顶级分类 ---------- */
            ['玄幻奇幻', 'xuanhuan', '', '剑气纵横，万族争锋', 100],
            ['武侠仙侠', 'wuxia', '', '江湖夜雨，一剑霜寒', 110],
            ['游戏竞技', 'game', '', '虚拟与现实的交错战场', 120],
            ['体育竞技', 'sports', '', '热血与汗水的赛场', 130],
            ['现实题材', 'reality', '', '生活褶皱里长出的光', 140],
            ['军事战争', 'military', '', '铁血与信仰的轰鸣', 150],
            ['轻小说', 'lightnovel', '', '轻盈日常里的奇想', 160],
            ['二次元', 'acg', '', '纸片世界的浪漫', 170],
            ['短篇故事', 'shortstory', '', '一页之间，一生起落', 180],
            ['灵异恐怖', 'horror', '', '黑暗中窥见未知', 190],
            ['职场商战', 'business', '', '棋盘之上的博弈', 200],
            ['乡村田园', 'pastoral', '', '田园牧歌与人间烟火', 210],
            ['诸天无限', 'infinite-world', '', '万界穿梭，无尽可能', 220],
            ['娱乐明星', 'entertainment', '', '聚光灯下的心动', 230],

            /* ---------- 玄幻奇幻 ---------- */
            ['东方玄幻', 'xuanhuan-east', 'xuanhuan', '剑修、宗门与万族争锋', 1],
            ['异世大陆', 'xuanhuan-continent', 'xuanhuan', '广袤异大陆的冒险史诗', 2],
            ['王朝争霸', 'xuanhuan-dynasty', 'xuanhuan', '铁骑与权谋共逐天下', 3],
            ['高武世界', 'xuanhuan-martial', 'xuanhuan', '一拳破山的武道极限', 4],
            ['克苏鲁神话', 'cthulhu-mythos', 'xuanhuan', '旧日低语与未知恐惧', 5],

            /* ---------- 武侠仙侠 ---------- */
            ['传统武侠', 'wuxia-classic', 'wuxia', '快意恩仇的江湖旧梦', 1],
            ['武侠幻想', 'wuxia-fantasy', 'wuxia', '侠气与奇想交织的江湖', 2],
            ['国术武学', 'wuxia-national', 'wuxia', '拳脚之间的家国热血', 3],
            ['修真文明', 'cultivation', 'wuxia', '以文明为基的修行之路', 4],

            /* ---------- 游戏竞技 ---------- */
            ['电子竞技', 'esports', 'game', '赛场与键盘上的荣耀', 1],
            ['网游世界', 'online-game', 'game', '虚拟世界里的真实情感', 2],
            ['游戏异界', 'game-world', 'game', '开局一个号，闯荡异世界', 3],
            ['无限流', 'infinite', 'game', '轮回副本中的求生与进化', 4],

            /* ---------- 体育竞技 ---------- */
            ['篮球', 'basketball', 'sports', '球场上的热血与友情', 1],
            ['足球', 'football', 'sports', '绿茵场上的荣耀之路', 2],
            ['田径', 'athletics', 'sports', '奔跑与冲刺的青春', 3],
            ['冰雪运动', 'winter-sports', 'sports', '冰雪之上的速度与梦想', 4],

            /* ---------- 现实题材 ---------- */
            ['社会百态', 'reality-society', 'reality', '人间烟火中的冷暖悲欢', 1],
            ['家庭伦理', 'reality-family', 'reality', '屋檐下的爱恨与和解', 2],
            ['行业职场', 'reality-career', 'reality', '真实行业里的成长与博弈', 3],
            ['时代变迁', 'reality-era', 'reality', '大时代下的小人物命运', 4],

            /* ---------- 军事战争 ---------- */
            ['战争幻想', 'military-fantasy', 'military', '架空战场上的铁血荣光', 1],
            ['现代战争', 'military-modern', 'military', '现代战场上的信念与抉择', 2],
            ['谍战特工', 'military-spy', 'military', '暗线之中的智斗与牺牲', 3],
            ['太空军事', 'military-space', 'military', '星海舰队的远征与守护', 4],

            /* ---------- 轻小说 ---------- */
            ['恋爱日常', 'light-romance', 'lightnovel', '轻盈心动的小确幸', 1],
            ['搞笑吐槽', 'light-comedy', 'lightnovel', '一本正经地胡说八道', 2],
            ['校园日常', 'light-campus', 'lightnovel', '教室与社团里的少年感', 3],
            ['异世界轻小说', 'light-isekai', 'lightnovel', '开局一纸召唤书', 4],

            /* ---------- 二次元 ---------- */
            ['同人衍生', 'acg-fanfic', 'acg', '基于原作的二次创作', 1],
            ['原创同人', 'acg-original', 'acg', '自建立世界的角色故事', 2],
            ['动漫幻想', 'acg-anime', 'acg', '动画质感的幻想冒险', 3],
            ['虚拟偶像', 'acg-idol', 'acg', '舞台与应援的闪耀物语', 4],

            /* ---------- 短篇故事 ---------- */
            ['微小说', 'micro-fiction', 'shortstory', '千字之间的情绪爆点', 1],
            ['短篇悬疑', 'short-suspense', 'shortstory', '一口气读完的谜题', 2],
            ['短篇言情', 'short-romance', 'shortstory', '一页心动的短篇爱恋', 3],
            ['散文随笔', 'essay', 'shortstory', '把日子写成温柔的文字', 4],

            /* ---------- 灵异恐怖 ---------- */
            ['灵异神怪', 'horror-supernatural', 'horror', '怪谈与志异的夜色', 1],
            ['惊悚悬疑', 'horror-thriller', 'horror', '步步紧逼的心理恐惧', 2],
            ['民俗恐怖', 'horror-folklore', 'horror', '乡野旧俗里的禁忌', 3],
            ['规则怪谈', 'horror-rules', 'horror', '遵守规则，才能活下去', 4],

            /* ---------- 职场商战 ---------- */
            ['商战职场', 'business-war', 'business', '商场如战场的谋略对局', 1],
            ['都市商战', 'business-urban', 'business', '城市资本里的博弈', 2],
            ['职场成长', 'business-growth', 'business', '从新人到掌舵者', 3],
            ['创业时代', 'business-startup', 'business', '从零开始的商业版图', 4],

            /* ---------- 乡村田园 ---------- */
            ['种田文', 'pastoral-farming', 'pastoral', '一亩三分地的富足人生', 1],
            ['乡村生活', 'pastoral-village', 'pastoral', '节奏缓慢的乡土人情', 2],
            ['年代乡村', 'pastoral-era', 'pastoral', '旧时光里的烟火岁月', 3],
            ['美食日常', 'pastoral-food', 'pastoral', '一粥一饭里的温柔', 4],

            /* ---------- 诸天无限 ---------- */
            ['诸天万界', 'infinite-all', 'infinite-world', '穿梭万界的成长旅程', 1],
            ['无限综漫', 'infinite-anime', 'infinite-world', '综漫世界的力量进阶', 2],
            ['无限恐怖', 'infinite-horror', 'infinite-world', '轮回任务中的生死博弈', 3],
            ['快穿系统', 'infinite-quick', 'infinite-world', '一个系统，万种人生', 4],

            /* ---------- 娱乐明星 ---------- */
            ['明星娱乐圈', 'entertainment-star', 'entertainment', '聚光灯下的爱恨纠葛', 1],
            ['综艺直播', 'entertainment-variety', 'entertainment', '镜头内外的真实人生', 2],
            ['网红主播', 'entertainment-streamer', 'entertainment', '直播间里的小世界', 3],
            ['影视制作', 'entertainment-film', 'entertainment', '幕后的光影与梦想', 4],

            /* ---------- 都市言情（补充子类） ---------- */
            ['现代言情', 'urban-romance', 'urban', '都市中的心动与重逢', 1],
            ['都市生活', 'urban-life', 'urban', '城市日常的烟火气', 2],
            ['豪门世家', 'urban-wealthy', 'urban', '名门之间的爱与博弈', 3],
            ['婚恋情感', 'urban-marriage', 'urban', '婚姻围城里的温柔', 4],

            /* ---------- 古风幻想（补充子类） ---------- */
            ['古代言情', 'ancient-romance', 'ancient', '古意盎然的爱与别离', 1],
            ['宫廷侯爵', 'ancient-noble', 'ancient', '深宅高墙里的权与情', 2],
            ['江湖庙堂', 'ancient-jianghu', 'ancient', '剑影与朝堂之间的抉择', 3],
            ['古典幻想', 'ancient-fantasy', 'ancient', '古风世界里的奇想', 4],

            /* ---------- 悬疑推理（补充子类） ---------- */
            ['刑侦探案', 'mystery-detective', 'mystery', '线索与证据的追索', 1],
            ['逻辑推理', 'mystery-inference', 'mystery', '抽丝剥茧的本格谜题', 2],
            ['犯罪心理', 'mystery-crime', 'mystery', '人性暗面下的罪案', 3],
            ['密室谜案', 'mystery-room', 'mystery', '封闭空间里的真相', 4],

            /* ---------- 青春校园（补充子类） ---------- */
            ['校园言情', 'campus-romance', 'campus', '教室走廊里的心跳', 1],
            ['青春成长', 'campus-growth', 'campus', '少年心事与自我寻找', 2],
            ['热血校园', 'campus-hotblood', 'campus', '社团与赛场上的青春', 3],
            ['校园悬疑', 'campus-suspense', 'campus', '校园阴影下的谜团', 4],

            /* ---------- 历史传奇（补充子类） ---------- */
            ['架空历史', 'history-alternate', 'history', '重构山河的另一种可能', 1],
            ['历史传记', 'history-biography', 'history', '风云人物的一生', 2],
            ['秦汉三国', 'history-ancient', 'history', '铁马金戈的古典时代', 3],
            ['唐宋明清', 'history-dynasty', 'history', '盛世与末路之间', 4],

            /* ---------- 治愈生活（补充子类） ---------- */
            ['生活随笔', 'healing-essay', 'healing', '把平凡过成诗', 1],
            ['萌宠日常', 'healing-pet', 'healing', '毛茸茸的陪伴', 2],
            ['美食治愈', 'healing-food', 'healing', '一餐一饭的安慰', 3],
            ['慢生活', 'healing-slow', 'healing', '慢下来，才看见光', 4],

            /* ---------- 幻想奇缘（补充子类） ---------- */
            ['西幻奇幻', 'fantasy-western', 'fantasy', '剑与魔法的西方幻想', 1],
            ['童话寓言', 'fantasy-fairy', 'fantasy', '写给大人的童话', 2],
            ['幻想冒险', 'fantasy-adventure', 'fantasy', '踏上未知世界的旅程', 3],
            ['神话传说', 'fantasy-myth', 'fantasy', '古老传说中的新生', 4],

            /* ---------- 科幻未来（补充子类） ---------- */
            ['星际科幻', 'scifi-interstellar', 'scifi', '星海之间的远征', 1],
            ['末世废土', 'scifi-wasteland', 'scifi', '文明余烬中的求生', 2],
            ['赛博朋克', 'scifi-cyberpunk', 'scifi', '霓虹与义体之下的人性', 3],
            ['时间旅行', 'scifi-time', 'scifi', '跨越时间的因果', 4],
        ];
    }

    /**
     * 标签数据：[名称, 编码]
     *
     * @return array<int, array{0:string,1:string}>
     */
    public static function tags(): array
    {
        return [
            /* 情感关系 */
            ['虐恋', 'angst'],
            ['破镜重圆', 'reconciliation'],
            ['先婚后爱', 'marriage-first'],
            ['一见钟情', 'love-at-first-sight'],
            ['青梅竹马', 'childhood-sweethearts'],
            ['双向暗恋', 'mutual-crush'],
            ['追妻火葬场', 'chase-wife'],
            ['极限拉扯', 'push-pull'],
            ['势均力敌', 'equals'],
            ['甜虐交织', 'sweet-angst'],
            ['白月光', 'white-moonlight'],
            ['替身', 'substitute'],
            ['契约恋爱', 'contract-love'],
            ['网恋', 'online-love'],
            ['年龄差', 'age-gap'],
            ['姐弟恋', 'older-sister'],
            ['久别重逢', 'reunion'],
            ['暗恋成真', 'crush-come-true'],
            ['慢热', 'slow-burn'],
            ['沙雕甜文', 'silly-sweet'],
            ['校园暗恋', 'campus-crush'],
            ['青春疼痛', 'youth-pain'],

            /* 人物设定 */
            ['男主视角', 'male-pov'],
            ['女主视角', 'female-pov'],
            ['多视角', 'multi-pov'],
            ['反派主角', 'villain-lead'],
            ['强大女主', 'strong-heroine'],
            ['天才主角', 'genius'],
            ['废柴逆袭', 'underdog'],
            ['扮猪吃虎', 'hidden-power'],
            ['双男主', 'dual-male'],
            ['双女主', 'dual-female'],
            ['大女主', 'big-heroine'],
            ['群像剧', 'ensemble-drama'],

            /* 世界观与题材 */
            ['东方玄幻', 'eastern-fantasy'],
            ['西幻', 'western-fantasy'],
            ['修真', 'cultivation-tag'],
            ['仙侠', 'xianxia-tag'],
            ['武侠', 'wuxia-tag'],
            ['末日', 'apocalypse'],
            ['末世', 'wasteland'],
            ['赛博朋克', 'cyberpunk'],
            ['星际科幻', 'space-scifi'],
            ['未来世界', 'future-world'],
            ['平行世界', 'parallel-world'],
            ['异世界', 'isekai'],
            ['穿越古代', 'ancient-travel'],
            ['现代穿越', 'modern-travel'],
            ['古代背景', 'ancient-setting'],
            ['民国', 'republic-era'],
            ['架空历史', 'alternate-history'],
            ['现实向', 'realistic'],
            ['职场', 'workplace'],
            ['娱乐圈', 'entertainment-tag'],
            ['古代宫廷', 'palace-tag'],
            ['江湖', 'jianghu'],
            ['都市', 'urban-tag'],
            ['乡村', 'countryside'],
            ['异兽', 'exotic-beast'],
            ['魔法', 'magic'],
            ['超能力', 'superpower'],
            ['神怪', 'supernatural'],
            ['灵异', 'paranormal'],
            ['恐怖', 'horror-tag'],
            ['克苏鲁', 'cthulhu-tag'],
            ['无限流', 'infinite-tag'],
            ['诸天', 'all-worlds'],
            ['快穿', 'quick-travel'],
            ['系统', 'system'],
            ['位面', 'plane'],
            ['虚拟游戏', 'virtual-game'],
            ['全息', 'holographic'],
            ['机甲', 'mecha'],
            ['星际战争', 'star-war'],
            ['末世求生', 'survival'],
            ['废土', 'wasteland-tag'],
            ['时间循环', 'time-loop'],
            ['时空穿梭', 'time-shift'],

            /* 剧情与节奏 */
            ['复仇', 'revenge'],
            ['打脸', 'face-slap'],
            ['逆袭', 'counterattack'],
            ['权谋宫斗', 'palace-scheme'],
            ['悬疑探案', 'detective'],
            ['推理', 'inference'],
            ['犯罪', 'crime'],
            ['密室锁凶', 'locked-room'],
            ['战争', 'war'],
            ['谍战', 'spy'],
            ['商战', 'business-war'],
            ['经营', 'management'],
            ['种田', 'farming'],
            ['基建', 'infrastructure'],
            ['美食', 'food'],
            ['萌宠', 'pets'],
            ['治愈系', 'healing-type'],
            ['日常', 'daily'],
            ['轻松搞笑', 'comedy'],
            ['沙雕', 'funny'],
            ['热血', 'hot-blooded'],
            ['燃', 'inspiring'],
            ['虐心', 'heartbreak'],
            ['催泪', 'tearjerker'],
            ['温馨', 'warm'],
            ['爽文', 'power-fantasy'],
            ['极限生存', 'survival-extreme'],
            ['逃生', 'escape'],
            ['成长流', 'growth-tag'],
            ['升级', 'level-up'],
            ['金手指', 'golden-finger'],
            ['无敌', 'invincible'],
            ['热血战斗', 'battle'],
            ['慢生活', 'slow-life'],

            /* 人物关系 */
            ['师徒', 'master-disciple'],
            ['兄妹', 'siblings'],
            ['敌人变情人', 'enemies-to-lovers'],
            ['欢喜冤家', 'bickering-lovers'],
            ['宿敌', 'nemesis'],
            ['双向救赎', 'mutual-redemption'],
            ['救赎', 'redemption'],
            ['陪伴', 'companionship'],
            ['守护', 'protection'],

            /* 读者倾向 */
            ['女频', 'female-channel'],
            ['男频', 'male-channel'],
            ['宠文', 'pamper'],
        ];
    }

    /**
     * 写入预置分类与标签（幂等）。
     *
     * @return array{categories:int, tags:int}
     */
    public static function run(?PDO $pdo = null): array
    {
        $pdo = $pdo ?? \App\Core\Database::pdo();
        $now = date('Y-m-d H:i:s');

        $findCategory = $pdo->prepare('SELECT id FROM book_categories WHERE code = ? LIMIT 1');
        $insertCategory = $pdo->prepare(
            'INSERT IGNORE INTO book_categories (parent_id, name, code, description, sort, status, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)'
        );

        $addedCategories = 0;
        $map = [];
        foreach (self::categories() as $row) {
            [$name, $code, $parentCode, $description, $sort] = $row;

            $parentId = 0;
            if ($parentCode !== '') {
                if (!isset($map[$parentCode]) || $map[$parentCode] === 0) {
                    $findCategory->execute([$parentCode]);
                    $found = $findCategory->fetchColumn();
                    $map[$parentCode] = $found === false ? 0 : (int) $found;
                }
                $parentId = $map[$parentCode];
            }

            $insertCategory->execute([$parentId, $name, $code, $description, $sort, $now]);
            if ($insertCategory->rowCount() > 0) {
                $addedCategories++;
            }

            if (!isset($map[$code]) || $map[$code] === 0) {
                $findCategory->execute([$code]);
                $found = $findCategory->fetchColumn();
                $map[$code] = $found === false ? 0 : (int) $found;
            }
        }

        $insertTag = $pdo->prepare('INSERT IGNORE INTO tags (name, code, status, created_at) VALUES (?, ?, 1, ?)');
        $addedTags = 0;
        foreach (self::tags() as [$name, $code]) {
            $insertTag->execute([$name, $code, $now]);
            if ($insertTag->rowCount() > 0) {
                $addedTags++;
            }
        }

        return ['categories' => $addedCategories, 'tags' => $addedTags];
    }
}
