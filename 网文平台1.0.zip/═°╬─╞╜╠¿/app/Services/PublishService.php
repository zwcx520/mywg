<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Switches;

class PublishService
{
    public static function publishChapter(int $chapterId, int $submitVersionNo): array
    {
        $chapter = Database::one('SELECT * FROM chapters WHERE id = ? LIMIT 1', [$chapterId]);
        if (!$chapter) {
            return ['ok' => false, 'message' => '章节不存在'];
        }

        $version = Database::one(
            'SELECT * FROM chapter_versions WHERE chapter_id = ? AND version_no = ? LIMIT 1',
            [$chapterId, $submitVersionNo]
        );
        if (!$version) {
            return ['ok' => false, 'message' => '找不到待发布的审核版本'];
        }

        $book = Database::one('SELECT * FROM books WHERE id = ? LIMIT 1', [(int) $chapter['book_id']]);
        if (!$book) {
            return ['ok' => false, 'message' => '作品不存在'];
        }
        if (!book_is_public((string) $book['status'])) {
            return ['ok' => false, 'message' => '作品尚未通过审核，章节无法发布'];
        }

        try {
            $result = Database::transaction(function () use ($chapter, $chapterId, $version, $book): array {
                $maxVersion = (int) Database::value('SELECT COALESCE(MAX(version_no), 0) FROM chapter_versions WHERE chapter_id = ?', [$chapterId]);
                $publishVersionNo = $maxVersion + 1;
                $now = date('Y-m-d H:i:s');
                $wordCount = word_count_text((string) $version['content']);

                Database::insert('chapter_versions', [
                    'chapter_id' => $chapterId,
                    'version_no' => $publishVersionNo,
                    'kind' => 'publish',
                    'content' => (string) $version['content'],
                    'word_count' => $wordCount,
                    'created_by' => null,
                    'created_at' => $now,
                ]);

                Database::insert('chapter_contents', [
                    'chapter_id' => $chapterId,
                    'version_no' => $publishVersionNo,
                    'content' => (string) $version['content'],
                    'word_count' => $wordCount,
                    'checksum' => md5((string) $version['content']),
                    'created_at' => $now,
                ]);

                Database::update('chapters', [
                    'status' => 'published',
                    'word_count' => $wordCount,
                    'published_at' => $now,
                    'scheduled_at' => null,
                    'review_note' => null,
                    'updated_at' => $now,
                ], ['id' => $chapterId]);

                Database::query(
                    "UPDATE schedules SET status = 'done', executed_at = ? WHERE chapter_id = ? AND status = 'pending'",
                    [$now, $chapterId]
                );

                $totalWords = (int) Database::value(
                    "SELECT COALESCE(SUM(word_count), 0) FROM chapters WHERE book_id = ? AND status = 'published'",
                    [(int) $book['id']]
                );

                $bookData = [
                    'word_count' => $totalWords,
                    'updated_at' => $now,
                ];
                if (!in_array((string) $book['status'], ['paused', 'finished'], true)) {
                    $bookData['status'] = 'serializing';
                }
                Database::update('books', $bookData, ['id' => (int) $book['id']]);

                $author = Database::one('SELECT user_id FROM authors WHERE id = ? LIMIT 1', [(int) $book['author_id']]);
                if ($author) {
                    notify_user((int) $author['user_id'], '章节已发布：《' . $chapter['title'] . '》', '你的章节已通过审核并发布。');
                }

                return ['ok' => true, 'message' => '章节发布成功', 'version_no' => $publishVersionNo];
            });
            return $result;
        } catch (\Throwable $e) {
            return ['ok' => false, 'message' => '发布失败：' . $e->getMessage()];
        }
    }

    public static function runDueSchedules(): array
    {
        if (!Switches::enabled('scheduled_publish')) {
            return ['ok' => true, 'published' => 0, 'message' => '定时发布开关关闭，任务跳过'];
        }

        $rows = Database::all(
            "SELECT s.*, c.status AS chapter_status FROM schedules s JOIN chapters c ON c.id = s.chapter_id
             WHERE s.status = 'pending' AND s.run_at <= NOW() AND c.status = 'scheduled' LIMIT 50"
        );

        $published = 0;
        foreach ($rows as $row) {
            $chapterId = (int) $row['chapter_id'];
            $versionNo = (int) Database::value(
                "SELECT MAX(version_no) FROM chapter_versions WHERE chapter_id = ? AND kind = 'submit'",
                [$chapterId]
            );
            if ($versionNo <= 0) {
                Database::query("UPDATE schedules SET status = 'failed', executed_at = ?, note = ? WHERE id = ?", [
                    date('Y-m-d H:i:s'), '找不到审核版本', (int) $row['id'],
                ]);
                continue;
            }
            $result = self::publishChapter($chapterId, $versionNo);
            if (($result['ok'] ?? false) === true) {
                $published++;
            }
        }

        return ['ok' => true, 'published' => $published, 'message' => '定时任务执行完成'];
    }
}
