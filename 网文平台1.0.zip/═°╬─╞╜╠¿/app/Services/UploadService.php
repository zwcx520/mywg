<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;

class UploadService
{
    /**
     * 保存用户上传的图片（覆盖模式）。
     * 所有用户上传的文件统一存放在 uploads/{登录名}/ 下，便于按用户归档、展示与删除。
     * 文件名由用途前缀 + 可选业务标识组成（avatar / cover_12 / logo），
     * 同一对象重复上传会直接覆盖同名文件，避免产生旧图残留。
     * 若扩展名发生变化，会先清理同前缀的旧文件。
     */
    public static function image(array $file, string $type = 'image', ?string $identity = null): string
    {
        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            throw new \RuntimeException('图片超过服务器允许的上传大小（当前 upload_max_filesize = ' . ini_get('upload_max_filesize') . '），请调整 php.ini');
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('文件上传失败，错误码：' . $error);
        }
        if ((int) ($file['size'] ?? 0) > 20 * 1024 * 1024) {
            throw new \RuntimeException('图片大小不能超过 20MB');
        }

        $tmp = (string) ($file['tmp_name'] ?? '');
        $info = @getimagesize($tmp);
        if ($info === false) {
            throw new \RuntimeException('上传文件不是有效图片');
        }

        $mime = (string) ($info['mime'] ?? '');
        $allowed = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
        ];
        if (!isset($allowed[$mime])) {
            throw new \RuntimeException('仅支持 JPG、PNG、WEBP、GIF 图片');
        }

        $owner = self::ownerFolder();
        $dir = APP_ROOT . '/uploads/' . $owner;
        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new \RuntimeException('无法创建上传目录');
        }

        $type = preg_replace('/[^a-z0-9_]/', '', strtolower($type)) ?: 'image';
        $identity = preg_replace('/[^a-z0-9_]/', '', strtolower((string) $identity)) ?? '';
        $prefix = $type . ($identity !== '' ? '_' . $identity : '');
        $name = $prefix . '.' . $allowed[$mime];
        $target = $dir . '/' . $name;

        // 覆盖：清理同用途、旧扩展名的历史文件（保留本次目标文件）
        foreach (glob($dir . '/' . $prefix . '.*') ?: [] as $old) {
            if (is_file($old) && $old !== $target) {
                @unlink($old);
            }
        }

        if (!move_uploaded_file($tmp, $target)) {
            throw new \RuntimeException('保存图片失败');
        }

        return $owner . '/' . $name;
    }

    /**
     * 当前用户的上传目录名：以登录名为准，去掉文件系统不安全字符。
     */
    public static function ownerFolder(?string $loginName = null): string
    {
        if ($loginName === null) {
            $user = Auth::user();
            $loginName = (string) ($user['login_name'] ?? '');
        }
        $safe = preg_replace('/[^\p{L}\p{N}_-]+/u', '', trim($loginName));
        if (!is_string($safe) || $safe === '') {
            return 'guest';
        }
        return $safe;
    }

    /**
     * 删除某个用户的上传目录（注销账号时使用）。
     */
    public static function purgeOwnerFolder(string $loginName): void
    {
        $owner = self::ownerFolder($loginName);
        if ($owner === '' || $owner === 'guest') {
            return;
        }
        $dir = APP_ROOT . '/uploads/' . $owner;
        if (!is_dir($dir)) {
            return;
        }
        foreach (glob($dir . '/*') ?: [] as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
        @rmdir($dir);
    }

    /**
     * 删除上传文件。
     * 统一入口：仅允许删除 uploads 目录内的文件，删除后顺带清理空目录。
     */
    public static function delete(?string $path): void
    {
        $path = trim((string) $path);
        if ($path === '' || preg_match('#^(https?:)?//#i', $path) || str_starts_with($path, 'data:')) {
            return;
        }

        $path = str_replace('\\', '/', $path);
        if (str_contains($path, '..')) {
            return;
        }

        $base = realpath(APP_ROOT . '/uploads');
        if ($base === false) {
            return;
        }
        $base = rtrim(str_replace('\\', '/', $base), '/');

        $absolute = $base . '/' . ltrim($path, '/');
        if (!is_file($absolute)) {
            return;
        }

        $real = realpath($absolute);
        if ($real === false) {
            return;
        }
        $real = str_replace('\\', '/', $real);
        if (!str_starts_with($real, $base . '/')) {
            return;
        }

        @unlink($real);

        // 清理空的用户文件夹（保留 uploads 根目录）
        $dir = dirname($real);
        if ($dir !== $base && is_dir($dir)) {
            $items = array_diff(scandir($dir) ?: [], ['.', '..']);
            if ($items === []) {
                @rmdir($dir);
            }
        }
    }
}
