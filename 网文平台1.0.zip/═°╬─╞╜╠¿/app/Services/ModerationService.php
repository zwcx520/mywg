<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

class ModerationService
{
    private static ?array $words = null;

    public static function scan(string $text): ?string
    {
        if (self::$words === null) {
            self::$words = Database::all('SELECT word, level FROM sensitive_words');
        }
        $level = null;
        foreach (self::$words as $row) {
            $word = (string) $row['word'];
            if ($word === '') {
                continue;
            }
            if (mb_stripos($text, $word, 0, 'UTF-8') !== false) {
                if ((string) $row['level'] === 'high') {
                    return 'high';
                }
                $level = 'low';
            }
        }
        return $level;
    }
}
