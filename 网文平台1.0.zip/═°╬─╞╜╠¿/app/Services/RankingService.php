<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

class RankingService
{
    public static function compute(string $code, int $categoryId = 0, int $limit = 20): array
    {
        $ranking = Database::one('SELECT * FROM rankings WHERE code = ? AND status = 1 LIMIT 1', [$code]);
        if (!$ranking) {
            $ranking = Database::one("SELECT * FROM rankings WHERE code = 'total' LIMIT 1");
            $code = 'total';
        }
        if (!$ranking) {
            return ['ranking' => null, 'books' => []];
        }

        $type = (string) $ranking['type'];
        $minRating = (int) $ranking['min_rating_count'];
        $where = "b.status IN ('approved','serializing','paused','finished')";
        $params = [];

        if ($categoryId > 0) {
            $where .= ' AND (b.category_id = ? OR b.category_id IN (SELECT id FROM book_categories WHERE parent_id = ?))';
            $params[] = $categoryId;
            $params[] = $categoryId;
        }

        if ($type === 'new') {
            $where .= ' AND b.published_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
        }
        if ($type === 'finished') {
            $where .= " AND b.status = 'finished'";
        }
        if ($type === 'rating') {
            $where .= ' AND b.rating_count >= ?';
            $params[] = $minRating;
        }

        $order = match ($type) {
            'favorite' => 'b.favorite_count DESC, b.view_count DESC',
            'read' => 'b.view_count DESC, b.favorite_count DESC',
            'new' => 'b.published_at DESC, b.id DESC',
            'finished' => 'b.rating DESC, b.rating_count DESC',
            'rating' => 'b.rating DESC, b.rating_count DESC',
            default => '(b.view_count + b.favorite_count * 3 + b.rating_count * 2) DESC, b.updated_at DESC',
        };

        $scoreExpr = match ($type) {
            'favorite' => 'b.favorite_count',
            'read' => 'b.view_count',
            'new' => 'UNIX_TIMESTAMP(COALESCE(b.published_at, b.created_at))',
            'rating', 'finished' => 'b.rating',
            default => '(b.view_count + b.favorite_count * 3 + b.rating_count * 2)',
        };

        $params[] = max(1, min(100, $limit));
        $sql = "SELECT b.*, a.pen_name, c.name AS category_name, ({$scoreExpr}) AS rank_score
                FROM books b
                JOIN authors a ON a.id = b.author_id
                LEFT JOIN book_categories c ON c.id = b.category_id
                WHERE {$where}
                ORDER BY {$order}
                LIMIT ?";

        $books = Database::all($sql, $params);
        return ['ranking' => $ranking, 'books' => $books];
    }

    public static function refresh(int $rankingId): array
    {
        $ranking = Database::one('SELECT * FROM rankings WHERE id = ? LIMIT 1', [$rankingId]);
        if (!$ranking) {
            return ['ok' => false, 'message' => '榜单不存在'];
        }
        $computed = self::compute((string) $ranking['code'], 0, 20);
        $date = date('Y-m-d');
        $now = date('Y-m-d H:i:s');

        Database::transaction(function () use ($rankingId, $computed, $date, $now): void {
            Database::query('DELETE FROM ranking_results WHERE ranking_id = ? AND period_date = ?', [$rankingId, $date]);
            $position = 1;
            foreach ($computed['books'] as $book) {
                Database::insert('ranking_results', [
                    'ranking_id' => $rankingId,
                    'period_date' => $date,
                    'book_id' => (int) $book['id'],
                    'score' => round((float) $book['rank_score'], 2),
                    'position' => $position,
                    'created_at' => $now,
                ]);
                $position++;
            }
        });

        return ['ok' => true, 'message' => '榜单快照已刷新，共 ' . count($computed['books']) . ' 部作品'];
    }

    public static function latestResults(int $rankingId, int $limit = 20): array
    {
        $date = Database::value('SELECT MAX(period_date) FROM ranking_results WHERE ranking_id = ?', [$rankingId]);
        if (!$date) {
            return [];
        }
        return Database::all(
            "SELECT rr.position, rr.score, b.*, a.pen_name
             FROM ranking_results rr JOIN books b ON b.id = rr.book_id JOIN authors a ON a.id = b.author_id
             WHERE rr.ranking_id = ? AND rr.period_date = ?
             ORDER BY rr.position ASC LIMIT ?",
            [$rankingId, $date, $limit]
        );
    }
}
