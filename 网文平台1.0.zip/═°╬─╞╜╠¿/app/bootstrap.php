<?php
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require __DIR__ . '/helpers.php';

App\Core\Config::load(APP_ROOT . '/config/config.php');

date_default_timezone_set((string) App\Core\Config::get('timezone', 'Asia/Shanghai'));

$logDir = APP_ROOT . '/storage/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0775, true);
}

if (App\Core\Config::get('debug')) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', $logDir . '/php-error.log');
}

try {
    App\Core\Database::init((array) App\Core\Config::get('db', []));
} catch (\Throwable $e) {
    error_log('数据库连接失败：' . $e->getMessage());
    if (PHP_SAPI === 'cli') {
        throw $e;
    }
    http_response_code(500);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>数据库连接失败</title>'
        . '<style>body{font-family:system-ui,-apple-system,"Microsoft YaHei",sans-serif;background:#fbf7f2;color:#3c3340;padding:48px;line-height:1.9}'
        . '.box{max-width:720px;margin:0 auto;background:#fff;border:1px solid #eadfe4;border-radius:18px;padding:32px 36px;box-shadow:0 20px 60px rgba(90,60,80,.08)}'
        . 'h1{font-size:22px;margin:0 0 6px}p{margin:8px 0;font-size:14px}code{background:#f6eef1;padding:2px 7px;border-radius:6px;font-size:13px}'
        . 'ul{font-size:13px;color:#6d6272}</style></head><body><div class="box">'
        . '<h1>数据库连接失败</h1>'
        . '<p>程序已读取 <code>config/config.php</code>，但无法连接 MySQL。</p>'
        . '<ul><li>检查数据库地址、端口、库名、用户名与密码是否正确；</li>'
        . '<li>确认 MySQL 服务已启动，且数据库 <code>utf8mb4</code> 可用；</li>'
        . '<li>如密码含特殊字符，请确认写入配置时未被转义破坏；</li>'
        . '<li>详细错误已写入 <code>storage/logs/php-error.log</code>。</li></ul>'
        . '<p style="color:#a4647c;font-size:13px;">修正 <code>config/config.php</code> 的 db 配置后刷新本页即可，无需重新安装。</p>'
        . '</div></body></html>';
    exit;
}

if (PHP_SAPI !== 'cli' && session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('moyun_session');
    session_start();
}
