<?php
declare(strict_types=1);

use App\Core\Auth;
use App\Core\Config;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Settings;
use App\Core\UA;
use App\Core\View;

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * 生成站内地址。
 * url_mode=query（默认）时不依赖 Nginx/Apache 伪静态，统一输出为 index.php?r=/path；
 * 配置好伪静态后可把 config 中 url_mode 改为 pretty。
 */
function url(string $path = '', array $query = []): string
{
    if (preg_match('#^https?://#i', $path)) {
        if ($query !== []) {
            $path .= (str_contains($path, '?') ? '&' : '?') . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
        }
        return $path;
    }

    $base = rtrim((string) Config::get('base_url', ''), '/');

    $fragment = '';
    if (($hashPos = strpos($path, '#')) !== false) {
        $fragment = substr($path, $hashPos);
        $path = substr($path, 0, $hashPos);
    }

    $embedded = [];
    if (($pos = strpos($path, '?')) !== false) {
        parse_str(substr($path, $pos + 1), $embedded);
        $path = substr($path, 0, $pos);
    }
    $path = '/' . ltrim($path, '/');
    $path = rtrim($path, '/') === '' ? '/' : rtrim($path, '/');

    $query = array_merge($embedded, $query);
    unset($query['r']);

    if ((string) Config::get('url_mode', 'query') === 'pretty') {
        $full = $base . $path;
    } else {
        $pathParam = $path === '/' ? [] : ['r' => $path];
        $query = array_merge($pathParam, $query);
        $full = $base . '/index.php';
    }

    if ($query !== []) {
        $full .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }
    return $full . $fragment;
}

/** 静态资源必须直连文件，不能走 index.php?r= 路由 */
function asset(string $path): string
{
    $base = rtrim((string) Config::get('base_url', ''), '/');
    $relative = 'resources/assets/' . ltrim($path, '/');
    $file = APP_ROOT . '/' . $relative;
    $version = is_file($file) ? '?v=' . filemtime($file) : '';
    return $base . '/' . $relative . $version;
}

/** 已下载到本地则使用本地资源，否则回退到 CDN 地址 */
function vendor_asset(string $path, string $fallback = ''): string
{
    $relative = 'resources/assets/' . ltrim($path, '/');
    if (is_file(APP_ROOT . '/' . $relative)) {
        return asset($path);
    }
    return $fallback;
}

function vendor_font_css(): string
{
    return vendor_asset(
        'vendor/fonts/google-fonts.css',
        'https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@400;500;600;700&family=Noto+Sans+SC:wght@300;400;500&display=swap'
    );
}

function vendor_fontawesome_css(): string
{
    return vendor_asset(
        'vendor/font-awesome/css/all.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'
    );
}

function vendor_sweetalert_js(): string
{
    return vendor_asset(
        'vendor/sweetalert2/sweetalert2.all.min.js',
        'https://cdn.jsdelivr.net/npm/sweetalert2@11'
    );
}

function upload_url(?string $path): string
{
    if ($path === null || trim($path) === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    $base = rtrim((string) Config::get('base_url', ''), '/');
    $url = $base . '/uploads/' . ltrim($path, '/');
    // 覆盖上传后文件名不变，用修改时间避免浏览器继续显示旧图
    $absolute = APP_ROOT . '/uploads/' . ltrim($path, '/');
    if (is_file($absolute)) {
        $url .= '?v=' . (int) filemtime($absolute);
    }
    return $url;
}

function redirect(string $path, int $status = 302): void
{
    header('Location: ' . url($path), true, $status);
    exit;
}

function json_response(mixed $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function abort(int $code, string $message = ''): void
{
    http_response_code($code);
    $titles = [403 => '没有访问权限', 404 => '页面走失了', 405 => '请求方式不正确', 419 => '页面已过期', 500 => '服务暂时不可用'];
    $title = $titles[$code] ?? '出错了';
    try {
        View::render('errors/error', [
            'code' => $code,
            'title' => $title,
            'message' => $message,
        ], 'public');
    } catch (Throwable $e) {
        echo '<!doctype html><meta charset="utf-8"><title>' . e($title) . '</title>';
        echo '<div style="font-family:serif;padding:48px;text-align:center">';
        echo '<h1 style="font-size:48px;margin:0">' . $code . '</h1><p>' . e($message ?: $title) . '</p>';
        echo '</div>';
    }
    exit;
}

function setting(string $key, string $default = ''): string
{
    return Settings::get($key, $default);
}

function csrf_field(): string
{
    return Csrf::field();
}

function csrf_token_value(): string
{
    return Csrf::token();
}

function is_mobile(): bool
{
    return UA::isMobile();
}

function auth_user(): ?array
{
    return Auth::user();
}

function auth_can(string $permission): bool
{
    return Auth::can($permission);
}

/** 当前登录账号是否为站长（role code = admin） */
function is_site_owner(): bool
{
    return Auth::hasRole('admin');
}

/** 手机号脱敏：138****5678 */
function mask_phone(string $value): string
{
    $length = strlen($value);
    if ($length < 7) {
        return mb_substr($value, 0, 1, 'UTF-8') . str_repeat('*', max(0, $length - 2)) . mb_substr($value, -1, 1, 'UTF-8');
    }
    return substr($value, 0, 3) . str_repeat('*', $length - 7) . substr($value, -4);
}

/** 邮箱脱敏：ab***@example.com */
function mask_email(string $value): string
{
    if (!str_contains($value, '@')) {
        return mask_name($value);
    }
    [$name, $domain] = explode('@', $value, 2);
    $keep = min(2, mb_strlen($name, 'UTF-8'));
    return mb_substr($name, 0, $keep, 'UTF-8') . '***@' . $domain;
}

/** IP 脱敏：192.*.*.10 / IPv6 保留前两组 */
function mask_ip(string $value): string
{
    if (filter_var($value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $parts = explode('.', $value);
        return $parts[0] . '.*.*.' . $parts[3];
    }
    $parts = explode(':', $value);
    return implode(':', array_slice($parts, 0, 2)) . ':****';
}

/** 姓名脱敏：张** */
function mask_name(string $value): string
{
    $chars = preg_split('//u', $value, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    if (count($chars) <= 1) {
        return $value . '*';
    }
    return $chars[0] . str_repeat('*', count($chars) - 1);
}

/** 证件号脱敏：1101**********1234 */
function mask_id_no(string $value): string
{
    $value = strtoupper($value);
    $length = strlen($value);
    if ($length <= 8) {
        return substr($value, 0, 2) . str_repeat('*', max(0, $length - 4)) . substr($value, -2);
    }
    return substr($value, 0, 4) . str_repeat('*', $length - 8) . substr($value, -4);
}

/**
 * 敏感信息展示：仅站长可见完整原值，其他后台角色一律脱敏。
 * $type 可选值：phone / email / ip / name / id_no
 */
function sensitive(?string $value, string $type): string
{
    $value = trim((string) $value);
    if ($value === '') {
        return '—';
    }
    if (is_site_owner()) {
        return $value;
    }
    return match ($type) {
        'phone' => mask_phone($value),
        'email' => mask_email($value),
        'ip' => mask_ip($value),
        'name' => mask_name($value),
        'id_no' => mask_id_no($value),
        default => $value,
    };
}

function word_count_text(?string $content): int
{
    $plain = strip_tags((string) $content);
    $plain = preg_replace('/\s+/u', '', $plain) ?? '';
    return (int) mb_strlen($plain, 'UTF-8');
}

function excerpt(?string $text, int $length = 120): string
{
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $text)) ?? '');
    return mb_substr($text, 0, $length, 'UTF-8') . (mb_strlen($text, 'UTF-8') > $length ? '…' : '');
}

function highlight(?string $text, string $keyword, int $length = 160): string
{
    $raw = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $text)) ?? '');
    $keyword = trim($keyword);
    if ($keyword !== '') {
        $pos = mb_stripos($raw, $keyword, 0, 'UTF-8');
        if ($pos !== false) {
            $start = max(0, $pos - 40);
            $raw = ($start > 0 ? '…' : '') . mb_substr($raw, $start, $length, 'UTF-8') . (mb_strlen($raw, 'UTF-8') > $start + $length ? '…' : '');
        } else {
            $raw = excerpt($raw, $length);
        }
    } else {
        $raw = excerpt($raw, $length);
    }
    $safe = e($raw);
    if ($keyword === '') {
        return $safe;
    }
    return str_ireplace(e($keyword), '<mark>' . e($keyword) . '</mark>', $safe);
}

function format_date(?string $datetime, string $format = 'Y-m-d'): string
{
    if ($datetime === null || $datetime === '' || str_starts_with($datetime, '0000')) {
        return '—';
    }
    $time = strtotime($datetime);
    return $time === false ? '—' : date($format, $time);
}

function time_ago(?string $datetime): string
{
    if ($datetime === null || $datetime === '') {
        return '—';
    }
    $time = strtotime($datetime);
    if ($time === false) {
        return '—';
    }
    $diff = time() - $time;
    if ($diff < 60) {
        return '刚刚';
    }
    if ($diff < 3600) {
        return (int) floor($diff / 60) . ' 分钟前';
    }
    if ($diff < 86400) {
        return (int) floor($diff / 3600) . ' 小时前';
    }
    if ($diff < 86400 * 30) {
        return (int) floor($diff / 86400) . ' 天前';
    }
    return date('Y-m-d', $time);
}

function status_label(string $status): string
{
    $labels = [
        'draft' => '草稿',
        'reviewing' => '审核中',
        'rejected' => '已驳回',
        'approved' => '审核通过',
        'serializing' => '连载中',
        'paused' => '暂停更新',
        'finished' => '已完结',
        'offline' => '已下架',
        'deleted' => '已删除',
        'pending' => '待审核',
        'published' => '已发布',
        'scheduled' => '定时待发布',
        'hidden' => '已隐藏',
        'recycle' => '回收站',
        'waiting' => '待审',
        'assigned' => '审核中',
        'handled' => '已处理',
        'received' => '已受理',
        'transferred' => '已转交',
        'closed' => '已关闭',
        'active' => '正常',
        'limited' => '受限',
        'locked' => '锁定',
        'risk' => '风险审查',
        'inactive' => '未激活',
        'deleting' => '注销中',
        'public' => '公开',
        'failed' => '失败',
        'done' => '完成',
        'skipped' => '跳过',
        'pending_author' => '审核中',
        'rejected_author' => '未通过',
        'approve' => '通过',
        'reject' => '驳回',
        'restore' => '恢复',
    ];
    return $labels[$status] ?? $status;
}

function status_badge_class(string $status): string
{
    $map = [
        'published' => 'badge-green',
        'serializing' => 'badge-green',
        'approved' => 'badge-green',
        'active' => 'badge-green',
        'public' => 'badge-green',
        'handled' => 'badge-green',
        'finished' => 'badge-green',
        'reviewing' => 'badge-gold',
        'pending' => 'badge-gold',
        'waiting' => 'badge-gold',
        'assigned' => 'badge-gold',
        'scheduled' => 'badge-gold',
        'received' => 'badge-gold',
        'paused' => 'badge-gold',
        'rejected' => 'badge-red',
        'offline' => 'badge-red',
        'locked' => 'badge-red',
        'risk' => 'badge-red',
        'deleted' => 'badge-red',
        'limited' => 'badge-red',
    ];
    return $map[$status] ?? 'badge-gray';
}

function report_status_label(string $status): string
{
    $labels = [
        'received' => '已受理',
        'reviewing' => '处理中',
        'handled' => '已处理',
        'transferred' => '已转交',
        'closed' => '已关闭',
    ];
    return $labels[$status] ?? $status;
}

function report_category_label(string $category): string
{
    $labels = [
        'violation' => '违法不良信息',
        'copyright' => '侵权投诉',
        'spam' => '垃圾营销',
        'minor' => '未成年人风险',
        'other' => '其他',
    ];
    return $labels[$category] ?? $category;
}

function book_is_public(string $status): bool
{
    return in_array($status, ['approved', 'serializing', 'paused', 'finished'], true);
}

function pager_html(array $pager): string
{
    if (($pager['pages'] ?? 1) <= 1) {
        return '';
    }
    $html = '<nav class="pager" aria-label="分页">';
    if (!empty($pager['prev'])) {
        $html .= '<a class="pager-link" href="' . e($pager['prev']) . '">上一页</a>';
    }
    foreach ($pager['links'] as $link) {
        $class = 'pager-link' . ($link['active'] ? ' is-active' : '');
        $html .= '<a class="' . $class . '" href="' . e($link['url']) . '">' . (int) $link['page'] . '</a>';
    }
    if (!empty($pager['next'])) {
        $html .= '<a class="pager-link" href="' . e($pager['next']) . '">下一页</a>';
    }
    $html .= '<span class="pager-meta">共 ' . (int) $pager['total'] . ' 条 · 第 ' . (int) $pager['page'] . '/' . (int) $pager['pages'] . ' 页</span>';
    $html .= '</nav>';
    return $html;
}

function cover_gradient(int $seed): string
{
    $palettes = [
        'linear-gradient(140deg, #6d4a6b 0%, #c98a9b 58%, #f2d6c8 100%)',
        'linear-gradient(140deg, #4a5d7e 0%, #8e9bb8 55%, #e7d9e4 100%)',
        'linear-gradient(140deg, #7e5a4f 0%, #c9a487 55%, #f3e4d4 100%)',
        'linear-gradient(140deg, #4f6a62 0%, #9bb8aa 55%, #e9efe4 100%)',
        'linear-gradient(140deg, #6a4f7a 0%, #b79ac7 55%, #f0e3f4 100%)',
        'linear-gradient(140deg, #7a4f5e 0%, #d3a0ac 55%, #fbe7ea 100%)',
        'linear-gradient(140deg, #3f5868 0%, #7fa8b8 55%, #dcecf0 100%)',
        'linear-gradient(140deg, #6b5a3f 0%, #c2ab86 55%, #f4ead7 100%)',
    ];
    return $palettes[abs($seed) % count($palettes)];
}

/** 后台列表用的用户头像缩略图：无头像时显示昵称首字 */
function avatar_thumb(?string $avatar, string $name = '', string $size = 'xs'): string
{
    $url = $avatar !== null && trim($avatar) !== '' ? upload_url($avatar) : '';
    if ($url !== '') {
        return '<img class="avatar-' . e($size) . '" src="' . e($url) . '" alt="">';
    }
    $initial = mb_substr(trim($name), 0, 1, 'UTF-8');
    return '<span class="avatar-' . e($size) . ' avatar-fallback">' . e($initial !== '' ? $initial : '读') . '</span>';
}

/** 作家名前的小头像：未提供头像时按笔名查询（同请求内缓存） */
function author_avatar(?string $penName, string $size = 'xs', ?string $avatar = null): string
{
    static $cache = [];
    $name = trim((string) $penName);
    if ($avatar === null && $name !== '') {
        if (!array_key_exists($name, $cache)) {
            $cache[$name] = (string) (Database::value(
                'SELECT COALESCE(NULLIF(a.avatar, \'\'), p.avatar) FROM authors a
                 LEFT JOIN user_profiles p ON p.user_id = a.user_id
                 WHERE a.pen_name = ? LIMIT 1',
                [$name]
            ) ?? '');
        }
        $avatar = $cache[$name];
    }
    return '<span class="author-inline-avatar">' . avatar_thumb($avatar, $name !== '' ? $name : '作者', $size) . '</span>';
}

/** 后台列表用的作品封面缩略图：无封面时显示渐变首字 */
function cover_thumb(?string $cover, string $title = '', int $seed = 0, string $size = 'xs'): string
{
    if ($cover !== null && trim($cover) !== '') {
        return '<img class="cover-' . e($size) . '" src="' . e(upload_url($cover)) . '" alt="">';
    }
    $initial = mb_substr(trim($title), 0, 1, 'UTF-8');
    return '<span class="cover-' . e($size) . ' cover-fallback" style="background:' . cover_gradient($seed) . '">' . e($initial !== '' ? $initial : '书') . '</span>';
}

function notify_user(int $userId, string $title, string $content = ''): void
{
    if ($userId <= 0) {
        return;
    }
    Database::insert('notices', [
        'user_id' => $userId,
        'title' => mb_substr($title, 0, 120, 'UTF-8'),
        'content' => mb_substr($content, 0, 1000, 'UTF-8'),
        'is_read' => 0,
        'created_at' => date('Y-m-d H:i:s'),
    ]);
}

function client_ip(): string
{
    return Request::ip();
}
