<?php
declare(strict_types=1);

/**
 * 全站路由表
 * 路由只注册第一版允许触达的页面与操作；
 * 商业化（充值、订阅、章节购买、打赏、自动订阅、月票、打赏礼物、作者结算）
 * 在第一版不注册任何页面、接口与后台任务路由，确保四层闸门中的路由闸门不可绕过。
 */

use App\Core\Router;

$router = new Router();

/* -------------------------------------------------------------------------
 * 访问网站系统（游客 / 读者）
 * ---------------------------------------------------------------------- */
$router->get('/', 'PublicController@home');
$router->get('/category', 'PublicController@category');
$router->get('/category/{id}', 'PublicController@category');
$router->get('/search', 'PublicController@search');
$router->get('/ranking', 'PublicController@ranking');
$router->get('/ranking/{code}', 'PublicController@ranking');
$router->get('/book/{id}', 'PublicController@book');
$router->get('/book/{id}/catalog', 'PublicController@catalog');
$router->get('/chapter/{id}', 'PublicController@chapter');
$router->get('/announcements', 'PublicController@announcements');
$router->get('/announcement/{id}', 'PublicController@announcement');
$router->get('/activities', 'PublicController@activities');
$router->get('/activity/{id}', 'PublicController@activity');
$router->get('/about', 'PublicController@about');

/* -------------------------------------------------------------------------
 * 账号系统
 * ---------------------------------------------------------------------- */
$router->get('/login', 'AuthController@showLogin');
$router->post('/login', 'AuthController@login');
$router->get('/register', 'AuthController@showRegister');
$router->post('/register', 'AuthController@register');
$router->get('/forgot-password', 'AuthController@showForgot');
$router->post('/forgot-password', 'AuthController@forgot');
$router->get('/reset-password', 'AuthController@showReset');
$router->post('/reset-password', 'AuthController@resetPassword');
$router->post('/logout', 'AuthController@logout');

/* -------------------------------------------------------------------------
 * 读者中心
 * ---------------------------------------------------------------------- */
$router->get('/user', 'UserController@center');
$router->get('/user/bookshelf', 'UserController@bookshelf');
$router->post('/user/bookshelf/add', 'UserController@shelfAdd');
$router->post('/user/bookshelf/remove', 'UserController@shelfRemove');
$router->get('/user/history', 'UserController@history');
$router->post('/user/history/delete', 'UserController@historyDelete');
$router->post('/user/history/clear', 'UserController@historyClear');
$router->get('/user/comments', 'UserController@comments');
$router->post('/user/comments/delete', 'UserController@commentDelete');
$router->post('/comment', 'UserController@postComment');
$router->post('/comment/like', 'UserController@likeComment');
$router->post('/rate', 'UserController@rate');
$router->get('/report', 'UserController@reportForm');
$router->post('/report', 'UserController@reportSubmit');
$router->get('/user/reports', 'UserController@reports');
$router->get('/user/settings', 'UserController@settings');
$router->post('/user/settings', 'UserController@saveSettings');
$router->post('/user/password', 'UserController@changePassword');
$router->get('/user/notices', 'UserController@notices');
$router->post('/user/notices/read', 'UserController@readNotices');
$router->post('/user/cancel', 'UserController@cancelAccount');

/* -------------------------------------------------------------------------
 * 作家系统
 * ---------------------------------------------------------------------- */
$router->get('/author/apply', 'AuthorController@applyForm');
$router->post('/author/apply', 'AuthorController@apply');
$router->get('/author', 'AuthorController@dashboard');
$router->get('/author/works', 'AuthorController@works');
$router->get('/author/work/create', 'AuthorController@workCreateForm');
$router->post('/author/work/create', 'AuthorController@workCreate');
$router->get('/author/work/{id}/edit', 'AuthorController@workEdit');
$router->post('/author/work/{id}/edit', 'AuthorController@workUpdate');
$router->post('/author/work/{id}/submit', 'AuthorController@workSubmit');
$router->post('/author/work/{id}/delete', 'AuthorController@workDelete');
$router->get('/author/work/{id}/volumes', 'AuthorController@volumes');
$router->post('/author/work/{id}/volumes', 'AuthorController@volumeCreate');
$router->post('/author/volume/{id}/update', 'AuthorController@volumeUpdate');
$router->post('/author/volume/{id}/delete', 'AuthorController@volumeDelete');
$router->get('/author/work/{id}/chapters', 'AuthorController@chapters');
$router->post('/author/work/{id}/chapters', 'AuthorController@chapterCreate');
$router->get('/author/chapter/{id}/edit', 'AuthorController@chapterEdit');
$router->post('/author/chapter/{id}/save', 'AuthorController@chapterSave');
$router->post('/author/chapter/{id}/submit', 'AuthorController@chapterSubmit');
$router->post('/author/chapter/{id}/autosave', 'AuthorController@chapterAutosave');
$router->post('/author/chapter/{id}/restore', 'AuthorController@chapterRestore');
$router->post('/author/chapter/{id}/delete', 'AuthorController@chapterDelete');
$router->get('/author/stats', 'AuthorController@stats');
$router->get('/author/recycle', 'AuthorController@recycle');
$router->post('/author/recycle/{id}/restore', 'AuthorController@recycleRestore');
$router->post('/author/recycle/{id}/purge', 'AuthorController@recyclePurge');

/* -------------------------------------------------------------------------
 * 站长后台管理系统
 * ---------------------------------------------------------------------- */
$router->get('/admin', 'Admin\\DashboardController@index');

$router->get('/admin/users', 'Admin\\UserController@index');
$router->post('/admin/users/purge-cancelled', 'Admin\\UserController@purgeCancelled');
$router->get('/admin/users/{id}', 'Admin\\UserController@show');
$router->post('/admin/users/{id}/status', 'Admin\\UserController@updateStatus');
$router->post('/admin/users/{id}/roles', 'Admin\\UserController@updateRoles');
$router->post('/admin/users/{id}/password', 'Admin\\UserController@resetPassword');
$router->post('/admin/users/{id}/delete', 'Admin\\UserController@destroy');
$router->get('/admin/authors', 'Admin\\UserController@authors');
$router->post('/admin/authors/{id}/review', 'Admin\\UserController@reviewAuthor');
$router->get('/admin/roles', 'Admin\\UserController@roles');
$router->get('/admin/roles/{id}/edit', 'Admin\\UserController@roleEdit');
$router->post('/admin/roles/{id}/save', 'Admin\\UserController@roleSave');

$router->get('/admin/books', 'Admin\\ContentController@books');
$router->post('/admin/books/{id}/action', 'Admin\\ContentController@bookAction');
$router->get('/admin/chapters', 'Admin\\ContentController@chapters');
$router->post('/admin/chapters/{id}/action', 'Admin\\ContentController@chapterAction');
$router->get('/admin/reviews', 'Admin\\ContentController@reviews');
$router->get('/admin/review/{type}/{id}', 'Admin\\ContentController@reviewDetail');
$router->post('/admin/review/{type}/{id}/act', 'Admin\\ContentController@reviewAct');
$router->get('/admin/comments', 'Admin\\ContentController@comments');
$router->post('/admin/comments/{id}/action', 'Admin\\ContentController@commentAction');

$router->get('/admin/reports', 'Admin\\OperationController@reports');
$router->get('/admin/reports/{id}', 'Admin\\OperationController@reportDetail');
$router->post('/admin/reports/{id}/act', 'Admin\\OperationController@reportAct');

$router->get('/admin/taxonomy', 'Admin\\OperationController@taxonomy');
$router->post('/admin/taxonomy/category/save', 'Admin\\OperationController@categorySave');
$router->post('/admin/taxonomy/category/{id}/delete', 'Admin\\OperationController@categoryDelete');
$router->post('/admin/taxonomy/tag/save', 'Admin\\OperationController@tagSave');
$router->post('/admin/taxonomy/tag/{id}/delete', 'Admin\\OperationController@tagDelete');
$router->post('/admin/taxonomy/preset', 'Admin\\OperationController@taxonomyPreset');

$router->get('/admin/recommend', 'Admin\\OperationController@recommend');
$router->post('/admin/recommend/save', 'Admin\\OperationController@recommendSave');
$router->post('/admin/recommend/{id}/toggle', 'Admin\\OperationController@recommendToggle');

$router->get('/admin/rankings', 'Admin\\OperationController@rankings');
$router->post('/admin/rankings/{id}/refresh', 'Admin\\OperationController@rankingRefresh');

$router->get('/admin/announcements', 'Admin\\OperationController@announcements');
$router->get('/admin/announcements/create', 'Admin\\OperationController@announcementForm');
$router->post('/admin/announcements/save', 'Admin\\OperationController@announcementSave');
$router->get('/admin/announcements/{id}/edit', 'Admin\\OperationController@announcementForm');
$router->post('/admin/announcements/{id}/save', 'Admin\\OperationController@announcementSave');
$router->post('/admin/announcements/{id}/status', 'Admin\\OperationController@announcementStatus');

$router->get('/admin/activities', 'Admin\\OperationController@activities');
$router->get('/admin/activities/create', 'Admin\\OperationController@activityForm');
$router->post('/admin/activities/save', 'Admin\\OperationController@activitySave');
$router->get('/admin/activities/{id}/edit', 'Admin\\OperationController@activityForm');
$router->post('/admin/activities/{id}/save', 'Admin\\OperationController@activitySave');
$router->post('/admin/activities/{id}/status', 'Admin\\OperationController@activityStatus');

$router->get('/admin/switches', 'Admin\\SystemController@switches');
$router->post('/admin/switches/{id}/toggle', 'Admin\\SystemController@switchToggle');
$router->get('/admin/logs', 'Admin\\SystemController@logs');
$router->get('/admin/recycle', 'Admin\\SystemController@recycle');
$router->post('/admin/recycle/{id}/restore', 'Admin\\SystemController@recycleRestore');
$router->post('/admin/recycle/{id}/purge', 'Admin\\SystemController@recyclePurge');
$router->get('/admin/finance', 'Admin\\SystemController@finance');
$router->get('/admin/settings', 'Admin\\SystemController@settings');
$router->post('/admin/settings/save', 'Admin\\SystemController@settingsSave');

return $router;
