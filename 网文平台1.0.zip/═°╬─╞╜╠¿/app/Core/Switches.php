<?php
declare(strict_types=1);

namespace App\Core;

class Switches
{
    private static ?array $cache = null;

    public static function all(bool $refresh = false): array
    {
        if (self::$cache === null || $refresh) {
            $rows = Database::all('SELECT * FROM switches ORDER BY grp, id');
            $cache = [];
            foreach ($rows as $row) {
                $cache[(string) $row['code']] = $row;
            }
            self::$cache = $cache;
        }
        return self::$cache;
    }

    public static function enabled(string $code): bool
    {
        $all = self::all();
        return isset($all[$code]) && (int) $all[$code]['value'] === 1;
    }

    public static function get(string $code): ?array
    {
        return self::all()[$code] ?? null;
    }
}
