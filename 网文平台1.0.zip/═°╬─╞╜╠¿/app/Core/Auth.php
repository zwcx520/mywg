<?php
declare(strict_types=1);

namespace App\Core;

class Auth
{
    private static ?array $user = null;
    private static bool $userLoaded = false;
    private static array $permissions = [];
    private static array $roles = [];

    public static function attempt(string $login, string $password): array
    {
        $login = trim($login);
        $user = Database::one(
            'SELECT * FROM users WHERE login_name = ? OR phone = ? OR email = ? LIMIT 1',
            [$login, $login, $login]
        );

        if (!$user) {
            self::logLogin(null, $login, 'fail', '账号不存在或凭证不匹配');
            return ['ok' => false, 'message' => '账号或密码不正确'];
        }

        if (!password_verify($password, (string) $user['password_hash'])) {
            self::logLogin((int) $user['id'], $login, 'fail', '密码错误');
            return ['ok' => false, 'message' => '账号或密码不正确'];
        }

        $status = (string) $user['status'];
        if (in_array($status, ['locked', 'deleted', 'deleting', 'risk'], true)) {
            self::logLogin((int) $user['id'], $login, 'fail', '账号状态限制：' . $status);
            return ['ok' => false, 'message' => '账号当前不可登录，请联系管理员'];
        }
        if ($status === 'inactive') {
            self::logLogin((int) $user['id'], $login, 'fail', '账号未激活');
            return ['ok' => false, 'message' => '账号尚未激活'];
        }

        self::logLogin((int) $user['id'], $login, 'success');
        self::login($user);
        return ['ok' => true, 'message' => '登录成功'];
    }

    private static function logLogin(?int $userId, string $login, string $result, string $risk = ''): void
    {
        Database::insert('login_logs', [
            'user_id' => $userId,
            'login_name' => mb_substr($login, 0, 120, 'UTF-8'),
            'ip' => Request::ip(),
            'ua' => Request::ua(),
            'result' => $result,
            'risk' => $risk === '' ? null : $risk,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function login(array $user): void
    {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int) $user['id'];
        self::$user = null;
        self::$userLoaded = false;
        self::$permissions = [];
        self::$roles = [];
    }

    public static function logout(): void
    {
        unset($_SESSION['uid']);
        self::$user = null;
        self::$userLoaded = false;
        self::$permissions = [];
        self::$roles = [];
        if (PHP_SAPI !== 'cli') {
            session_regenerate_id(true);
        }
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function id(): int
    {
        $user = self::user();
        return $user ? (int) $user['id'] : 0;
    }

    public static function user(): ?array
    {
        if (self::$userLoaded) {
            return self::$user;
        }
        self::$userLoaded = true;
        $uid = (int) ($_SESSION['uid'] ?? 0);
        if ($uid <= 0) {
            return null;
        }

        $user = Database::one(
            'SELECT u.*, p.nickname, p.avatar, p.bio, p.gender, p.city
             FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id
             WHERE u.id = ? LIMIT 1',
            [$uid]
        );
        if (!$user) {
            unset($_SESSION['uid']);
            return null;
        }
        if (!in_array((string) $user['status'], ['active', 'limited'], true)) {
            unset($_SESSION['uid']);
            return null;
        }

        self::$user = $user;
        self::loadRoles();
        return self::$user;
    }

    private static function loadRoles(): void
    {
        if (!self::$user) {
            return;
        }
        $uid = (int) self::$user['id'];
        $roles = Database::all(
            'SELECT r.code, r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?',
            [$uid]
        );
        self::$roles = [];
        foreach ($roles as $role) {
            self::$roles[(string) $role['code']] = (string) $role['name'];
        }

        $perms = Database::all(
            'SELECT DISTINCT p.code FROM user_roles ur
             JOIN role_permissions rp ON rp.role_id = ur.role_id
             JOIN permissions p ON p.id = rp.permission_id
             WHERE ur.user_id = ?',
            [$uid]
        );
        self::$permissions = array_map(static fn ($row) => (string) $row['code'], $perms);
    }

    public static function roles(): array
    {
        self::user();
        return self::$roles;
    }

    public static function hasRole(string $code): bool
    {
        self::user();
        return isset(self::$roles[$code]);
    }

    public static function can(string $permission): bool
    {
        self::user();
        if (!self::$user) {
            return false;
        }
        return in_array($permission, self::$permissions, true);
    }

    public static function requireLogin(string $redirect = '/login'): void
    {
        if (!self::check()) {
            Flash::add('info', '请先登录后再继续。');
            $next = Request::path();
            redirect($redirect . '?next=' . urlencode($next));
        }
    }

    public static function requireAdmin(): void
    {
        self::requireLogin('/login');
        if (!self::can('admin.access')) {
            abort(403, '当前账号没有后台访问权限。');
        }
    }

    public static function requirePermission(string $permission): void
    {
        self::requireAdmin();
        if (!self::can($permission)) {
            abort(403, '当前角色无权访问该模块。');
        }
    }
}
