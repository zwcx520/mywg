<?php
declare(strict_types=1);

namespace App\Core;

class UA
{
    public static function isMobile(): bool
    {
        if (isset($_COOKIE['view_mode'])) {
            return $_COOKIE['view_mode'] === 'mobile';
        }
        $ua = strtolower(Request::ua());
        if ($ua === '') {
            return false;
        }
        $keywords = ['mobile', 'android', 'iphone', 'ipad', 'ipod', 'windows phone', 'harmonyos', 'mobile safari', 'micromessenger'];
        foreach ($keywords as $keyword) {
            if (str_contains($ua, $keyword)) {
                return true;
            }
        }
        return false;
    }

    public static function deviceLabel(): string
    {
        return self::isMobile() ? '移动端' : '电脑端';
    }
}
