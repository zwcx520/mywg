<?php
declare(strict_types=1);

namespace App\Core;

class Logger
{
    public static function admin(string $module, string $action, string $detail = '', ?string $targetType = null, ?int $targetId = null): void
    {
        $admin = Auth::user();
        if (!$admin) {
            return;
        }
        Database::insert('admin_logs', [
            'admin_id' => (int) $admin['id'],
            'module' => $module,
            'action' => $action,
            'detail' => mb_substr($detail, 0, 1000, 'UTF-8'),
            'target_type' => $targetType,
            'target_id' => $targetId,
            'ip' => Request::ip(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
