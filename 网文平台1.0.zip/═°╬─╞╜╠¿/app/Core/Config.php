<?php
declare(strict_types=1);

namespace App\Core;

class Config
{
    private static array $items = [];

    public static function load(string $path): void
    {
        if (!is_file($path)) {
            if (PHP_SAPI !== 'cli') {
                header('Location: install.php');
                exit;
            }
            throw new \RuntimeException('缺少 config/config.php，请先安装程序。');
        }
        $config = require $path;
        if (!is_array($config)) {
            throw new \RuntimeException('配置文件格式不正确。');
        }
        self::$items = $config;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $segments = explode('.', $key);
        $value = self::$items;
        foreach ($segments as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }
        return $value;
    }

    public static function all(): array
    {
        return self::$items;
    }
}
