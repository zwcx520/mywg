<?php
declare(strict_types=1);

namespace App\Core;

class View
{
    public static function render(string $view, array $data = [], string $layout = 'public'): void
    {
        $file = APP_ROOT . '/resources/views/' . $view . '.php';
        if (!is_file($file)) {
            abort(500, '视图文件不存在：' . $view);
        }

        $data['site'] = Settings::all();
        $data['currentUser'] = Auth::user();
        $data['isMobile'] = UA::isMobile();
        $data['flashes'] = Flash::pull();
        extract($data, EXTR_SKIP);

        ob_start();
        require $file;
        $content = (string) ob_get_clean();

        $layoutFile = APP_ROOT . '/resources/views/layouts/' . $layout . '.php';
        if (!is_file($layoutFile)) {
            echo $content;
            return;
        }
        require $layoutFile;
    }

    public static function partial(string $view, array $data = []): void
    {
        $file = APP_ROOT . '/resources/views/' . $view . '.php';
        if (!is_file($file)) {
            return;
        }
        extract($data, EXTR_SKIP);
        require $file;
    }
}
