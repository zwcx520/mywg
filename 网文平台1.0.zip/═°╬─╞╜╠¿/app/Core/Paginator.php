<?php
declare(strict_types=1);

namespace App\Core;

class Paginator
{
    public static function make(int $total, int $perPage, int $page, string $baseUrl, array $query = []): array
    {
        $perPage = max(1, $perPage);
        $pages = max(1, (int) ceil($total / $perPage));
        $page = min(max(1, $page), $pages);
        $offset = ($page - 1) * $perPage;

        $separator = str_contains($baseUrl, '?') ? '&' : '?';

        $links = [];
        $start = max(1, $page - 2);
        $end = min($pages, $page + 2);
        for ($i = $start; $i <= $end; $i++) {
            $q = array_merge($query, ['page' => $i]);
            unset($q['r']);
            $links[] = [
                'page' => $i,
                'url' => $baseUrl . $separator . http_build_query($q, '', '&', PHP_QUERY_RFC3986),
                'active' => $i === $page,
            ];
        }

        $prevQuery = array_merge($query, ['page' => $page - 1]);
        $nextQuery = array_merge($query, ['page' => $page + 1]);
        unset($prevQuery['r'], $nextQuery['r']);
        $prevUrl = $page > 1 ? $baseUrl . $separator . http_build_query($prevQuery, '', '&', PHP_QUERY_RFC3986) : null;
        $nextUrl = $page < $pages ? $baseUrl . $separator . http_build_query($nextQuery, '', '&', PHP_QUERY_RFC3986) : null;

        return [
            'total' => $total,
            'per_page' => $perPage,
            'page' => $page,
            'pages' => $pages,
            'offset' => $offset,
            'from' => $total === 0 ? 0 : $offset + 1,
            'to' => min($total, $offset + $perPage),
            'links' => $links,
            'prev' => $prevUrl,
            'next' => $nextUrl,
        ];
    }
}
