<?php
declare(strict_types=1);

namespace App\Core;

class Csrf
{
    public static function token(): string
    {
        if (empty($_SESSION['_csrf'])) {
            $_SESSION['_csrf'] = bin2hex(random_bytes(32));
        }
        return (string) $_SESSION['_csrf'];
    }

    public static function field(): string
    {
        return '<input type="hidden" name="_token" value="' . htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8') . '">';
    }

    public static function verify(): bool
    {
        $token = (string) ($_POST['_token'] ?? Request::header('X-CSRF-Token'));
        if ($token === '' || empty($_SESSION['_csrf'])) {
            return false;
        }
        return hash_equals((string) $_SESSION['_csrf'], $token);
    }
}
