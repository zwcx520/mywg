<?php
declare(strict_types=1);

namespace App\Core;

class Router
{
    private array $routes = [];

    public function get(string $path, string $handler): void
    {
        $this->add('GET', $path, $handler);
    }

    public function post(string $path, string $handler): void
    {
        $this->add('POST', $path, $handler);
    }

    private function add(string $method, string $path, string $handler): void
    {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler,
            'regex' => $this->toRegex($path),
        ];
    }

    private function toRegex(string $path): string
    {
        $pattern = preg_replace('#\{[a-zA-Z_]+\}#', '([^/]+)', $path);
        return '#^' . $pattern . '$#';
    }

    public function dispatch(): void
    {
        $method = Request::method();
        $path = Request::path();

        if ($method === 'POST' && !Csrf::verify()) {
            abort(419, '页面已过期，请刷新后重新提交。');
        }

        $pathMatched = false;
        foreach ($this->routes as $route) {
            if (!preg_match($route['regex'], $path, $matches)) {
                continue;
            }
            $pathMatched = true;
            if ($route['method'] !== $method) {
                continue;
            }
            array_shift($matches);
            $this->invoke($route['handler'], $matches);
            return;
        }

        if ($pathMatched) {
            abort(405, '请求方法不被允许。');
        }
        abort(404, '没有找到你访问的页面。');
    }

    private function invoke(string $handler, array $params): void
    {
        [$controllerName, $method] = explode('@', $handler);
        $class = 'App\\Controllers\\' . $controllerName;
        if (!class_exists($class) || !method_exists($class, $method)) {
            abort(500, '路由处理程序不存在。');
        }
        $controller = new $class();
        $controller->{$method}(...$params);
    }
}
