<?php
declare(strict_types=1);

namespace App\Core;

class Settings
{
    private static ?array $cache = null;

    public static function all(bool $refresh = false): array
    {
        if (self::$cache === null || $refresh) {
            $rows = Database::all('SELECT skey, svalue FROM site_settings');
            $cache = [];
            foreach ($rows as $row) {
                $cache[(string) $row['skey']] = (string) $row['svalue'];
            }
            self::$cache = $cache;
        }
        return self::$cache;
    }

    public static function get(string $key, string $default = ''): string
    {
        $all = self::all();
        return $all[$key] ?? $default;
    }

    public static function save(string $key, string $value): void
    {
        $exists = Database::one('SELECT skey FROM site_settings WHERE skey = ?', [$key]);
        if ($exists) {
            Database::update('site_settings', ['svalue' => $value, 'updated_at' => date('Y-m-d H:i:s')], ['skey' => $key]);
        } else {
            Database::insert('site_settings', [
                'skey' => $key,
                'svalue' => $value,
                'grp' => 'site',
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        }
        self::$cache = null;
    }
}
