SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  login_name VARCHAR(32) NOT NULL,
  phone VARCHAR(20) NULL,
  email VARCHAR(120) NULL,
  password_hash VARCHAR(255) NOT NULL,
  status ENUM('inactive','active','limited','locked','risk','deleting','deleted') NOT NULL DEFAULT 'active',
  register_ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_login_name (login_name),
  UNIQUE KEY uk_phone (phone),
  UNIQUE KEY uk_email (email),
  KEY idx_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_profiles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  nickname VARCHAR(40) NOT NULL,
  avatar VARCHAR(255) NULL,
  bio VARCHAR(255) NULL,
  gender VARCHAR(10) NULL,
  city VARCHAR(40) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_settings (
  user_id INT UNSIGNED NOT NULL,
  font_size TINYINT UNSIGNED NOT NULL DEFAULT 18,
  line_height TINYINT UNSIGNED NOT NULL DEFAULT 2,
  theme VARCHAR(12) NOT NULL DEFAULT 'light',
  reading_mode VARCHAR(12) NOT NULL DEFAULT 'scroll',
  updated_at DATETIME NULL,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_identities (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  real_name VARCHAR(40) NOT NULL,
  id_no VARCHAR(32) NOT NULL,
  phone VARCHAR(20) NULL,
  material VARCHAR(255) NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  remark VARCHAR(255) NULL,
  reviewed_by INT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_user (user_id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  token CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_token (token),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_logs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NULL,
  login_name VARCHAR(120) NULL,
  ip VARCHAR(45) NULL,
  ua VARCHAR(255) NULL,
  result ENUM('success','fail') NOT NULL DEFAULT 'fail',
  risk VARCHAR(60) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_user_created (user_id, created_at),
  KEY idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS consents (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  doc_type VARCHAR(30) NOT NULL,
  version VARCHAR(20) NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS authors (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  pen_name VARCHAR(40) NOT NULL,
  avatar VARCHAR(255) NULL,
  intro VARCHAR(500) NULL,
  status ENUM('active','paused','revoked') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_user (user_id),
  UNIQUE KEY uk_pen (pen_name),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS author_applications (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  pen_name VARCHAR(40) NOT NULL,
  intro VARCHAR(500) NULL,
  real_name VARCHAR(40) NOT NULL,
  id_no VARCHAR(32) NOT NULL,
  phone VARCHAR(20) NULL,
  material VARCHAR(255) NULL,
  status ENUM('pending','rejected','approved') NOT NULL DEFAULT 'pending',
  remark VARCHAR(255) NULL,
  reviewed_by INT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_status_created (status, created_at),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS book_categories (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  parent_id INT UNSIGNED NOT NULL DEFAULT 0,
  name VARCHAR(40) NOT NULL,
  code VARCHAR(40) NOT NULL,
  description VARCHAR(255) NULL,
  sort INT NOT NULL DEFAULT 0,
  status TINYINT UNSIGNED NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_code (code),
  KEY idx_parent_sort (parent_id, sort)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tags (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(30) NOT NULL,
  code VARCHAR(30) NOT NULL,
  status TINYINT UNSIGNED NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_name (name),
  UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS books (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  book_code VARCHAR(24) NOT NULL,
  author_id INT UNSIGNED NOT NULL,
  category_id INT UNSIGNED NOT NULL,
  title VARCHAR(80) NOT NULL,
  cover VARCHAR(255) NULL,
  summary VARCHAR(1000) NULL,
  copyright_note VARCHAR(255) NULL,
  status ENUM('draft','reviewing','rejected','approved','serializing','paused','finished','offline','deleted') NOT NULL DEFAULT 'draft',
  editor_id INT UNSIGNED NULL,
  review_note VARCHAR(255) NULL,
  word_count INT UNSIGNED NOT NULL DEFAULT 0,
  view_count INT UNSIGNED NOT NULL DEFAULT 0,
  favorite_count INT UNSIGNED NOT NULL DEFAULT 0,
  rating DECIMAL(3,1) NOT NULL DEFAULT 0.0,
  rating_count INT UNSIGNED NOT NULL DEFAULT 0,
  is_featured TINYINT UNSIGNED NOT NULL DEFAULT 0,
  published_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_code (book_code),
  KEY idx_author (author_id),
  KEY idx_category (category_id),
  KEY idx_status_updated (status, updated_at),
  KEY idx_featured (is_featured, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS book_tag_map (
  book_id INT UNSIGNED NOT NULL,
  tag_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (book_id, tag_id),
  KEY idx_tag (tag_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS volumes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  book_id INT UNSIGNED NOT NULL,
  title VARCHAR(80) NOT NULL,
  sort INT NOT NULL DEFAULT 0,
  status ENUM('draft','public','hidden','recycle') NOT NULL DEFAULT 'draft',
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_book_sort (book_id, sort),
  KEY idx_book_status (book_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chapters (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  book_id INT UNSIGNED NOT NULL,
  volume_id INT UNSIGNED NOT NULL,
  chapter_no INT UNSIGNED NOT NULL,
  title VARCHAR(120) NOT NULL,
  status ENUM('draft','pending','approved','published','scheduled','rejected','hidden','offline','recycle') NOT NULL DEFAULT 'draft',
  is_paid TINYINT UNSIGNED NOT NULL DEFAULT 0,
  price DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  trial_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
  word_count INT UNSIGNED NOT NULL DEFAULT 0,
  read_count INT UNSIGNED NOT NULL DEFAULT 0,
  review_note VARCHAR(255) NULL,
  published_at DATETIME NULL,
  scheduled_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_book_no (book_id, chapter_no),
  KEY idx_volume (volume_id),
  KEY idx_status (status),
  KEY idx_published (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chapter_drafts (
  chapter_id INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  editor_token VARCHAR(40) NULL,
  version_no INT UNSIGNED NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (chapter_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chapter_contents (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  chapter_id INT UNSIGNED NOT NULL,
  version_no INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  word_count INT UNSIGNED NOT NULL DEFAULT 0,
  checksum CHAR(32) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_chapter_version (chapter_id, version_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chapter_snapshots (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  chapter_id INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  summary VARCHAR(255) NULL,
  version_no INT UNSIGNED NOT NULL DEFAULT 0,
  device VARCHAR(80) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_chapter_created (chapter_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chapter_versions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  chapter_id INT UNSIGNED NOT NULL,
  version_no INT UNSIGNED NOT NULL,
  kind ENUM('submit','publish','history') NOT NULL,
  content MEDIUMTEXT NOT NULL,
  word_count INT UNSIGNED NOT NULL DEFAULT 0,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_chapter_version (chapter_id, version_no),
  KEY idx_chapter_kind (chapter_id, kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chapter_reviews (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  chapter_id INT UNSIGNED NOT NULL,
  version_no INT UNSIGNED NOT NULL,
  reviewer_id INT UNSIGNED NOT NULL,
  action ENUM('approve','reject','transfer','offline') NOT NULL,
  reason_code VARCHAR(30) NULL,
  reason VARCHAR(255) NULL,
  note VARCHAR(500) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_chapter (chapter_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS book_reviews (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  book_id INT UNSIGNED NOT NULL,
  reviewer_id INT UNSIGNED NOT NULL,
  action ENUM('approve','reject','offline','restore') NOT NULL,
  reason VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_book (book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS review_tasks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  target_type ENUM('book','chapter','author','comment') NOT NULL,
  target_id INT UNSIGNED NOT NULL,
  version_no INT UNSIGNED NOT NULL DEFAULT 0,
  priority TINYINT UNSIGNED NOT NULL DEFAULT 2,
  status ENUM('waiting','assigned','handled') NOT NULL DEFAULT 'waiting',
  assignee_id INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  handled_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_status_priority (status, priority, created_at),
  KEY idx_target (target_type, target_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS schedules (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  chapter_id INT UNSIGNED NOT NULL,
  run_at DATETIME NOT NULL,
  status ENUM('pending','done','failed','skipped') NOT NULL DEFAULT 'pending',
  idempotency_key VARCHAR(80) NOT NULL,
  executed_at DATETIME NULL,
  note VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_chapter (chapter_id),
  UNIQUE KEY uk_key (idempotency_key),
  KEY idx_status_run (status, run_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recycle_items (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  target_type ENUM('book','volume','chapter','comment','bookshelf') NOT NULL,
  target_id INT UNSIGNED NOT NULL,
  title VARCHAR(120) NULL,
  owner_id INT UNSIGNED NULL,
  deleted_by INT UNSIGNED NULL,
  deleted_at DATETIME NOT NULL,
  restore_deadline DATETIME NULL,
  reason VARCHAR(255) NULL,
  restored_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_type_target (target_type, target_id),
  KEY idx_owner (owner_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bookshelf (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  book_id INT UNSIGNED NOT NULL,
  group_name VARCHAR(30) NOT NULL DEFAULT '默认分组',
  is_top TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_user_book (user_id, book_id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reading_history (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  book_id INT UNSIGNED NOT NULL,
  chapter_id INT UNSIGNED NOT NULL,
  read_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_user_book (user_id, book_id),
  KEY idx_user_read (user_id, read_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ratings (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  book_id INT UNSIGNED NOT NULL,
  score TINYINT UNSIGNED NOT NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_user_book (user_id, book_id),
  KEY idx_book (book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  book_id INT UNSIGNED NOT NULL,
  chapter_id INT UNSIGNED NULL,
  user_id INT UNSIGNED NOT NULL,
  parent_id INT UNSIGNED NULL,
  content VARCHAR(1000) NOT NULL,
  status ENUM('waiting','approved','hidden','deleted') NOT NULL DEFAULT 'approved',
  like_count INT UNSIGNED NOT NULL DEFAULT 0,
  ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_book_status_created (book_id, status, created_at),
  KEY idx_user (user_id),
  KEY idx_parent (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comment_likes (
  user_id INT UNSIGNED NOT NULL,
  comment_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (user_id, comment_id),
  KEY idx_comment (comment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notices (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(120) NOT NULL,
  content VARCHAR(1000) NULL,
  is_read TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_user_read (user_id, is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reports (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  reporter_id INT UNSIGNED NOT NULL,
  target_type ENUM('book','chapter','comment','user','cover','summary') NOT NULL,
  target_id INT UNSIGNED NOT NULL,
  category ENUM('violation','copyright','spam','minor','other') NOT NULL DEFAULT 'other',
  description VARCHAR(1000) NULL,
  status ENUM('received','reviewing','handled','transferred','closed') NOT NULL DEFAULT 'received',
  result VARCHAR(255) NULL,
  handled_by INT UNSIGNED NULL,
  handled_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_status_created (status, created_at),
  KEY idx_reporter (reporter_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS report_actions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  report_id INT UNSIGNED NOT NULL,
  admin_id INT UNSIGNED NOT NULL,
  action VARCHAR(40) NOT NULL,
  note VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_report (report_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS announcements (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(120) NOT NULL,
  summary VARCHAR(255) NULL,
  content MEDIUMTEXT NULL,
  scope ENUM('site','author','admin') NOT NULL DEFAULT 'site',
  status ENUM('draft','published','offline') NOT NULL DEFAULT 'draft',
  start_at DATETIME NULL,
  end_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_status_start (status, start_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activities (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(120) NOT NULL,
  summary VARCHAR(255) NULL,
  content MEDIUMTEXT NULL,
  cover VARCHAR(255) NULL,
  start_at DATETIME NULL,
  end_at DATETIME NULL,
  status ENUM('draft','published','offline') NOT NULL DEFAULT 'draft',
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_status_start (status, start_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS roles (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(30) NOT NULL,
  name VARCHAR(40) NOT NULL,
  description VARCHAR(255) NULL,
  is_system TINYINT UNSIGNED NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS permissions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(60) NOT NULL,
  name VARCHAR(60) NOT NULL,
  module VARCHAR(30) NOT NULL,
  action VARCHAR(30) NOT NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_code (code),
  KEY idx_module (module)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id INT UNSIGNED NOT NULL,
  permission_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  KEY idx_permission (permission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_roles (
  user_id INT UNSIGNED NOT NULL,
  role_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, role_id),
  KEY idx_role (role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admin_logs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  admin_id INT UNSIGNED NOT NULL,
  module VARCHAR(30) NOT NULL,
  action VARCHAR(60) NOT NULL,
  detail VARCHAR(1000) NULL,
  target_type VARCHAR(20) NULL,
  target_id INT UNSIGNED NULL,
  ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_admin_created (admin_id, created_at),
  KEY idx_module (module, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS switches (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(60) NOT NULL,
  grp VARCHAR(30) NOT NULL DEFAULT 'commercial',
  value TINYINT UNSIGNED NOT NULL DEFAULT 0,
  default_value TINYINT UNSIGNED NOT NULL DEFAULT 0,
  allow_toggle TINYINT UNSIGNED NOT NULL DEFAULT 0,
  version INT UNSIGNED NOT NULL DEFAULT 1,
  updated_by INT UNSIGNED NULL,
  updated_at DATETIME NULL,
  reason VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_code (code),
  KEY idx_group (grp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_settings (
  skey VARCHAR(64) NOT NULL,
  svalue TEXT NULL,
  grp VARCHAR(32) NOT NULL DEFAULT 'site',
  updated_at DATETIME NULL,
  PRIMARY KEY (skey)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rankings (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(30) NOT NULL,
  name VARCHAR(60) NOT NULL,
  type ENUM('total','category','new','finished','heat','favorite','read','rating') NOT NULL,
  period ENUM('daily','weekly','monthly') NOT NULL DEFAULT 'daily',
  min_rating_count INT UNSIGNED NOT NULL DEFAULT 10,
  status TINYINT UNSIGNED NOT NULL DEFAULT 1,
  description VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ranking_results (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ranking_id INT UNSIGNED NOT NULL,
  period_date DATE NOT NULL,
  book_id INT UNSIGNED NOT NULL,
  score DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  position INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_rank_date_book (ranking_id, period_date, book_id),
  KEY idx_period_position (ranking_id, period_date, position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recommendations (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  slot VARCHAR(40) NOT NULL,
  book_id INT UNSIGNED NOT NULL,
  weight INT NOT NULL DEFAULT 0,
  start_at DATETIME NULL,
  end_at DATETIME NULL,
  status TINYINT UNSIGNED NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_slot_status (slot, status),
  KEY idx_book (book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sensitive_words (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  word VARCHAR(64) NOT NULL,
  level ENUM('low','high') NOT NULL DEFAULT 'low',
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_word (word)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stat_daily (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  stat_date DATE NOT NULL,
  dim_type VARCHAR(20) NOT NULL,
  dim_id INT UNSIGNED NOT NULL DEFAULT 0,
  metric VARCHAR(20) NOT NULL,
  value INT UNSIGNED NOT NULL DEFAULT 0,
  batch_no VARCHAR(32) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_date_dim_metric (stat_date, dim_type, dim_id, metric)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recharge_packages (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  bonus DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  status TINYINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_no VARCHAR(40) NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  biz_type VARCHAR(30) NOT NULL,
  biz_id INT UNSIGNED NOT NULL DEFAULT 0,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'CNY',
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  channel VARCHAR(30) NULL,
  idempotency_key VARCHAR(80) NULL,
  expire_at DATETIME NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_order_no (order_no),
  UNIQUE KEY uk_idempotency (idempotency_key),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subscription_orders (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_no VARCHAR(40) NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  book_id INT UNSIGNED NOT NULL DEFAULT 0,
  period VARCHAR(20) NULL,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_order_no (order_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rewards (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  target_type VARCHAR(20) NOT NULL,
  target_id INT UNSIGNED NOT NULL DEFAULT 0,
  gift_code VARCHAR(30) NULL,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settlements (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  author_id INT UNSIGNED NOT NULL,
  period VARCHAR(20) NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  created_at DATETIME NOT NULL,
  PRIMARY KEY (id),
  KEY idx_author (author_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO book_categories (id, parent_id, name, code, description, sort, status, created_at) VALUES
(1, 0, '都市言情', 'urban', '城市烟火里的心动与重逢', 10, 1, NOW()),
(2, 0, '古风幻想', 'ancient', '衣袂与灯火之间的旧梦', 20, 1, NOW()),
(3, 0, '悬疑推理', 'mystery', '雾里抽丝剥茧的真相', 30, 1, NOW()),
(4, 0, '青春校园', 'campus', '盛夏、晚风与少年心事', 40, 1, NOW()),
(5, 0, '科幻未来', 'scifi', '星海尽头的浪漫回声', 50, 1, NOW()),
(6, 0, '历史传奇', 'history', '山河为卷，写尽人间', 60, 1, NOW()),
(7, 0, '治愈生活', 'healing', '把日子过成温柔的诗', 70, 1, NOW()),
(8, 0, '幻想奇缘', 'fantasy', '命运交错的奇幻旅程', 80, 1, NOW()),
(9, 2, '仙侠问道', 'xianxia', '剑与心的漫长修行', 1, 1, NOW()),
(10, 2, '宫闱情深', 'palace', '深宫灯影里的情与谋', 2, 1, NOW());

INSERT INTO tags (id, name, code, status, created_at) VALUES
(1, '甜宠', 'sweet', 1, NOW()),
(2, '双强', 'strong', 1, NOW()),
(3, '重生', 'rebirth', 1, NOW()),
(4, '穿越', 'time-travel', 1, NOW()),
(5, '群像', 'ensemble', 1, NOW()),
(6, '悬疑', 'suspense', 1, NOW()),
(7, '治愈', 'healing', 1, NOW()),
(8, '星际', 'interstellar', 1, NOW()),
(9, '权谋', 'scheme', 1, NOW()),
(10, '暗恋', 'secret-love', 1, NOW()),
(11, '成长', 'growth', 1, NOW()),
(12, '宿命感', 'destiny', 1, NOW());

INSERT INTO roles (code, name, description, is_system, created_at) VALUES
('reader', '注册读者', '浏览、阅读、评论与收藏', 1, NOW()),
('author', '认证作家', '创作、提交审核与查看本人统计', 1, NOW()),
('editor', '责任审核员', '负责所分配作品与章节的审核', 1, NOW()),
('reviewer', '内容审核员', '内容与评论审核，不处理财务', 1, NOW()),
('operator', '运营专员', '分类、标签、推荐、榜单与公告', 1, NOW()),
('finance', '财务管理员', '商业化扩展位与结算占位', 1, NOW()),
('security', '安全管理员', '日志、举报、封锁与应急开关', 1, NOW()),
('admin', '站长', '全站配置与最终上线授权', 1, NOW());

INSERT INTO permissions (code, name, module, action, created_at) VALUES
('admin.access', '后台入口', 'admin', 'access', NOW()),
('admin.dashboard', '后台首页', 'admin', 'dashboard', NOW()),
('admin.users', '用户管理', 'users', 'view', NOW()),
('admin.users.manage', '用户处置', 'users', 'manage', NOW()),
('admin.roles', '角色管理', 'roles', 'view', NOW()),
('admin.roles.manage', '角色授权', 'roles', 'manage', NOW()),
('admin.review', '审核工作台', 'review', 'view', NOW()),
('admin.review.handle', '内容处置', 'review', 'handle', NOW()),
('admin.authors', '作家认证', 'authors', 'view', NOW()),
('admin.books', '作品管理', 'books', 'view', NOW()),
('admin.reports', '举报管理', 'reports', 'view', NOW()),
('admin.reports.handle', '举报处置', 'reports', 'handle', NOW()),
('admin.taxonomy', '分类标签', 'taxonomy', 'manage', NOW()),
('admin.ops', '运营配置', 'ops', 'manage', NOW()),
('admin.comments', '评论治理', 'comments', 'manage', NOW()),
('admin.logs', '日志审计', 'logs', 'view', NOW()),
('admin.switches', '业务开关', 'switches', 'view', NOW()),
('admin.switches.manage', '开关变更', 'switches', 'manage', NOW()),
('admin.recycle', '回收站', 'recycle', 'manage', NOW()),
('admin.finance', '财务扩展位', 'finance', 'view', NOW()),
('admin.settings', '站点配置', 'settings', 'manage', NOW());

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('admin.access','admin.dashboard','admin.review','admin.review.handle','admin.books','admin.authors') WHERE r.code = 'editor';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('admin.access','admin.dashboard','admin.review','admin.comments') WHERE r.code = 'reviewer';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('admin.access','admin.dashboard','admin.taxonomy','admin.ops','admin.comments','admin.books') WHERE r.code = 'operator';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('admin.access','admin.dashboard','admin.finance') WHERE r.code = 'finance';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.code IN ('admin.access','admin.dashboard','admin.reports','admin.reports.handle','admin.logs','admin.switches') WHERE r.code = 'security';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON 1 = 1 WHERE r.code = 'admin';

INSERT INTO switches (code, name, grp, value, default_value, allow_toggle, version, updated_at, reason) VALUES
('recharge', '充值', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('subscription', '订阅', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('chapter_purchase', '章节购买', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('reward', '打赏', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('auto_subscribe', '自动订阅', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('monthly_ticket', '月票', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('reward_gift', '打赏礼物', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('author_settlement', '作者结算', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('payment_channel', '支付渠道', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('recommend_ticket', '推荐票', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('vip_badge', 'VIP 标识', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('extension_slot', '商业化扩展位', 'commercial', 0, 0, 0, 1, NOW(), '第一版锁定关闭，仅保留数据结构'),
('register_open', '开放注册', 'operation', 1, 1, 1, 1, NOW(), '运营可配置'),
('comment_pre_review', '评论先审后发', 'operation', 0, 0, 1, 1, NOW(), '默认先发后审，命中风险词先隐藏'),
('search_open', '站内搜索', 'operation', 1, 1, 1, 1, NOW(), '运营可配置'),
('scheduled_publish', '定时发布任务', 'operation', 1, 1, 1, 1, NOW(), '运营可配置');

INSERT INTO rankings (code, name, type, period, min_rating_count, status, description) VALUES
('total', '热力总榜', 'total', 'daily', 10, 1, '阅读、收藏与互动综合热度，每日刷新'),
('category', '分类榜', 'category', 'weekly', 10, 1, '按分类聚合的综合热度'),
('new', '新书榜', 'new', 'weekly', 5, 1, '发布 30 天内的新作'),
('finished', '完结榜', 'finished', 'weekly', 10, 1, '已完结作品的长期口碑'),
('heat', '热度榜', 'heat', 'daily', 10, 1, '阅读、收藏与互动加权计算'),
('favorite', '收藏榜', 'favorite', 'daily', 0, 1, '按有效收藏数排序'),
('read', '阅读榜', 'read', 'daily', 0, 1, '按有效阅读量排序'),
('rating', '评分榜', 'rating', 'weekly', 10, 1, '仅统计有效账号评分，样本不足不入榜');

INSERT INTO site_settings (skey, svalue, grp, updated_at) VALUES
('site_name', '墨韵文阁', 'site', NOW()),
('site_slogan', '在字里行间，与温柔相逢', 'site', NOW()),
('site_keywords', '网络文学,原创小说,浪漫阅读,古风,言情', 'site', NOW()),
('site_desc', '墨韵文阁是一个浪漫唯美的原创网络文学阅读与创作平台，先审后发，尊重版权。', 'site', NOW()),
('icp_no', '备案信息待运营主体核验后填写', 'site', NOW()),
('copyright_text', '© 2026 墨韵文阁 · 作品版权归作者所有', 'site', NOW()),
('contact_email', 'service@example.com', 'site', NOW()),
('report_notice', '如遇违法侵权内容，请通过举报入口提交，平台将依法依规处置。', 'site', NOW());

INSERT INTO sensitive_words (word, level, created_at) VALUES
('测试敏感词', 'low', NOW()),
('恶意链接', 'high', NOW()),
('冒充官方', 'high', NOW());

INSERT INTO announcements (title, summary, content, scope, status, start_at, end_at, created_at, updated_at) VALUES
('欢迎来到墨韵文阁', '在这里，每一次阅读都是一场温柔的相遇。', '墨韵文阁正式开放阅读与创作。所有作品均执行先审后发制度，作品页展示版权信息与责任审核主体。商业化功能在第一版保持关闭，所有已标识的付费章节在关闭期间免费开放阅读。', 'site', 'published', '2026-11-01 00:00:00', '2027-12-31 23:59:59', NOW(), NOW()),
('关于版权保护的说明', '尊重原创，是平台与读者共同的约定。', '平台仅展示作者授权发布的作品。未经授权，任何单位或个人不得复制、转载、改编或用于商业用途。如发现侵权内容，可通过作品页或举报中心提交权利证明，平台将核验后依规处理。', 'site', 'published', '2026-11-01 00:00:00', '2027-12-31 23:59:59', NOW(), NOW());

INSERT INTO activities (title, summary, content, start_at, end_at, status, created_at) VALUES
('长夜共读计划', '在冬夜里，为喜欢的故事点一盏灯。', '活动期间，读者可在作品评论区分享阅读感受，优秀书评将进入编辑推荐位。本活动仅作内容展示，不涉及支付、奖品发放或广告收益。', '2026-11-01 00:00:00', '2026-12-31 23:59:59', 'published', NOW()),
('春日书单征集', '把心动写进书单，把春天留给故事。', '面向读者征集年度心动书单，入选书单将在首页与活动页展示。活动规则以站内公告为准，第一版不关联任何付费行为。', '2026-11-01 00:00:00', '2027-02-28 23:59:59', 'published', NOW());
