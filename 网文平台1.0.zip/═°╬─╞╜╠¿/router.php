<?php
declare(strict_types=1);

/**
 * PHP 内置服务器开发路由：
 *   php -S 127.0.0.1:8000 router.php
 * 静态资源命中时直接返回，其余请求交给前端控制器。
 */

$uri = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
$file = __DIR__ . rawurldecode($uri);

if ($uri !== '/' && is_file($file)) {
    return false;
}

require __DIR__ . '/index.php';
