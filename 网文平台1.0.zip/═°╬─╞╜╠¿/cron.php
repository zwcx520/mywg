<?php
declare(strict_types=1);

/**
 * 定时任务入口（建议由服务器计划任务每 1-5 分钟调用一次）：
 *   php cron.php
 *
 * 仅处理第一版允许的后台任务：定时发布。
 * 商业化相关的结算、自动订阅扣费等任务在第一版不存在。
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    echo 'cron.php 仅允许通过命令行执行。';
    exit;
}

require __DIR__ . '/app/bootstrap.php';

$service = new App\Services\PublishService();
try {
    $result = $service->runDueSchedules();
    echo '[' . date('Y-m-d H:i:s') . '] 定时发布任务完成：发布 ' . (int) ($result['published'] ?? 0) . ' 篇，跳过 ' . (int) ($result['skipped'] ?? 0) . ' 篇' . PHP_EOL;
} catch (Throwable $e) {
    echo '[' . date('Y-m-d H:i:s') . '] 任务失败：' . $e->getMessage() . PHP_EOL;
    exit(1);
}
