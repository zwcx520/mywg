/* ==========================================================================
   墨韵文阁 · 前端交互
   依赖：Font Awesome 6（图标）、SweetAlert2（确认与提示）
   ========================================================================== */
(function () {
    'use strict';

    const $ = (sel, root) => (root || document).querySelector(sel);
    const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

    function toast(type, message) {
        if (window.Swal) {
            const icon = type === 'success' ? 'success' : type === 'error' ? 'error' : 'info';
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: icon,
                title: message,
                showConfirmButton: false,
                timer: 3200,
                timerProgressBar: true,
                customClass: { popup: 'moyun-toast' }
            });
            return;
        }
        const box = document.createElement('div');
        box.className = 'flash flash-' + type;
        box.style.position = 'fixed';
        box.style.top = '18px';
        box.style.right = '18px';
        box.style.zIndex = '9999';
        box.textContent = message;
        document.body.appendChild(box);
        setTimeout(() => box.remove(), 3200);
    }

    /* 抽屉导航 ------------------------------------------------------------ */
    function bindDrawer() {
        const drawer = $('[data-drawer]');
        if (!drawer) return;
        const openBtn = $('[data-drawer-open]');
        const closeEls = $$('[data-drawer-close]', drawer);
        const mask = $('.drawer-mask', drawer);
        const open = () => drawer.classList.add('is-open');
        const close = () => drawer.classList.remove('is-open');
        if (openBtn) openBtn.addEventListener('click', open);
        closeEls.forEach((el) => el.addEventListener('click', close));
        if (mask) mask.addEventListener('click', close);
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') close();
        });
    }

    /* 后台侧栏 ------------------------------------------------------------ */
    function bindAdminSide() {
        const side = $('.admin-side');
        if (!side) return;
        const openBtn = $('[data-admin-menu]');
        const mask = $('.admin-drawer-mask');
        const open = () => {
            side.classList.add('is-open');
            if (mask) mask.classList.add('is-open');
        };
        const close = () => {
            side.classList.remove('is-open');
            if (mask) mask.classList.remove('is-open');
        };
        if (openBtn) openBtn.addEventListener('click', open);
        if (mask) mask.addEventListener('click', close);
        $$('a', side).forEach((a) => a.addEventListener('click', close));
    }

    /* 手机 / 电脑视图切换 ------------------------------------------------ */
    function bindDeviceToggle() {
        $$('[data-view-mode]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const mode = btn.getAttribute('data-view-mode');
                document.cookie = 'view_mode=' + mode + ';path=/;max-age=' + (60 * 60 * 24 * 365) + ';samesite=lax';
                window.location.reload();
            });
        });
        $$('[data-view-reset]').forEach((btn) => {
            btn.addEventListener('click', () => {
                document.cookie = 'view_mode=;path=/;max-age=0;';
                window.location.reload();
            });
        });
    }

    /* Flash 自动淡出 ------------------------------------------------------ */
    function bindFlashes() {
        $$('.flash').forEach((flash, index) => {
            setTimeout(() => {
                flash.style.transition = 'opacity .5s, transform .5s';
                flash.style.opacity = '0';
                flash.style.transform = 'translateY(-6px)';
                setTimeout(() => flash.remove(), 550);
            }, 5000 + index * 300);
        });
    }

    /* 危险操作确认 -------------------------------------------------------- */
    function bindConfirms() {
        $$('form[data-confirm]').forEach((form) => {
            form.addEventListener('submit', (e) => {
                if (form.dataset.confirmed === '1') return;
                e.preventDefault();
                const text = form.getAttribute('data-confirm') || '确认执行该操作？';
                const danger = form.hasAttribute('data-danger');
                if (!window.Swal) {
                    if (window.confirm(text)) {
                        form.dataset.confirmed = '1';
                        form.submit();
                    }
                    return;
                }
                Swal.fire({
                    title: danger ? '请再次确认' : '确认操作',
                    text: text,
                    icon: danger ? 'warning' : 'question',
                    showCancelButton: true,
                    confirmButtonText: '确认',
                    cancelButtonText: '取消',
                    confirmButtonColor: danger ? '#b4525b' : '#a4647c',
                    cancelButtonColor: '#8f8492',
                    background: '#fffdfb',
                    customClass: { popup: 'moyun-swal' }
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.dataset.confirmed = '1';
                        form.submit();
                    }
                });
            });
        });

        // 带 data-confirm 的提交按钮（例如审核通过 / 驳回、带 formaction 的提交）
        $$('button[data-confirm]').forEach((btn) => {
            btn.addEventListener('click', (e) => {
                if (btn.dataset.confirmed === '1') return;
                e.preventDefault();
                const text = btn.getAttribute('data-confirm') || '确认执行该操作？';
                const danger = btn.hasAttribute('data-danger');
                const go = () => {
                    btn.dataset.confirmed = '1';
                    btn.click();
                };
                if (!window.Swal) {
                    if (window.confirm(text)) go();
                    return;
                }
                Swal.fire({
                    title: danger ? '请再次确认' : '确认操作',
                    text: text,
                    icon: danger ? 'warning' : 'question',
                    showCancelButton: true,
                    confirmButtonText: '确认',
                    cancelButtonText: '取消',
                    confirmButtonColor: danger ? '#b4525b' : '#a4647c',
                    cancelButtonColor: '#8f8492',
                    background: '#fffdfb',
                    customClass: { popup: 'moyun-swal' }
                }).then((result) => {
                    if (result.isConfirmed) go();
                });
            });
        });
    }

    /* 阅读器偏好 ---------------------------------------------------------- */
    const READER_KEY = 'moyun_reader_prefs_v1';
    const READER_DEFAULTS = { fontSize: 18, lineHeight: 2, theme: 'light', mode: 'scroll' };

    function loadReaderPrefs() {
        try {
            const raw = localStorage.getItem(READER_KEY);
            return raw ? Object.assign({}, READER_DEFAULTS, JSON.parse(raw)) : Object.assign({}, READER_DEFAULTS);
        } catch (e) {
            return Object.assign({}, READER_DEFAULTS);
        }
    }

    function applyReaderPrefs(prefs) {
        const content = $('[data-reader-content]');
        if (!content) return;
        content.style.setProperty('--reader-font', prefs.fontSize + 'px');
        content.style.setProperty('--reader-line', String(prefs.lineHeight));
        content.style.fontSize = prefs.fontSize + 'px';
        content.style.lineHeight = String(prefs.lineHeight);
        document.body.classList.remove('reader-theme-light', 'reader-theme-sepia', 'reader-theme-night');
        document.body.classList.add('reader-theme-' + prefs.theme);
        const settings = $('[data-reader-settings]');
        if (settings) {
            const fs = $('[data-reader-fontsize]', settings);
            const lh = $('[data-reader-lineheight]', settings);
            if (fs) fs.textContent = prefs.fontSize + 'px';
            if (lh) lh.textContent = prefs.lineHeight.toFixed(1);
        }
        $$('[data-reader-theme-btn]').forEach((btn) => {
            btn.classList.toggle('is-active', btn.getAttribute('data-reader-theme-btn') === prefs.theme);
        });
    }

    function saveReaderPrefs(prefs) {
        applyReaderPrefs(prefs);
        try {
            localStorage.setItem(READER_KEY, JSON.stringify(prefs));
        } catch (e) { /* ignore */ }
        // 同步到服务端设置（静默）
        const form = $('[data-reader-pref-form]');
        if (form) {
            const fsInput = $('[name="font_size"]', form);
            const themeInput = $('[name="theme"]', form);
            const modeInput = $('[name="reading_mode"]', form);
            if (fsInput) fsInput.value = prefs.fontSize;
            if (themeInput) themeInput.value = prefs.theme;
            if (modeInput) modeInput.value = prefs.mode;
            const data = new FormData(form);
            // 行距在数据库中是离散档位（2/3/4），小数行距仅本地生效，不回写服务端
            data.delete('line_height');
            fetch(form.getAttribute('action'), {
                method: 'POST',
                body: data,
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            }).catch(() => { /* 离线时忽略 */ });
        }
    }

    function bindReader() {
        const content = $('[data-reader-content]');
        if (!content) return;
        let prefs = loadReaderPrefs();
        applyReaderPrefs(prefs);

        const panel = $('[data-reader-settings]');
        $$('[data-reader-open-settings]').forEach((btn) => {
            btn.addEventListener('click', () => {
                if (!panel) return;
                panel.classList.toggle('is-open');
            });
        });
        $$('[data-reader-close-settings]').forEach((btn) => {
            btn.addEventListener('click', () => panel && panel.classList.remove('is-open'));
        });

        $$('[data-reader-font]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const delta = parseInt(btn.getAttribute('data-reader-font'), 10);
                prefs.fontSize = Math.min(30, Math.max(14, prefs.fontSize + delta));
                saveReaderPrefs(prefs);
            });
        });
        $$('[data-reader-line]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const delta = parseFloat(btn.getAttribute('data-reader-line'));
                prefs.lineHeight = Math.min(2.6, Math.max(1.6, +(prefs.lineHeight + delta).toFixed(1)));
                saveReaderPrefs(prefs);
            });
        });
        $$('[data-reader-theme-btn]').forEach((btn) => {
            btn.addEventListener('click', () => {
                prefs.theme = btn.getAttribute('data-reader-theme-btn');
                saveReaderPrefs(prefs);
            });
        });

        // 目录抽屉
        const drawer = $('[data-reader-drawer]');
        if (drawer) {
            const open = () => drawer.classList.add('is-open');
            const close = () => drawer.classList.remove('is-open');
            $$('[data-reader-drawer-open]').forEach((btn) => btn.addEventListener('click', open));
            $$('[data-reader-drawer-close]', drawer).forEach((btn) => btn.addEventListener('click', close));
            const mask = $('.mask', drawer);
            if (mask) mask.addEventListener('click', close);
        }

        // 键盘左右翻章
        document.addEventListener('keydown', (e) => {
            if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
            if (e.key === 'ArrowLeft') {
                const prev = $('[data-reader-prev]');
                if (prev) window.location.href = prev.getAttribute('href');
            }
            if (e.key === 'ArrowRight') {
                const next = $('[data-reader-next]');
                if (next) window.location.href = next.getAttribute('href');
            }
        });
    }

    /* 阅读页：右下角悬浮工具栏 ------------------------------------------------ */
    function bindReaderFab() {
        const toolbar = $('[data-reader-toolbar]');
        if (!toolbar) return;
        const toggle = $('[data-reader-toolbar-toggle]', toolbar);
        const items = $$('.reader-fab-list > *', toolbar);
        if (!toggle) return;
        const icon = $('i', toggle);

        // 由下往上逐一展开：越靠近圆形按钮，出现越早
        items.forEach((item, index) => {
            item.style.setProperty('--i', String(items.length - index));
        });

        function setOpen(open) {
            toolbar.classList.toggle('is-open', open);
            toggle.classList.toggle('is-open', open);
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            toggle.setAttribute('aria-label', open ? '收起阅读工具' : '展开阅读工具');
            if (icon) {
                icon.classList.toggle('fa-bars', !open);
                icon.classList.toggle('fa-xmark', open);
            }
        }

        toggle.addEventListener('click', (event) => {
            event.stopPropagation();
            setOpen(!toolbar.classList.contains('is-open'));
        });
        items.forEach((item) => item.addEventListener('click', () => setOpen(false)));
        document.addEventListener('click', (event) => {
            if (!toolbar.classList.contains('is-open')) return;
            if (toolbar.contains(event.target)) return;
            setOpen(false);
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') setOpen(false);
        });
    }

    /* 作家编辑器：草稿自动保存 -------------------------------------------- */
    function bindAutosave() {
        const form = $('[data-autosave-url]');
        if (!form) return;
        const endpoint = form.getAttribute('data-autosave-url');
        const tokenInput = $('[name="editor_token"]', form);
        const status = $('[data-autosave-status]');
        const content = $('[name="content"]', form);
        const title = $('[name="title"]', form);
        let timer = null;
        let dirty = false;
        let saving = false;

        const setStatus = (text, kind) => {
            if (!status) return;
            status.textContent = text;
            status.style.color = kind === 'error' ? '#a14550' : kind === 'ok' ? '#4e735f' : '#9a8b9c';
        };

        const doSave = () => {
            if (!dirty || saving || !endpoint) return;
            saving = true;
            setStatus('正在自动保存…', '');
            const body = new FormData();
            body.append('title', title ? title.value : '');
            body.append('content', content ? content.value : '');
            body.append('editor_token', tokenInput ? tokenInput.value : '');
            const csrf = document.querySelector('meta[name="csrf-token"]');
            fetch(endpoint, {
                method: 'POST',
                body: body,
                credentials: 'same-origin',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-Token': csrf ? csrf.getAttribute('content') : ''
                }
            })
                .then((res) => res.json().then((data) => ({ status: res.status, data: data })))
                .then(({ status: code, data }) => {
                    saving = false;
                    if (code === 409) {
                        setStatus('检测到其他窗口的更新，请刷新后对比草稿', 'error');
                        toast('error', data.message || '自动保存冲突：内容已在其他窗口被修改。');
                        return;
                    }
                    if (!data.ok) {
                        setStatus(data.message || '自动保存失败', 'error');
                        return;
                    }
                    dirty = false;
                    setStatus('已自动保存 · ' + (data.saved_at || new Date().toLocaleTimeString('zh-CN')), 'ok');
                })
                .catch(() => {
                    saving = false;
                    setStatus('自动保存失败，请检查网络', 'error');
                });
        };

        const markDirty = () => {
            dirty = true;
            setStatus('有未保存的修改…', '');
            if (timer) clearTimeout(timer);
            timer = setTimeout(doSave, 15000);
        };

        [content, title].forEach((el) => {
            if (!el) return;
            el.addEventListener('input', markDirty);
        });
        if (content) {
            content.addEventListener('blur', () => {
                if (dirty) doSave();
            });
        }
        // 离开页面前尽力保存
        window.addEventListener('beforeunload', (e) => {
            if (dirty) {
                doSave();
                e.preventDefault();
                e.returnValue = '';
            }
        });
        setInterval(() => {
            if (dirty) doSave();
        }, 60000);
        setStatus('自动保存已开启', '');
    }

    /* 字数统计 ------------------------------------------------------------ */
    function bindCounters() {
        $$('[data-counter]').forEach((input) => {
            const target = document.getElementById(input.getAttribute('data-counter'));
            if (!target) return;
            const max = parseInt(input.getAttribute('maxlength') || '0', 10);
            const update = () => {
                const len = input.value.length;
                target.textContent = max > 0 ? len + ' / ' + max : String(len);
            };
            input.addEventListener('input', update);
            update();
        });
    }

    /* 定时发布开关 -------------------------------------------------------- */
    function bindSchedule() {
        const checkbox = $('[data-schedule-toggle]');
        const box = $('[data-schedule-box]');
        if (!checkbox || !box) return;
        const update = () => {
            box.style.display = checkbox.checked ? '' : 'none';
            const input = box.querySelector('[name="scheduled_at"]');
            if (input) input.disabled = !checkbox.checked;
        };
        checkbox.addEventListener('change', update);
        update();
    }

    /* 表单重复提交保护 ---------------------------------------------------- */
    function bindSubmitLock() {
        $$('form[data-lock-submit]').forEach((form) => {
            form.addEventListener('submit', () => {
                const btn = $('button[type="submit"]', form);
                if (btn && !btn.disabled) {
                    setTimeout(() => {
                        btn.disabled = true;
                        btn.dataset.original = btn.innerHTML;
                        btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> 处理中';
                    }, 0);
                }
            });
        });
    }

    /* 标签 / 分类折叠 ----------------------------------------------------- */
    function bindToggles() {
        $$('[data-toggle-target]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const target = document.getElementById(btn.getAttribute('data-toggle-target'));
                if (target) target.classList.toggle('is-hidden');
            });
        });
    }

    /* 分类栏横向滑动 ----------------------------------------------------- */
    function bindChipScroll() {
        $$('.chip-scroll').forEach((bar) => {
            bar.addEventListener('wheel', (e) => {
                if (Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
                if (bar.scrollWidth <= bar.clientWidth) return;
                e.preventDefault();
                bar.scrollLeft += e.deltaY;
            }, { passive: false });

            let dragging = false;
            let moved = 0;
            let suppressClick = false;
            let startX = 0;
            let startLeft = 0;

            bar.addEventListener('pointerdown', (e) => {
                if (e.pointerType !== 'mouse') return;
                dragging = true;
                moved = 0;
                suppressClick = false;
                startX = e.clientX;
                startLeft = bar.scrollLeft;
            });
            bar.addEventListener('pointermove', (e) => {
                if (!dragging) return;
                const delta = e.clientX - startX;
                moved = Math.max(moved, Math.abs(delta));
                if (moved > 4) {
                    suppressClick = true;
                    bar.classList.add('is-dragging');
                    bar.scrollLeft = startLeft - delta;
                }
            });
            const stopDrag = () => {
                dragging = false;
                bar.classList.remove('is-dragging');
            };
            bar.addEventListener('pointerup', stopDrag);
            bar.addEventListener('pointerleave', stopDrag);
            bar.addEventListener('pointercancel', stopDrag);
            bar.addEventListener('click', (e) => {
                if (suppressClick) {
                    e.preventDefault();
                    e.stopPropagation();
                    suppressClick = false;
                }
            }, true);
        });
    }

    /* 头像上传即时预览 --------------------------------------------------- */
    function bindAvatarPreview() {
        const input = $('#avatar');
        const box = $('#avatar-preview');
        if (!input || !box) return;
        input.addEventListener('change', () => {
            const file = input.files && input.files[0];
            if (!file || !file.type.startsWith('image/')) return;
            const url = URL.createObjectURL(file);
            const img = new Image();
            img.onload = () => {
                box.innerHTML = '';
                box.appendChild(img);
                URL.revokeObjectURL(url);
            };
            img.src = url;
            img.alt = '头像预览';
        });
    }

    /* 作品封面即时预览 --------------------------------------------------- */
    function bindCoverPreview() {
        const input = $('#cover_file');
        const box = $('#cover-preview');
        if (!input || !box) return;

        input.addEventListener('change', () => {
            const file = input.files && input.files[0];
            if (!file || !file.type.startsWith('image/')) return;
            const url = URL.createObjectURL(file);
            const img = new Image();
            img.onload = () => {
                box.innerHTML = '';
                box.style.background = 'transparent';
                box.appendChild(img);
                URL.revokeObjectURL(url);
            };
            img.src = url;
            img.alt = '封面预览';
            img.style.width = '100%';
            img.style.height = '100%';
            img.style.objectFit = 'cover';

            const remove = $('input[name="remove_cover"]');
            if (remove) remove.checked = false;
        });

        const remove = $('input[name="remove_cover"]');
        if (remove) {
            remove.addEventListener('change', () => {
                if (!remove.checked) return;
                input.value = '';
                box.innerHTML = '暂无封面';
                box.style.background = box.dataset.gradient || 'transparent';
            });
        }
    }

    /* 作品详情：手机端「目录 / 读者评论」按钮栏切换 */
    function bindBookTabs() {
        const bar = document.querySelector('[data-book-tabs]');
        if (!bar) return;
        const root = bar.parentElement;
        const tabs = Array.prototype.slice.call(bar.querySelectorAll('[data-book-tab]'));
        const panels = Array.prototype.slice.call(root.querySelectorAll('[data-book-panel]'));
        if (!tabs.length || !panels.length) return;

        function activate(name, scroll) {
            tabs.forEach(function (tab) {
                const on = tab.getAttribute('data-book-tab') === name;
                tab.classList.toggle('is-active', on);
                tab.setAttribute('aria-selected', on ? 'true' : 'false');
            });
            panels.forEach(function (panel) {
                panel.classList.toggle('is-active', panel.getAttribute('data-book-panel') === name);
            });
            if (scroll) {
                bar.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }

        tabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                const name = tab.getAttribute('data-book-tab');
                activate(name, true);
                if (name === 'comments' && window.history.replaceState) {
                    window.history.replaceState(null, '', '#comments');
                }
            });
        });

        // 评论翻页（?page=N）或站内带 #comments 的链接：直接展示评论页
        const hasPage = new URLSearchParams(window.location.search).has('page');
        if (window.location.hash === '#comments' || hasPage) {
            activate('comments', false);
        }
        window.addEventListener('hashchange', function () {
            if (window.location.hash === '#comments') {
                activate('comments', false);
            }
        });
    }

    /* 首页轮播：自动播放 + 左右滑动 + 上下摇晃切换 */
    function bindHeroSlider() {
        const root = document.querySelector('[data-hero-slider]');
        if (!root) return;
        const slides = Array.prototype.slice.call(root.querySelectorAll('[data-hero-slide]'));
        const dots = Array.prototype.slice.call(root.querySelectorAll('[data-hero-dot]'));
        const prev = root.querySelector('[data-hero-prev]');
        const next = root.querySelector('[data-hero-next]');
        const indexEl = root.querySelector('[data-hero-index]');
        const chaptersEl = root.querySelector('.hero-stats-bar [data-hero-chapters]');
        const wordsEl = root.querySelector('.hero-stats-bar [data-hero-words]');
        if (slides.length < 2) return;

        let current = 0;
        let timer = null;
        const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

        const stop = () => {
            if (timer) {
                window.clearInterval(timer);
                timer = null;
            }
        };
        const start = () => {
            stop();
            if (reduceMotion) return;
            timer = window.setInterval(() => go(current + 1, false), 6000);
        };
        const go = (target, manual) => {
            current = (target + slides.length) % slides.length;
            slides.forEach((slide, i) => {
                slide.classList.toggle('is-active', i === current);
                slide.setAttribute('aria-hidden', i === current ? 'false' : 'true');
                if (i === current) {
                    slide.removeAttribute('inert');
                } else {
                    slide.setAttribute('inert', '');
                }
            });
            dots.forEach((dot, i) => dot.classList.toggle('is-active', i === current));
            if (indexEl) indexEl.textContent = ('0' + (current + 1)).slice(-2);
            if (chaptersEl) {
                const count = parseInt(slides[current].getAttribute('data-hero-chapters'), 10) || 0;
                chaptersEl.textContent = count.toLocaleString('zh-CN');
            }
            if (wordsEl) {
                const words = parseInt(slides[current].getAttribute('data-hero-words'), 10) || 0;
                wordsEl.textContent = Math.round(words / 10000).toLocaleString('zh-CN') + ' 万';
            }
            if (manual) start();
        };

        dots.forEach((dot) => {
            dot.addEventListener('click', () => go(parseInt(dot.getAttribute('data-index'), 10) || 0, true));
        });
        if (prev) prev.addEventListener('click', () => go(current - 1, true));
        if (next) next.addEventListener('click', () => go(current + 1, true));
        root.addEventListener('mouseenter', stop);
        root.addEventListener('mouseleave', start);
        root.addEventListener('focusin', stop);
        root.addEventListener('focusout', start);
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) stop(); else start();
        });

        let dragX = null;
        let dragY = null;
        root.addEventListener('pointerdown', (event) => {
            if (event.target.closest('a, button')) return;
            if (event.pointerType === 'mouse' && event.button !== 0) return;
            dragX = event.clientX;
            dragY = event.clientY;
            stop();
        });
        root.addEventListener('pointerup', (event) => {
            if (dragX === null) return;
            const dx = event.clientX - dragX;
            const dy = event.clientY - dragY;
            dragX = null;
            if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.2) {
                go(current + (dx < 0 ? 1 : -1), true);
            } else {
                start();
            }
        });
        window.addEventListener('pointerup', (event) => {
            if (dragX === null) return;
            const dx = event.clientX - dragX;
            const dy = event.clientY - dragY;
            dragX = null;
            if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.2) {
                go(current + (dx < 0 ? 1 : -1), true);
            } else {
                start();
            }
        });
        window.addEventListener('pointercancel', () => {
            dragX = null;
            start();
        });

        go(0, false);
        start();
    }

    function bindSideFab() {
        var fab = document.querySelector('[data-side-fab]');
        var side = document.getElementById('accountSide');
        if (!fab || !side) {
            return;
        }
        var icon = fab.querySelector('i');
        Array.prototype.forEach.call(side.querySelectorAll('.side-link'), function (link, index) {
            link.style.setProperty('--i', String(index));
        });

        function setOpen(open) {
            side.classList.toggle('is-open', open);
            fab.classList.toggle('is-open', open);
            fab.setAttribute('aria-expanded', open ? 'true' : 'false');
            fab.setAttribute('aria-label', open ? '收起中心菜单' : '打开中心菜单');
            if (icon) {
                icon.classList.toggle('fa-bars', !open);
                icon.classList.toggle('fa-xmark', open);
            }
        }

        fab.addEventListener('click', function (event) {
            event.stopPropagation();
            setOpen(!side.classList.contains('is-open'));
        });
        side.addEventListener('click', function (event) {
            if (event.target.closest('a')) {
                setOpen(false);
            }
        });
        document.addEventListener('click', function (event) {
            if (!side.classList.contains('is-open')) {
                return;
            }
            if (side.contains(event.target) || fab.contains(event.target)) {
                return;
            }
            setOpen(false);
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                setOpen(false);
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        bindDrawer();
        bindAdminSide();
        bindSideFab();
        bindDeviceToggle();
        bindFlashes();
        bindConfirms();
        bindReader();
        bindReaderFab();
        bindBookTabs();
        bindAutosave();
        bindCounters();
        bindSchedule();
        bindSubmitLock();
        bindToggles();
        bindChipScroll();
        bindAvatarPreview();
        bindCoverPreview();
        bindHeroSlider();
    });
})();
