<?php
/** 站长后台布局 */
$path = \App\Core\Request::path();
$adminName = $currentUser['nickname'] ?? ($currentUser['login_name'] ?? '站长');
$sectionTitles = [
    '/admin' => '总览',
    '/admin/users' => '用户管理',
    '/admin/authors' => '作家认证',
    '/admin/roles' => '角色与权限',
    '/admin/books' => '作品管理',
    '/admin/chapters' => '章节管理',
    '/admin/reviews' => '审核工作台',
    '/admin/review' => '审核详情',
    '/admin/comments' => '评论治理',
    '/admin/reports' => '举报处置',
    '/admin/taxonomy' => '分类与标签',
    '/admin/recommend' => '推荐位',
    '/admin/rankings' => '榜单管理',
    '/admin/announcements' => '公告管理',
    '/admin/activities' => '活动管理',
    '/admin/switches' => '业务开关',
    '/admin/logs' => '操作日志',
    '/admin/recycle' => '回收站',
    '/admin/finance' => '财务扩展位',
    '/admin/settings' => '站点配置',
];
$currentTitle = '后台管理';
foreach ($sectionTitles as $prefix => $label) {
    if ($path === $prefix || ($prefix !== '/admin' && str_starts_with($path, $prefix))) {
        $currentTitle = $label;
        break;
    }
}
$adminActive = static function (string $prefix) use ($path): string {
    if ($prefix === '/admin') {
        return $path === '/admin' ? 'is-active' : '';
    }
    return str_starts_with($path, $prefix) ? 'is-active' : '';
};
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e(csrf_token_value()) ?>">
    <title><?= e($currentTitle) ?> · 站长后台 · <?= e(setting('site_name', '墨韵文阁')) ?></title>
    <link rel="stylesheet" href="<?= e(vendor_font_css()) ?>">
    <link rel="stylesheet" href="<?= e(vendor_fontawesome_css()) ?>">
    <link rel="stylesheet" href="<?= asset('css/admin.css') ?>">
</head>
<body class="admin-body <?= is_mobile() ? 'mobile-view' : 'desktop-view' ?>">

<aside class="admin-side" data-admin-side>
    <div class="admin-brand">
        <span class="seal"><i class="fa-solid fa-feather-pointed"></i></span>
        <div>
            <h1><?= e(mb_substr(setting('site_name', '墨韵文阁'), 0, 8, 'UTF-8')) ?></h1>
            <span>EDITOR CONSOLE</span>
        </div>
    </div>

    <nav class="admin-nav">
        <div class="nav-group">概览</div>
        <a class="<?= $adminActive('/admin') ?>" href="<?= url('/admin') ?>"><i class="fa-solid fa-gauge-high"></i>工作台</a>

        <div class="nav-group">内容</div>
        <a class="<?= $adminActive('/admin/reviews') ?>" href="<?= url('/admin/reviews') ?>"><i class="fa-solid fa-clipboard-check"></i>审核队列</a>
        <?php if (auth_can('admin.books')): ?>
            <a class="<?= $adminActive('/admin/books') ?>" href="<?= url('/admin/books') ?>"><i class="fa-solid fa-book-open"></i>作品管理</a>
            <a class="<?= $adminActive('/admin/chapters') ?>" href="<?= url('/admin/chapters') ?>"><i class="fa-solid fa-file-lines"></i>章节管理</a>
        <?php endif; ?>
        <?php if (auth_can('admin.comments')): ?>
            <a class="<?= $adminActive('/admin/comments') ?>" href="<?= url('/admin/comments') ?>"><i class="fa-solid fa-comments"></i>评论治理</a>
        <?php endif; ?>

        <div class="nav-group">用户与权限</div>
        <?php if (auth_can('admin.users')): ?>
            <a class="<?= $adminActive('/admin/users') ?>" href="<?= url('/admin/users') ?>"><i class="fa-solid fa-users"></i>用户管理</a>
        <?php endif; ?>
        <?php if (auth_can('admin.authors')): ?>
            <a class="<?= $adminActive('/admin/authors') ?>" href="<?= url('/admin/authors') ?>"><i class="fa-solid fa-id-card"></i>作家认证</a>
        <?php endif; ?>
        <?php if (auth_can('admin.roles')): ?>
            <a class="<?= $adminActive('/admin/roles') ?>" href="<?= url('/admin/roles') ?>"><i class="fa-solid fa-user-shield"></i>角色权限</a>
        <?php endif; ?>

        <div class="nav-group">运营</div>
        <?php if (auth_can('admin.reports')): ?>
            <a class="<?= $adminActive('/admin/reports') ?>" href="<?= url('/admin/reports') ?>"><i class="fa-solid fa-flag"></i>举报处置</a>
        <?php endif; ?>
        <?php if (auth_can('admin.taxonomy')): ?>
            <a class="<?= $adminActive('/admin/taxonomy') ?>" href="<?= url('/admin/taxonomy') ?>"><i class="fa-solid fa-tags"></i>分类标签</a>
        <?php endif; ?>
        <?php if (auth_can('admin.ops')): ?>
            <a class="<?= $adminActive('/admin/recommend') ?>" href="<?= url('/admin/recommend') ?>"><i class="fa-solid fa-star"></i>推荐位</a>
            <a class="<?= $adminActive('/admin/rankings') ?>" href="<?= url('/admin/rankings') ?>"><i class="fa-solid fa-ranking-star"></i>榜单</a>
            <a class="<?= $adminActive('/admin/announcements') ?>" href="<?= url('/admin/announcements') ?>"><i class="fa-solid fa-bullhorn"></i>公告</a>
            <a class="<?= $adminActive('/admin/activities') ?>" href="<?= url('/admin/activities') ?>"><i class="fa-solid fa-gift"></i>活动</a>
        <?php endif; ?>

        <div class="nav-group">系统</div>
        <?php if (auth_can('admin.switches')): ?>
            <a class="<?= $adminActive('/admin/switches') ?>" href="<?= url('/admin/switches') ?>"><i class="fa-solid fa-toggle-on"></i>业务开关</a>
        <?php endif; ?>
        <?php if (auth_can('admin.logs')): ?>
            <a class="<?= $adminActive('/admin/logs') ?>" href="<?= url('/admin/logs') ?>"><i class="fa-solid fa-scroll"></i>操作日志</a>
        <?php endif; ?>
        <?php if (auth_can('admin.recycle')): ?>
            <a class="<?= $adminActive('/admin/recycle') ?>" href="<?= url('/admin/recycle') ?>"><i class="fa-solid fa-trash-can"></i>回收站</a>
        <?php endif; ?>
        <?php if (auth_can('admin.finance')): ?>
            <a class="<?= $adminActive('/admin/finance') ?>" href="<?= url('/admin/finance') ?>"><i class="fa-solid fa-wallet"></i>财务扩展位</a>
        <?php endif; ?>
        <?php if (auth_can('admin.settings')): ?>
            <a class="<?= $adminActive('/admin/settings') ?>" href="<?= url('/admin/settings') ?>"><i class="fa-solid fa-gear"></i>站点配置</a>
        <?php endif; ?>

        <div class="nav-group">商业化（第一版锁定）</div>
        <span class="locked"><i class="fa-solid fa-lock"></i>充值 / 订阅</span>
        <span class="locked"><i class="fa-solid fa-lock"></i>打赏 / 月票</span>
        <span class="locked"><i class="fa-solid fa-lock"></i>作者结算</span>
    </nav>

    <div class="admin-side-foot">
        <div class="who">
            <i class="fa-solid fa-circle-user"></i>
            <strong><?= e($adminName) ?></strong>
        </div>
        <a href="<?= url('/') ?>"><i class="fa-solid fa-arrow-up-right-from-square"></i>访问前台</a>
        <form method="post" action="<?= url('/logout') ?>" style="margin:0;">
            <?= csrf_field() ?>
            <button class="side-logout" type="submit"><i class="fa-solid fa-arrow-right-from-bracket"></i>退出登录</button>
        </form>
    </div>
</aside>

<div class="admin-drawer-mask" data-admin-mask></div>

<div class="admin-main">
    <header class="admin-top">
        <div>
            <span class="title"><?= e($currentTitle) ?></span>
            <span class="sub"><?= e(date('Y 年 m 月 d 日')) ?></span>
        </div>
        <div class="spacer"></div>
        <span class="device"><i class="fa-solid fa-display"></i> <?= is_mobile() ? '移动端' : '电脑端' ?></span>
        <a class="to-site" href="<?= url('/') ?>"><i class="fa-solid fa-book-open"></i><span class="to-site-label">前台</span></a>
        <form method="post" action="<?= url('/logout') ?>" style="margin:0;">
            <?= csrf_field() ?>
            <button class="to-site" type="submit" style="border:1px solid rgba(146,112,138,.28);cursor:pointer;background:rgba(255,255,255,.7);"><i class="fa-solid fa-arrow-right-from-bracket"></i><span class="to-site-label">退出</span></button>
        </form>
        <button class="admin-menu-btn" type="button" data-admin-menu aria-label="打开菜单"><i class="fa-solid fa-bars"></i></button>
    </header>

    <div class="admin-content">
        <?php require __DIR__ . '/../partials/flashes.php'; ?>
        <?= $content ?>
    </div>
</div>

<script src="<?= e(vendor_sweetalert_js()) ?>"></script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
