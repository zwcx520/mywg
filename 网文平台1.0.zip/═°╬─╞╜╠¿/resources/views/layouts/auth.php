<?php
/** 账号认证布局：登录 / 注册 / 找回密码 */
$pageTitle = $pageTitle ?? '账号';
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e(csrf_token_value()) ?>">
    <title><?= e($pageTitle) ?> · <?= e(setting('site_name', '墨韵文阁')) ?></title>
    <link rel="stylesheet" href="<?= e(vendor_font_css()) ?>">
    <link rel="stylesheet" href="<?= e(vendor_fontawesome_css()) ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body class="auth-body <?= is_mobile() ? 'mobile-view' : 'desktop-view' ?>">
<div class="auth-card">
    <div class="auth-brand">
        <a class="brand-seal" href="<?= url('/') ?>"><i class="fa-solid fa-feather-pointed"></i></a>
        <h1><?= e(setting('site_name', '墨韵文阁')) ?></h1>
        <p><?= e(setting('site_slogan', '在字里行间，与你重逢')) ?></p>
    </div>

    <?php require __DIR__ . '/../partials/flashes.php'; ?>
    <?= $content ?>
</div>

<script src="<?= e(vendor_sweetalert_js()) ?>"></script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
