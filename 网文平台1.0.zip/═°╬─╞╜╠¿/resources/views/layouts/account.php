<?php
/** 读者中心 / 作家中心布局 */
$path = \App\Core\Request::path();
$isAuthorArea = str_starts_with($path, '/author');
$nickname = $currentUser['nickname'] ?? ($currentUser['login_name'] ?? '读者');
$roles = \App\Core\Auth::roles();
$roleText = $isAuthorArea ? '作家' : (isset($roles['reader']) ? '读者' : '用户');
$navItem = static function (string $prefix, string $current) use ($path): string {
    return str_starts_with($path, $prefix) && strlen($path) >= strlen($prefix) ? 'is-active' : '';
};
$menuActive = static function (string $exact) use ($path): string {
    return $path === $exact ? 'is-active' : '';
};
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e(csrf_token_value()) ?>">
    <title><?= e($pageTitle ?? ($isAuthorArea ? '作家中心' : '读者中心')) ?> · <?= e(setting('site_name', '墨韵文阁')) ?></title>
    <link rel="stylesheet" href="<?= e(vendor_font_css()) ?>">
    <link rel="stylesheet" href="<?= e(vendor_fontawesome_css()) ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body class="<?= is_mobile() ? 'mobile-view' : 'desktop-view' ?>">
<?php require __DIR__ . '/../partials/site_header.php'; ?>

<main class="main">
    <div class="container">
        <?php require __DIR__ . '/../partials/flashes.php'; ?>
        <div class="account-layout">
            <aside class="account-side" id="accountSide">
                <div class="side-user">
                    <span class="author-avatar">
                        <?php if (!empty($currentUser['avatar'])): ?>
                            <img src="<?= e(upload_url((string) $currentUser['avatar'])) ?>" alt="">
                        <?php else: ?>
                            <?= e(mb_substr((string) $nickname, 0, 1, 'UTF-8')) ?>
                        <?php endif; ?>
                    </span>
                    <span>
                        <span class="name"><?= e($nickname) ?></span>
                        <span class="role"><?= e($roleText) ?></span>
                    </span>
                </div>

                <?php if (!$isAuthorArea): ?>
                    <div class="side-group">
                        <div class="side-group-title">读者中心</div>
                        <a class="side-link <?= $menuActive('/user') ?>" href="<?= url('/user') ?>"><i class="fa-solid fa-house-user"></i>个人中心</a>
                        <a class="side-link <?= $navItem('/user/bookshelf', '/') ?>" href="<?= url('/user/bookshelf') ?>"><i class="fa-solid fa-bookmark"></i>我的书架</a>
                        <a class="side-link <?= $navItem('/user/history', '/') ?>" href="<?= url('/user/history') ?>"><i class="fa-solid fa-clock-rotate-left"></i>阅读历史</a>
                        <a class="side-link <?= $navItem('/user/comments', '/') ?>" href="<?= url('/user/comments') ?>"><i class="fa-solid fa-comment-dots"></i>我的评论</a>
                        <a class="side-link <?= $navItem('/user/reports', '/') ?>" href="<?= url('/user/reports') ?>"><i class="fa-solid fa-flag"></i>我的举报</a>
                        <a class="side-link <?= $navItem('/user/notices', '/') ?>" href="<?= url('/user/notices') ?>"><i class="fa-solid fa-bell"></i>消息通知</a>
                        <a class="side-link <?= $navItem('/user/settings', '/') ?>" href="<?= url('/user/settings') ?>"><i class="fa-solid fa-gear"></i>账号设置</a>
                    </div>
                    <div class="side-group">
                        <div class="side-group-title">创作</div>
                        <a class="side-link" href="<?= url('/author') ?>"><i class="fa-solid fa-feather-pointed"></i>进入作家中心</a>
                        <a class="side-link" href="<?= url('/author/apply') ?>"><i class="fa-solid fa-id-card"></i>作家认证</a>
                    </div>
                <?php else: ?>
                    <div class="side-group">
                        <div class="side-group-title">作家中心</div>
                        <a class="side-link <?= $menuActive('/author') ?>" href="<?= url('/author') ?>"><i class="fa-solid fa-gauge-high"></i>创作台</a>
                        <a class="side-link <?= $navItem('/author/works', '/') ?>" href="<?= url('/author/works') ?>"><i class="fa-solid fa-book-open"></i>我的作品</a>
                        <a class="side-link <?= $menuActive('/author/work/create') ?>" href="<?= url('/author/work/create') ?>"><i class="fa-solid fa-plus"></i>新建作品</a>
                        <a class="side-link <?= $navItem('/author/stats', '/') ?>" href="<?= url('/author/stats') ?>"><i class="fa-solid fa-chart-line"></i>数据统计</a>
                        <a class="side-link <?= $navItem('/author/recycle', '/') ?>" href="<?= url('/author/recycle') ?>"><i class="fa-solid fa-trash-can"></i>回收站</a>
                        <a class="side-link <?= $navItem('/author/apply', '/') ?>" href="<?= url('/author/apply') ?>"><i class="fa-solid fa-id-card"></i>认证信息</a>
                    </div>
                    <div class="side-group">
                        <div class="side-group-title">读者</div>
                        <a class="side-link" href="<?= url('/user') ?>"><i class="fa-solid fa-house-user"></i>返回读者中心</a>
                        <a class="side-link" href="<?= url('/user/bookshelf') ?>"><i class="fa-solid fa-bookmark"></i>我的书架</a>
                    </div>
                <?php endif; ?>
            </aside>

            <button class="side-fab" type="button" aria-label="打开中心菜单" aria-expanded="false" aria-controls="accountSide" data-side-fab>
                <i class="fa-solid fa-bars"></i>
            </button>

            <section class="account-main">
                <?= $content ?>
            </section>
        </div>
    </div>
</main>

<script src="<?= e(vendor_sweetalert_js()) ?>"></script>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
