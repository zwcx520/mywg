<?php
/** 读者端公共布局 */
$pageTitle = $pageTitle ?? null;
$titleText = $pageTitle !== null && $pageTitle !== ''
    ? $pageTitle . ' · ' . setting('site_name', '墨韵文阁')
    : setting('site_name', '墨韵文阁') . ' · ' . setting('site_slogan', '在字里行间，与你重逢');
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="<?= e(csrf_token_value()) ?>">
    <title><?= e($titleText) ?></title>
    <meta name="description" content="<?= e(setting('site_desc', '温柔、克制、尊重版权的原创网络文学平台。')) ?>">
    <meta name="keywords" content="<?= e(setting('site_keywords', '网络文学,原创小说,在线阅读,作家平台')) ?>">
    <link rel="stylesheet" href="<?= e(vendor_font_css()) ?>">
    <link rel="stylesheet" href="<?= e(vendor_fontawesome_css()) ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <?php if (!empty($extraCss)): ?>
        <link rel="stylesheet" href="<?= e($extraCss) ?>">
    <?php endif; ?>
</head>
<body class="<?= is_mobile() ? 'mobile-view' : 'desktop-view' ?> <?= e($bodyClass ?? '') ?>">
<?php require __DIR__ . '/../partials/site_header.php'; ?>

<main class="main">
    <div class="container">
        <?php require __DIR__ . '/../partials/flashes.php'; ?>
        <?= $content ?>
    </div>
</main>

<?php require __DIR__ . '/../partials/site_footer.php'; ?>

<script src="<?= e(vendor_sweetalert_js()) ?>"></script>
<script src="<?= asset('js/app.js') ?>"></script>
<?php if (!empty($extraJs)): ?>
    <script src="<?= e($extraJs) ?>"></script>
<?php endif; ?>
</body>
</html>
