<?php /** 错误页 */ ?>
<div style="padding: 70px 0 40px; text-align:center;">
    <div class="eyebrow" style="justify-content:center;">SOMETHING WENT QUIET</div>
    <h1 style="font-size: clamp(52px, 9vw, 96px); letter-spacing: .18em; color: var(--rose-deep); margin-bottom: 8px;">
        <?= (int) ($code ?? 404) ?>
    </h1>
    <h2 style="font-size: 22px; letter-spacing: .1em; margin-bottom: 14px;"><?= e($title ?? '页面走失了') ?></h2>
    <p style="color: var(--ink-faint); font-size: 13px; max-width: 460px; margin: 0 auto 28px; line-height: 2;">
        <?= e($message !== '' ? $message : '也许是一阵风吹乱了书页，换个方向，故事仍在继续。') ?>
    </p>
    <div style="display:flex; gap:10px; justify-content:center; flex-wrap:wrap;">
        <a class="btn btn-primary" href="<?= url('/') ?>"><i class="fa-solid fa-house"></i> 回到首页</a>
        <a class="btn btn-ghost" href="<?= url('/search') ?>"><i class="fa-solid fa-compass"></i> 去找书</a>
    </div>
</div>
