<?php /** 重置密码 */ ?>
<h2 style="font-size:20px;letter-spacing:.1em;margin-bottom:6px;">设置新密码</h2>
<p style="font-size:12px;color:var(--ink-faint);margin-bottom:20px;">重置链接仅可使用一次，有效期 30 分钟。</p>

<form method="post" action="<?= url('/reset-password') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="field" style="margin-bottom:14px;">
        <label for="password">新密码</label>
        <input class="input" id="password" type="password" name="password" minlength="8" placeholder="至少 8 位" required autofocus>
    </div>
    <div class="field" style="margin-bottom:18px;">
        <label for="password_confirm">确认新密码</label>
        <input class="input" id="password_confirm" type="password" name="password_confirm" minlength="8" required>
    </div>
    <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-key"></i> 更新密码</button>
</form>

<div class="auth-foot">
    <a href="<?= url('/login') ?>">← 返回登录</a>
</div>
