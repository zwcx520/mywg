<?php /** 注册 */ ?>
<div class="auth-tabs">
    <a class="auth-tab" href="<?= url('/login') ?>">登录</a>
    <span class="auth-tab is-active">注册</span>
</div>

<form method="post" action="<?= url('/register') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field">
            <label for="login_name">登录名</label>
            <input class="input" id="login_name" type="text" name="login_name" maxlength="20" placeholder="3-20 位中文 / 字母 / 数字" required>
        </div>
        <div class="field">
            <label for="nickname">昵称</label>
            <input class="input" id="nickname" type="text" name="nickname" maxlength="20" placeholder="2-20 个字符" required>
        </div>
        <div class="field">
            <label for="phone">手机号</label>
            <input class="input" id="phone" type="text" name="phone" maxlength="11" placeholder="手机号与邮箱至少填一项">
        </div>
        <div class="field">
            <label for="email">邮箱</label>
            <input class="input" id="email" type="email" name="email" maxlength="120" placeholder="用于找回密码">
        </div>
        <div class="field">
            <label for="password">密码</label>
            <input class="input" id="password" type="password" name="password" minlength="8" placeholder="至少 8 位" required>
        </div>
        <div class="field">
            <label for="password_confirm">确认密码</label>
            <input class="input" id="password_confirm" type="password" name="password_confirm" minlength="8" required>
        </div>
    </div>

    <label class="check-pill" style="margin-top:16px;width:100%;justify-content:flex-start;">
        <input type="checkbox" name="agree" value="1" required>
        <span style="font-size:11.5px;line-height:1.7;">我已阅读并同意《用户协议》《隐私规则》与《内容发布规范》，理解平台执行先审后发制度。</span>
    </label>

    <button class="btn btn-primary btn-block" type="submit" style="margin-top:16px;"><i class="fa-solid fa-user-plus"></i> 创建账号</button>
</form>

<div class="auth-foot">
    已有账号？<a href="<?= url('/login') ?>">直接登录</a>
    <div style="margin-top:10px;"><a href="<?= url('/') ?>" style="color:var(--ink-faint);">← 返回首页</a></div>
</div>
