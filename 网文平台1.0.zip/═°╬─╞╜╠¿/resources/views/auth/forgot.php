<?php /** 找回密码 */ ?>
<h2 style="font-size:20px;letter-spacing:.1em;margin-bottom:6px;">找回密码</h2>
<p style="font-size:12px;color:var(--ink-faint);margin-bottom:20px;">输入登录名、手机号或邮箱，我们会生成一条 30 分钟内有效的重置链接。</p>

<?php if (!empty($sent)): ?>
    <div class="flash flash-success" style="margin-bottom:18px;">
        <i class="fa-solid fa-circle-check"></i>
        <span>如果账号存在，重置链接已生成。请检查站内邮件日志或联系站长。</span>
    </div>
    <?php if (!empty($demoLink)): ?>
        <div class="flash flash-info" style="margin-bottom:18px;display:block;">
            <div style="font-size:11.5px;margin-bottom:6px;">演示模式：可直接使用以下链接</div>
            <a href="<?= e($demoLink) ?>" style="font-size:11.5px;word-break:break-all;color:var(--rose-deep);"><?= e($demoLink) ?></a>
        </div>
    <?php endif; ?>
<?php endif; ?>

<form method="post" action="<?= url('/forgot-password') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <div class="field" style="margin-bottom:16px;">
        <label for="login">账号信息</label>
        <input class="input" id="login" type="text" name="login" placeholder="登录名 / 手机号 / 邮箱" required>
    </div>
    <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-envelope"></i> 生成重置链接</button>
</form>

<div class="auth-foot">
    <a href="<?= url('/login') ?>">← 返回登录</a>
</div>
