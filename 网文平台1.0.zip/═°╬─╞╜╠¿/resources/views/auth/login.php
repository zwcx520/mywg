<?php /** 登录 */ ?>
<div class="auth-tabs">
    <span class="auth-tab is-active">登录</span>
    <a class="auth-tab" href="<?= url('/register') ?>">注册</a>
</div>

<form method="post" action="<?= url('/login') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <input type="hidden" name="next" value="<?= e($next) ?>">

    <div class="field" style="margin-bottom:14px;">
        <label for="login">账号</label>
        <input class="input" id="login" type="text" name="login" placeholder="登录名 / 手机号 / 邮箱" required autofocus>
    </div>
    <div class="field" style="margin-bottom:18px;">
        <label for="password">密码</label>
        <input class="input" id="password" type="password" name="password" placeholder="请输入密码" required>
    </div>

    <button class="btn btn-primary btn-block" type="submit"><i class="fa-solid fa-right-to-bracket"></i> 登录</button>
</form>

<div class="auth-foot">
    <?php if ($next !== ''): ?>
        <div style="margin-bottom:8px;font-size:11.5px;color:var(--rose-deep);">登录后将返回你刚才访问的页面。</div>
    <?php endif; ?>
    <a href="<?= url('/forgot-password') ?>">忘记密码？</a>
    <span style="margin:0 8px;color:var(--line-strong);">|</span>
    <a href="<?= url('/register') ?>">还没有账号，去注册</a>
    <div style="margin-top:10px;"><a href="<?= url('/') ?>" style="color:var(--ink-faint);">← 返回首页</a></div>
</div>
