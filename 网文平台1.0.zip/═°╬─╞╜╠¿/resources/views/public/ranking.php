<?php
/** 榜单页 */
$pageTitle = $ranking['name'] ?? '排行榜';
?>
<div class="page-hero">
    <div class="eyebrow">RANKING BOARD</div>
    <h1><?= e($ranking['name'] ?? '排行榜') ?></h1>
    <p>规则公开、数据可解释。榜单只收录已通过审核并处于公开状态的作品。</p>
</div>

<div class="ranking-tabs">
    <?php foreach ($rankings as $item): ?>
        <a class="chip <?= (string) $ranking['code'] === (string) $item['code'] ? 'is-active' : '' ?>"
           href="<?= url('/ranking/' . $item['code'], $categoryId > 0 ? ['cat' => $categoryId] : []) ?>">
            <?= e($item['name']) ?>
        </a>
    <?php endforeach; ?>
</div>

<div class="ranking-tabs chip-scroll" style="margin-top:-10px;">
    <a class="chip <?= $categoryId === 0 ? 'is-active' : '' ?>" href="<?= url('/ranking/' . $ranking['code']) ?>">全部类别</a>
    <?php foreach ($categories as $category): ?>
        <a class="chip <?= $categoryId === (int) $category['id'] ? 'is-active' : '' ?>"
           href="<?= url('/ranking/' . $ranking['code'], ['cat' => (int) $category['id']]) ?>"><?= e($category['name']) ?></a>
    <?php endforeach; ?>
</div>

<div class="ranking-board">
    <div class="formula">
        <i class="fa-solid fa-scale-balanced"></i>
        <?= e($formula) ?>
        <?php if (!empty($ranking['description'])): ?> · <?= e($ranking['description']) ?><?php endif; ?>
    </div>

    <?php if ($books === []): ?>
        <div class="empty"><i class="fa-solid fa-ranking-star"></i><p>当前榜单暂无可展示作品，稍后再来看看。</p></div>
    <?php else: ?>
        <?php foreach ($books as $index => $book): ?>
            <div class="ranking-row">
                <div class="no"><?= $index + 1 ?></div>
                <a class="book-cover" href="<?= url('/book/' . (int) $book['id']) ?>"
                   style="width:56px; aspect-ratio:3/4; background: <?= e(cover_gradient((int) $book['id'])) ?>;">
                    <?php if (!empty($book['cover'])): ?>
                        <img src="<?= e(upload_url((string) $book['cover'])) ?>" alt="">
                    <?php endif; ?>
                    <span class="cover-title" style="font-size:10px;"><?= e($book['title']) ?></span>
                </a>
                <div style="min-width:0;">
                    <a href="<?= url('/book/' . (int) $book['id']) ?>" style="font-family:var(--serif);font-size:16px;"><?= e($book['title']) ?></a>
                    <div style="font-size:11.5px;color:var(--ink-faint);margin-top:4px;">
                        <?= author_avatar($book['pen_name'] ?? null, 'xs', $book['author_avatar'] ?? null) ?><?= e($book['pen_name']) ?>
                        <span style="margin:0 6px;">·</span><?= e($book['category_name'] ?? '未分类') ?>
                        <span style="margin:0 6px;">·</span><?= number_format((int) $book['word_count']) ?> 字
                        <span style="margin:0 6px;">·</span><?= e(status_label((string) $book['status'])) ?>
                    </div>
                    <div style="font-size:12px;color:var(--ink-soft);margin-top:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:560px;">
                        <?= e(excerpt((string) $book['summary'], 80)) ?>
                    </div>
                </div>
                <div style="text-align:right;">
                    <div style="font-family:var(--serif);font-size:18px;color:var(--gold-deep);"><?= number_format((float) $book['rank_score'], 0) ?></div>
                    <div style="font-size:10.5px;color:var(--ink-faint);">榜面分值</div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
