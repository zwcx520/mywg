<?php
/** 活动列表 */
$pageTitle = '站内活动';
?>
<div class="page-hero">
    <div class="eyebrow">ACTIVITIES</div>
    <h1>站内活动</h1>
    <p>写作、阅读与相遇的小小理由。</p>
</div>

<?php if ($items === []): ?>
    <div class="empty"><i class="fa-solid fa-gift"></i><p>暂时没有进行中的活动。</p></div>
<?php else: ?>
    <div class="notice-grid">
        <?php foreach ($items as $item): ?>
            <a class="notice-card" href="<?= url('/activity/' . (int) $item['id']) ?>">
                <span class="date" style="color:var(--gold-deep);">
                    活动 <?= format_date($item['start_at'] ?? $item['created_at']) ?>
                    <?php if (!empty($item['end_at'])): ?> — <?= format_date($item['end_at']) ?><?php endif; ?>
                </span>
                <h3><?= e($item['title']) ?></h3>
                <p><?= e(excerpt((string) $item['content'], 120)) ?></p>
            </a>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
