<?php
/** 作品目录 */
$pageTitle = $book['title'] . ' · 目录';
?>
<div class="catalog-head">
    <div class="catalog-head-main">
        <a class="catalog-cover" href="<?= url('/book/' . (int) $book['id']) ?>" style="background: <?= e(cover_gradient((int) $book['id'])) ?>;">
            <?php if (!empty($book['cover'])): ?>
                <img src="<?= e(upload_url((string) $book['cover'])) ?>" alt="<?= e($book['title']) ?>">
            <?php endif; ?>
            <span><?= e($book['title']) ?></span>
        </a>
        <div style="min-width:0;">
            <div style="font-size:11px;letter-spacing:.18em;color:var(--rose-deep);margin-bottom:6px;">CATALOG</div>
            <h1 style="font-size:24px;letter-spacing:.08em;"><?= e($book['title']) ?></h1>
            <div style="font-size:12px;color:var(--ink-faint);margin-top:6px;">
                <?= author_avatar($book['pen_name'] ?? null, 'xs', $book['author_avatar'] ?? null) ?><?= e($book['pen_name']) ?> · <?= e(status_label((string) $book['status'])) ?> · 共 <?= (int) $total ?> 章 · <?= number_format((int) $book['word_count']) ?> 字
            </div>
        </div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <a class="btn btn-ghost btn-sm" href="<?= url('/book/' . (int) $book['id']) ?>"><i class="fa-solid fa-circle-info"></i> 作品详情</a>
        <?php if (!empty($last)): ?>
            <a class="btn btn-primary btn-sm" href="<?= url('/chapter/' . (int) $last['id']) ?>"><i class="fa-solid fa-book-open"></i> 读最新章</a>
        <?php endif; ?>
    </div>
</div>

<?php if ($volumes === []): ?>
    <div class="empty"><i class="fa-solid fa-book"></i><p>作者还没有发布章节，先去收藏这本书吧。</p></div>
<?php else: ?>
    <?php foreach ($volumes as $volume): ?>
        <section class="volume-block">
            <div class="volume-title">
                <span><?= e($volume['title']) ?></span>
                <span style="font-size:11px;font-weight:400;color:var(--ink-faint);"><?= count($volume['chapters']) ?> 章</span>
            </div>
            <?php if ($volume['chapters'] === []): ?>
                <p style="font-size:12px;color:var(--ink-faint);padding:10px 0;">本卷暂无已发布章节。</p>
            <?php else: ?>
                <div class="catalog-grid">
                    <?php foreach ($volume['chapters'] as $chapter): ?>
                        <a class="chapter-row" href="<?= url('/chapter/' . (int) $chapter['id']) ?>">
                            <span class="no"><?= (int) $chapter['chapter_no'] ?></span>
                            <span class="title"><?= e($chapter['title']) ?></span>
                            <?php if (!empty($chapter['is_paid'])): ?>
                                <span class="badge badge-gold" style="font-size:10px;">免费开放</span>
                            <?php endif; ?>
                            <span class="meta"><?= e(word_count_text((int) $chapter['word_count'])) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
<?php endif; ?>
