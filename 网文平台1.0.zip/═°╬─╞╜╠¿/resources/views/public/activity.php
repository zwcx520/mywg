<?php
/** 活动详情 */
$pageTitle = $item['title'];
?>
<div class="container-narrow" style="padding: 20px 0 10px;">
    <a class="more-link" href="<?= url('/activities') ?>"><i class="fa-solid fa-arrow-left"></i> 返回活动列表</a>
    <div class="page-hero" style="margin-top:18px;">
        <div class="eyebrow" style="color:var(--gold-deep);">ACTIVITY · <?= format_date($item['start_at'] ?? $item['created_at']) ?></div>
        <h1 style="font-size: clamp(24px, 3vw, 32px);"><?= e($item['title']) ?></h1>
        <?php if (!empty($item['end_at'])): ?>
            <p>活动截止：<?= format_date($item['end_at']) ?></p>
        <?php endif; ?>
    </div>
    <article class="panel" style="font-size:14px;line-height:2.1;color:var(--ink-soft);white-space:pre-wrap;">
        <?= e($item['content']) ?>
    </article>
    <div class="panel" style="background: rgba(216,180,138,.1); border:1px dashed rgba(184,140,96,.4);">
        <p style="font-size:12px;color:#8a6438;line-height:1.9;">
            <i class="fa-solid fa-circle-info"></i>
            第一版活动不关联任何付费、充值、打赏与订阅行为，所有参与均免费。
        </p>
    </div>
</div>
