<?php
/** 阅读页 */
$pageTitle = $chapter['title'] . ' · ' . $book['title'];
$bodyClass = 'reader-body reader-theme-' . ($prefs['theme'] ?? 'light');
?>
<div class="reader-toolbar" data-reader-toolbar>
    <div class="reader-fab-wrap">
        <div class="reader-fab-list" id="readerFabList">
            <span class="reader-tool-title"><?= e($book['title']) ?> · 第 <?= (int) $chapter['chapter_no'] ?> 章 <?= e($chapter['title']) ?></span>
            <button class="reader-tool" type="button" data-reader-drawer-open aria-label="目录"><i class="fa-solid fa-list"></i></button>
            <a class="reader-tool" href="<?= url('/book/' . (int) $book['id']) ?>" aria-label="作品详情"><i class="fa-solid fa-circle-info"></i></a>
            <button class="reader-tool" type="button" data-reader-open-settings aria-label="阅读设置"><i class="fa-solid fa-sliders"></i></button>
            <?php if ($currentUser !== null): ?>
                <a class="reader-tool" href="<?= url('/report', ['target_type' => 'chapter', 'target_id' => (int) $chapter['id']]) ?>" aria-label="举报本章"><i class="fa-solid fa-flag"></i></a>
            <?php endif; ?>
        </div>
        <button class="reader-fab" type="button" data-reader-toolbar-toggle aria-label="展开阅读工具" aria-expanded="false" aria-controls="readerFabList">
            <i class="fa-solid fa-bars"></i>
        </button>
    </div>
</div>

<div class="reader-wrap">
    <h1 class="reader-title"><?= e($chapter['title']) ?></h1>
    <div class="reader-sub">
        <?= author_avatar($book['pen_name'] ?? null, 'xs', $book['author_avatar'] ?? null) ?><?= e($book['pen_name']) ?> · 第 <?= (int) $chapter['chapter_no'] ?> 章 · <?= e(word_count_text((int) $chapter['word_count'])) ?>
        · <?= format_date($chapter['published_at']) ?>
    </div>
    <?php if ($paidNote !== null): ?>
        <div class="reader-paidnote"><i class="fa-solid fa-gift"></i> <?= e($paidNote) ?></div>
    <?php endif; ?>

    <article class="reader-content" data-reader-content><?= e($content) ?></article>

    <div class="reader-nav">
        <?php if (!empty($prev)): ?>
            <a class="btn btn-ghost" href="<?= url('/chapter/' . (int) $prev['id']) ?>" data-reader-prev>
                <i class="fa-solid fa-arrow-left"></i> 上一章
            </a>
        <?php else: ?>
            <span class="btn btn-ghost" style="opacity:.4;cursor:not-allowed;"><i class="fa-solid fa-arrow-left"></i> 已是第一章</span>
        <?php endif; ?>
        <?php if (!empty($next)): ?>
            <a class="btn btn-primary" href="<?= url('/chapter/' . (int) $next['id']) ?>" data-reader-next>
                下一章 <i class="fa-solid fa-arrow-right"></i>
            </a>
        <?php else: ?>
            <span class="btn btn-primary" style="opacity:.45;cursor:not-allowed;">已是最新章 <i class="fa-solid fa-check"></i></span>
        <?php endif; ?>
    </div>

    <div style="text-align:center;margin-top:26px;">
        <a class="more-link" href="<?= url('/book/' . (int) $book['id'] . '/catalog') ?>"><i class="fa-solid fa-list"></i> 返回目录</a>
    </div>

    <?php if ($currentUser !== null): ?>
        <form method="post" action="<?= url('/user/settings') ?>" data-reader-pref-form style="display:none;">
            <?= csrf_field() ?>
            <input type="hidden" name="font_size" value="<?= (int) $prefs['font_size'] ?>">
            <input type="hidden" name="line_height" value="<?= (int) $prefs['line_height'] ?>">
            <input type="hidden" name="theme" value="<?= e($prefs['theme']) ?>">
            <input type="hidden" name="reading_mode" value="<?= e($prefs['reading_mode']) ?>">
            <input type="hidden" name="from_chapter" value="<?= (int) $chapter['id'] ?>">
        </form>
    <?php endif; ?>
</div>

<div class="reader-drawer" data-reader-drawer>
    <div class="mask"></div>
    <aside class="sheet">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;">
            <h3 style="margin:0;">目录</h3>
            <button class="reader-tool" type="button" data-reader-drawer-close><i class="fa-solid fa-xmark"></i></button>
        </div>
        <?php foreach ($volumes as $volume): ?>
            <div style="font-size:12px;letter-spacing:.1em;color:var(--rose-deep);margin:16px 0 8px;"><?= e($volume['title']) ?></div>
            <?php foreach ($volume['chapters'] as $item): ?>
                <a class="chapter-row <?= (int) $item['id'] === (int) $chapter['id'] ? 'is-current' : '' ?>"
                   href="<?= url('/chapter/' . (int) $item['id']) ?>"
                   style="<?= (int) $item['id'] === (int) $chapter['id'] ? 'background:rgba(192,132,151,.14);color:var(--rose-deep);' : '' ?>">
                    <span class="no"><?= (int) $item['chapter_no'] ?></span>
                    <span class="title"><?= e($item['title']) ?></span>
                </a>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </aside>
</div>

<div class="reader-drawer" data-reader-settings>
    <div class="mask" data-reader-close-settings></div>
    <aside class="sheet" style="left:auto;right:0;transform:translateX(100%);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;">
            <h3 style="margin:0;">阅读设置</h3>
            <button class="reader-tool" type="button" data-reader-close-settings><i class="fa-solid fa-xmark"></i></button>
        </div>

        <div style="font-size:11px;letter-spacing:.12em;color:var(--ink-faint);margin-bottom:8px;">字号</div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px;">
            <button class="btn btn-ghost btn-sm" type="button" data-reader-font="-1">A-</button>
            <span data-reader-fontsize style="font-size:12px;color:var(--ink-soft);min-width:44px;text-align:center;"><?= (int) $prefs['font_size'] ?>px</span>
            <button class="btn btn-ghost btn-sm" type="button" data-reader-font="1">A+</button>
        </div>

        <div style="font-size:11px;letter-spacing:.12em;color:var(--ink-faint);margin-bottom:8px;">行距</div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px;">
            <button class="btn btn-ghost btn-sm" type="button" data-reader-line="-0.1">紧凑</button>
            <span data-reader-lineheight style="font-size:12px;color:var(--ink-soft);min-width:44px;text-align:center;"><?= number_format((float) $prefs['line_height'], 1) ?></span>
            <button class="btn btn-ghost btn-sm" type="button" data-reader-line="0.1">宽松</button>
        </div>

        <div style="font-size:11px;letter-spacing:.12em;color:var(--ink-faint);margin-bottom:8px;">主题</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <button class="chip <?= $prefs['theme'] === 'light' ? 'is-active' : '' ?>" type="button" data-reader-theme-btn="light">暖白</button>
            <button class="chip <?= $prefs['theme'] === 'sepia' ? 'is-active' : '' ?>" type="button" data-reader-theme-btn="sepia">纸黄</button>
            <button class="chip <?= $prefs['theme'] === 'night' ? 'is-active' : '' ?>" type="button" data-reader-theme-btn="night">夜读</button>
        </div>

        <div style="margin-top:22px;padding-top:16px;border-top:1px dashed var(--line);font-size:11px;color:var(--ink-faint);line-height:1.9;">
            阅读偏好保存在本机；登录后会同步到账号设置。可使用键盘 ← → 切换章节。
        </div>
    </aside>
</div>

<style>
.reader-drawer[data-reader-settings] .sheet.is-open { transform: none; }
.reader-drawer[data-reader-settings].is-open .sheet[style*="translateX(100%)"] { transform: translateX(0) !important; }
</style>
