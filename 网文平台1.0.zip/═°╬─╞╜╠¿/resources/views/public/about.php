<?php
/** 关于我们 */
$pageTitle = '关于我们';
?>
<div class="container-narrow" style="padding: 10px 0 20px;">
    <div class="page-hero">
        <div class="eyebrow">ABOUT</div>
        <h1>关于 <?= e(setting('site_name', '墨韵文阁')) ?></h1>
        <p><?= e(setting('site_slogan', '在字里行间，与你重逢')) ?></p>
    </div>

    <article class="panel" style="font-size:13.5px;line-height:2.1;color:var(--ink-soft);white-space:pre-wrap;">
        <?= e(setting('about_text', setting('site_desc', '一个温柔、克制、尊重版权的原创网络文学平台。')) . "\n\n" .
            "我们相信，好的故事值得被认真对待。所有作品在公开展示前都会经过内容审核，执行先审后发制度；作者的原稿、审核版本、发布版本与历史版本彼此分离，发布后的编辑不会覆盖读者正在阅读的内容。\n\n" .
            "平台尊重每一位作者的版权，也尊重每一位读者的阅读体验。若你发现侵权、违规或不适宜的内容，可以通过举报入口反馈，我们会逐条处理并留下可追溯的处置记录。\n\n" .
            "第一版为纯内容社区，不开放充值、订阅、章节购买、打赏、自动订阅、月票、打赏礼物与作者结算。带有付费标识的历史章节在此期间全部免费开放。")) ?>
    </article>

    <div class="notice-grid" style="margin-top:20px;">
        <div class="panel" style="margin-bottom:0;">
            <div class="eyebrow">内容原则</div>
            <p style="font-size:12.5px;line-height:2;color:var(--ink-soft);">先审后发 · 版权优先 · 拒绝抄袭 · 保护未成年读者 · 处置留痕</p>
        </div>
        <div class="panel" style="margin-bottom:0;">
            <div class="eyebrow">联系我们</div>
            <p style="font-size:12.5px;line-height:2;color:var(--ink-soft);">
                邮箱：<?= e(setting('contact_email', '未设置')) ?><br>
                举报：登录后通过作品页或阅读页的举报入口提交。
            </p>
        </div>
    </div>

    <div style="text-align:center;margin-top:24px;">
        <a class="btn btn-soft btn-sm" href="<?= url('/author/apply') ?>"><i class="fa-solid fa-feather-pointed"></i> 申请成为作者</a>
        <a class="btn btn-ghost btn-sm" href="<?= url('/report') ?>"><i class="fa-solid fa-flag"></i> 内容举报</a>
    </div>
</div>
