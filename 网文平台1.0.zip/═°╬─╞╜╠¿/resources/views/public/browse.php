<?php
/** 找书 / 分类列表 */
$pageTitle = $heading;
$isSearch = ($mode ?? '') === 'search';
?>
<div class="page-hero">
    <div class="eyebrow"><?= $isSearch ? 'SEARCH THE SHELF' : 'BROWSE BY CATEGORY' ?></div>
    <h1><?= e($heading) ?></h1>
    <p><?= e($subheading ?? '') ?></p>
</div>

<?php if ($isSearch): ?>
<form class="search-hero" action="<?= url('/search') ?>" method="get">
    <input type="hidden" name="r" value="/search">
    <input type="search" name="q" value="<?= e($keyword) ?>" placeholder="输入书名、作者笔名或标签关键词">
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> 搜索</button>
</form>
<?php endif; ?>

<?php
$topCategories = array_values(array_filter($categories, static fn ($c) => (int) ($c['parent_id'] ?? 0) === 0));
$childrenByParent = [];
foreach ($categories as $c) {
    if ((int) ($c['parent_id'] ?? 0) > 0) {
        $childrenByParent[(int) $c['parent_id']][] = $c;
    }
}
?>
<form class="filters" method="get" action="<?= url($basePath) ?>">
    <input type="hidden" name="r" value="<?= e($basePath) ?>">
    <?php if ($isSearch && $keyword !== ''): ?>
        <input type="hidden" name="q" value="<?= e($keyword) ?>">
    <?php endif; ?>

    <div class="filter-row">
        <span class="filter-label">分类</span>
        <div class="filter-options chip-scroll">
            <a class="chip <?= (int) $categoryId === 0 ? 'is-active' : '' ?>" href="<?= url($basePath, $isSearch && $keyword !== '' ? ['q' => $keyword] : []) ?>">全部</a>
            <?php foreach ($topCategories as $category): ?>
                <a class="chip <?= (int) $categoryId === (int) $category['id'] ? 'is-active' : '' ?>"
                   href="<?= url('/category/' . (int) $category['id']) ?>"><?= e($category['name']) ?></a>
                <?php foreach ($childrenByParent[(int) $category['id']] ?? [] as $child): ?>
                    <a class="chip <?= (int) $categoryId === (int) $child['id'] ? 'is-active' : '' ?>"
                       href="<?= url('/category/' . (int) $child['id']) ?>" style="font-size:11px;"><?= e($child['name']) ?></a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="filter-row">
        <span class="filter-label">排序</span>
        <div class="filter-options chip-scroll">
            <?php foreach (['updated' => '最近更新', 'new' => '最新上架', 'heat' => '热度', 'favorite' => '收藏', 'rating' => '评分'] as $key => $label): ?>
                <label class="chip <?= ($filters['sort'] ?? '') === $key ? 'is-active' : '' ?>" style="cursor:pointer;">
                    <input type="radio" name="sort" value="<?= $key ?>" <?= ($filters['sort'] ?? '') === $key ? 'checked' : '' ?> style="display:none;">
                    <?= e($label) ?>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="filter-row">
        <span class="filter-label">状态</span>
        <div class="filter-options chip-scroll">
            <?php foreach (['all' => '全部', 'serializing' => '连载中', 'finished' => '已完结', 'paused' => '暂停更新'] as $key => $label): ?>
                <label class="chip <?= ($filters['status'] ?? 'all') === $key ? 'is-active' : '' ?>" style="cursor:pointer;">
                    <input type="radio" name="status" value="<?= $key ?>" <?= ($filters['status'] ?? 'all') === $key ? 'checked' : '' ?> style="display:none;">
                    <?= e($label) ?>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="filter-row">
        <span class="filter-label">字数</span>
        <div class="filter-options chip-scroll">
            <?php foreach (['all' => '不限', 'lt30' => '30 万以下', '30to100' => '30-100 万', 'gt100' => '100 万以上'] as $key => $label): ?>
                <label class="chip <?= ($filters['words'] ?? 'all') === $key ? 'is-active' : '' ?>" style="cursor:pointer;">
                    <input type="radio" name="words" value="<?= $key ?>" <?= ($filters['words'] ?? 'all') === $key ? 'checked' : '' ?> style="display:none;">
                    <?= e($label) ?>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="filter-row">
        <span class="filter-label">更新</span>
        <div class="filter-options chip-scroll">
            <?php foreach (['all' => '不限', '7' => '7 天内', '30' => '30 天内'] as $key => $label): ?>
                <label class="chip <?= ($filters['updated'] ?? 'all') === $key ? 'is-active' : '' ?>" style="cursor:pointer;">
                    <input type="radio" name="updated" value="<?= $key ?>" <?= ($filters['updated'] ?? 'all') === $key ? 'checked' : '' ?> style="display:none;">
                    <?= e($label) ?>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if ($tags !== []): ?>
    <div class="filter-row">
        <span class="filter-label">标签</span>
        <div class="filter-options chip-scroll">
            <?php foreach ($tags as $tag): ?>
                <label class="check-pill">
                    <input type="checkbox" name="tags[]" value="<?= (int) $tag['id'] ?>" <?= in_array((int) $tag['id'], $filters['tags'] ?? [], true) ? 'checked' : '' ?>>
                    <?= e($tag['name']) ?>
                </label>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="filter-actions">
        <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-filter"></i> 应用筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url($basePath) ?>">重置</a>
        <span style="margin-left:auto;font-size:11.5px;color:var(--ink-faint);align-self:center;">共 <?= (int) $pager['total'] ?> 部作品</span>
    </div>
</form>

<?php if ($books === []): ?>
    <div class="empty">
        <i class="fa-solid fa-magnifying-glass"></i>
        <p><?= $isSearch ? '没有找到与「' . e($keyword) . '」相关的作品，换一个关键词试试？' : '这个分类暂时还没有作品。' ?></p>
    </div>
<?php else: ?>
    <div class="result-grid">
        <?php foreach ($books as $book): ?>
            <?php require __DIR__ . '/../partials/book_card.php'; ?>
        <?php endforeach; ?>
    </div>
    <?= pager_html($pager) ?>
<?php endif; ?>
