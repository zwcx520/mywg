<?php
/** 公告详情 */
$pageTitle = $item['title'];
?>
<div class="container-narrow" style="padding: 20px 0 10px;">
    <a class="more-link" href="<?= url('/announcements') ?>"><i class="fa-solid fa-arrow-left"></i> 返回公告列表</a>
    <div class="page-hero" style="margin-top:18px;">
        <div class="eyebrow">ANNOUNCEMENT · <?= format_date($item['published_at'] ?? $item['created_at']) ?></div>
        <h1 style="font-size: clamp(24px, 3vw, 32px);"><?= e($item['title']) ?></h1>
    </div>
    <article class="panel" style="font-size:14px;line-height:2.1;color:var(--ink-soft);white-space:pre-wrap;">
        <?= e($item['content']) ?>
    </article>
</div>
