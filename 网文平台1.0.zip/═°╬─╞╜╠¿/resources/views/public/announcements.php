<?php
/** 公告列表 */
$pageTitle = '平台公告';
?>
<div class="page-hero">
    <div class="eyebrow">ANNOUNCEMENTS</div>
    <h1>平台公告</h1>
    <p>关于规则、审核与站点变化的正式说明。</p>
</div>

<?php if ($items === []): ?>
    <div class="empty"><i class="fa-solid fa-bullhorn"></i><p>目前没有生效中的公告。</p></div>
<?php else: ?>
    <div class="simple-list" style="gap:14px;">
        <?php foreach ($items as $item): ?>
            <a class="notice-card" href="<?= url('/announcement/' . (int) $item['id']) ?>" style="display:block;">
                <span class="date"><?= format_date($item['published_at'] ?? $item['created_at']) ?></span>
                <h3><?= e($item['title']) ?></h3>
                <p><?= e(excerpt((string) $item['content'], 140)) ?></p>
            </a>
        <?php endforeach; ?>
    </div>
    <?= pager_html($pager) ?>
<?php endif; ?>
