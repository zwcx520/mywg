<?php
/** 作品详情 */
$pageTitle = $book['title'];
$publicBook = true;
?>
<div class="book-hero">
    <div class="detail-cover" style="background: <?= e(cover_gradient((int) $book['id'])) ?>;">
        <?php if (!empty($book['cover'])): ?>
            <img src="<?= e(upload_url((string) $book['cover'])) ?>" alt="<?= e($book['title']) ?>">
        <?php endif; ?>
        <span class="cover-title"><?= e($book['title']) ?></span>
    </div>

    <div class="detail-info">
        <div class="detail-cat"><?= e($book['category_name'] ?? '未分类') ?> · <?= e($book['category_parent_name'] ?? '原创文学') ?></div>
        <h1><?= e($book['title']) ?></h1>
        <div class="detail-meta">
            <span><?= author_avatar($book['pen_name'] ?? null, 'xs', $book['author_avatar'] ?? null) ?><?= e($book['pen_name']) ?></span>
            <span><i class="fa-solid fa-circle-dot"></i> <?= e(status_label((string) $book['status'])) ?></span>
            <span><i class="fa-solid fa-file-lines"></i> <?= number_format((int) $book['word_count']) ?> 字</span>
            <span><i class="fa-solid fa-list"></i> <?= (int) $chapterCount ?> 章</span>
            <span><i class="fa-solid fa-clock"></i> 更新于 <?= time_ago($book['updated_at']) ?></span>
        </div>

        <?php if ($tags !== []): ?>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px;">
                <?php foreach ($tags as $tag): ?>
                    <a class="chip" href="<?= url('/search', ['q' => $tag['name']]) ?>"><?= e($tag['name']) ?></a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="detail-body">
        <div class="detail-actions">
            <a class="btn btn-primary" href="<?= url('/book/' . (int) $book['id'] . '/catalog') ?>">
                <i class="fa-solid fa-book-open"></i> 开始阅读
            </a>

            <?php if ($currentUser !== null): ?>
                <?php if ($inShelf): ?>
                    <form method="post" action="<?= url('/user/bookshelf/remove') ?>" data-lock-submit>
                        <?= csrf_field() ?>
                        <input type="hidden" name="book_id" value="<?= (int) $book['id'] ?>">
                        <button class="btn btn-soft" type="submit"><i class="fa-solid fa-bookmark"></i> 已在书架</button>
                    </form>
                <?php else: ?>
                    <form method="post" action="<?= url('/user/bookshelf/add') ?>" data-lock-submit>
                        <?= csrf_field() ?>
                        <input type="hidden" name="book_id" value="<?= (int) $book['id'] ?>">
                        <input type="hidden" name="group_name" value="默认分组">
                        <button class="btn btn-soft" type="submit"><i class="fa-regular fa-bookmark"></i> 加入书架</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <a class="btn btn-soft" href="<?= url('/login', ['next' => '/book/' . (int) $book['id']]) ?>"><i class="fa-regular fa-bookmark"></i> 加入书架</a>
            <?php endif; ?>

            <a class="btn btn-ghost" href="<?= url('/report', ['target_type' => 'book', 'target_id' => (int) $book['id']]) ?>">
                <i class="fa-solid fa-flag"></i> 举报
            </a>
        </div>

        <div class="stat-row">
            <div class="stat-item"><strong><?= number_format((int) $book['view_count']) ?></strong><span>阅读量</span></div>
            <div class="stat-item"><strong><?= number_format((int) $book['favorite_count']) ?></strong><span>收藏</span></div>
            <div class="stat-item"><strong><?= number_format((int) $book['rating_count']) ?></strong><span>评分人数</span></div>
            <div class="stat-item"><strong><?= number_format((float) $book['rating'], 1) ?></strong><span>作品评分</span></div>
        </div>

        <?php if ($currentUser !== null): ?>
            <form method="post" action="<?= url('/rate') ?>" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:16px;padding-top:14px;border-top:1px dashed var(--line);">
                <?= csrf_field() ?>
                <input type="hidden" name="book_id" value="<?= (int) $book['id'] ?>">
                <span style="font-size:12px;color:var(--ink-faint);">为本书打分</span>
                <select class="input" name="score" style="width:auto;padding:6px 10px;">
                    <?php for ($i = 10; $i >= 1; $i--): ?>
                        <option value="<?= $i ?>" <?= $userRating === $i ? 'selected' : '' ?>><?= $i ?> 分</option>
                    <?php endfor; ?>
                </select>
                <button class="btn btn-gold btn-sm" type="submit"><i class="fa-solid fa-star"></i> 提交评分</button>
                <?php if ($userRating > 0): ?>
                    <span style="font-size:11.5px;color:var(--gold-deep);">你已评 <?= $userRating ?> 分</span>
                <?php endif; ?>
            </form>
        <?php endif; ?>
    </div>

    <p class="detail-summary"><?= e($book['summary']) ?></p>
</div>

<div class="detail-grid">
    <div class="detail-main">
        <div class="book-tabs" data-book-tabs>
            <button class="book-tab is-active" type="button" data-book-tab="catalog" aria-controls="bookPanelCatalog">
                <i class="fa-solid fa-file-lines"></i> 目录 <span class="book-tab-badge"><?= (int) $chapterCount ?></span>
            </button>
            <button class="book-tab" type="button" data-book-tab="comments" aria-controls="bookPanelComments">
                <i class="fa-solid fa-comments"></i> 读者评论 <span class="book-tab-badge"><?= (int) $commentTotal ?></span>
            </button>
        </div>

        <section class="panel book-tab-panel is-active" id="bookPanelCatalog" data-book-panel="catalog">
            <div class="panel-head">
                <h2><i class="fa-solid fa-file-lines" style="color:var(--rose);margin-right:8px;"></i>最新章节</h2>
                <a class="more-link" href="<?= url('/book/' . (int) $book['id'] . '/catalog') ?>">查看全部 <?= (int) $chapterCount ?> 章 <i class="fa-solid fa-arrow-right"></i></a>
            </div>
            <div class="chapter-list">
                <?php foreach ($latestChapters as $chapter): ?>
                    <a class="chapter-row" href="<?= url('/chapter/' . (int) $chapter['id']) ?>">
                        <span class="no">第 <?= (int) $chapter['chapter_no'] ?> 章</span>
                        <span class="title"><?= e($chapter['title']) ?></span>
                        <?php if (!empty($chapter['is_paid'])): ?>
                            <span class="badge badge-gold">付费标识 · 免费开放</span>
                        <?php endif; ?>
                        <span class="meta"><?= e(word_count_text((int) $chapter['word_count'])) ?> · <?= time_ago($chapter['published_at']) ?></span>
                    </a>
                <?php endforeach; ?>
                <?php if ($latestChapters === []): ?>
                    <div class="empty" style="margin-top:12px;"><i class="fa-solid fa-pen-nib"></i><p>作者还未发布章节。</p></div>
                <?php endif; ?>
            </div>
        </section>

        <section class="panel book-tab-panel" id="comments" data-book-panel="comments">
            <div class="panel-head">
                <h2><i class="fa-solid fa-comments" style="color:var(--rose);margin-right:8px;"></i>读者评论 <span style="font-size:12px;color:var(--ink-faint);font-weight:400;"><?= (int) $commentTotal ?></span></h2>
            </div>

            <?php if ($currentUser !== null): ?>
                <form class="comment-form" method="post" action="<?= url('/comment') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="book_id" value="<?= (int) $book['id'] ?>">
                    <input type="hidden" name="back" value="<?= e('/book/' . (int) $book['id'] . '#comments') ?>">
                    <textarea name="content" maxlength="500" placeholder="写下你读到的心情，温柔一点，故事会更长。" required></textarea>
                    <div class="row">
                        <span style="font-size:11px;color:var(--ink-faint);">评论可能进入审核队列，请耐心等待。</span>
                        <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-paper-plane"></i> 发表评论</button>
                    </div>
                </form>
            <?php else: ?>
                <div class="empty" style="padding:22px;">
                    <p><a href="<?= url('/login') ?>" style="color:var(--rose-deep);">登录</a> 后可以为这本书留下评论。</p>
                </div>
            <?php endif; ?>

            <?php if ($comments !== []): ?>
                <div class="comment-list" style="margin-top:22px;">
                    <?php foreach ($comments as $comment): ?>
                        <div class="comment-item">
                            <span class="comment-avatar">
                                <?php if (!empty($comment['avatar'])): ?>
                                    <img src="<?= e(upload_url((string) $comment['avatar'])) ?>" alt="">
                                <?php else: ?>
                                    <?= e(mb_substr((string) ($comment['nickname'] ?? '读'), 0, 1, 'UTF-8')) ?>
                                <?php endif; ?>
                            </span>
                            <div>
                                <div class="comment-head">
                                    <span class="comment-name"><?= e($comment['nickname'] ?? '匿名读者') ?></span>
                                    <span class="comment-time"><?= time_ago($comment['created_at']) ?></span>
                                </div>
                                <div class="comment-body"><?= nl2br(e($comment['content'])) ?></div>
                                <div class="comment-actions">
                                    <?php if ($currentUser !== null): ?>
                                        <form method="post" action="<?= url('/comment/like') ?>" style="display:inline;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="comment_id" value="<?= (int) $comment['id'] ?>">
                                            <input type="hidden" name="back" value="<?= e('/book/' . (int) $book['id'] . '#comments') ?>">
                                            <button type="submit"><i class="fa-regular fa-heart"></i> <?= (int) $comment['like_count'] ?></button>
                                        </form>
                                        <details style="display:inline;">
                                            <summary style="cursor:pointer;list-style:none;">回复</summary>
                                            <form method="post" action="<?= url('/comment') ?>" style="margin-top:8px;display:flex;gap:8px;">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="book_id" value="<?= (int) $book['id'] ?>">
                                                <input type="hidden" name="parent_id" value="<?= (int) $comment['id'] ?>">
                                                <input type="hidden" name="back" value="<?= e('/book/' . (int) $book['id'] . '#comments') ?>">
                                                <input class="input" type="text" name="content" maxlength="500" placeholder="回复这条评论…" style="flex:1;">
                                                <button class="btn btn-soft btn-sm" type="submit">发送</button>
                                            </form>
                                        </details>
                                    <?php else: ?>
                                        <span><i class="fa-regular fa-heart"></i> <?= (int) $comment['like_count'] ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($comment['replies'] !== []): ?>
                                    <div class="comment-replies">
                                        <?php foreach ($comment['replies'] as $reply): ?>
                                            <div class="comment-reply"><strong><?= e($reply['nickname'] ?? '读者') ?></strong>：<?= e($reply['content']) ?></div>
                                        <?php endforeach; ?>
                                        <?php if (count($comment['replies']) >= 3): ?>
                                            <div style="font-size:11px;color:var(--ink-faint);">更多回复已折叠。</div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?= pager_html($commentPager) ?>
            <?php else: ?>
                <div class="empty" style="margin-top:18px;padding:26px;">
                    <i class="fa-regular fa-comment"></i>
                    <p>还没有评论，来写下第一句吧。</p>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <aside>
        <div class="panel">
            <div class="author-box">
                <span class="author-avatar"><?php if (!empty($book['author_avatar'])): ?><img src="<?= e(upload_url((string) $book['author_avatar'])) ?>" alt=""><?php else: ?><?= e(mb_substr((string) $book['pen_name'], 0, 1, 'UTF-8')) ?><?php endif; ?></span>
                <div>
                    <div class="author-name"><?= e($book['pen_name']) ?></div>
                    <div style="font-size:11px;color:var(--ink-faint);"><?= e($book['author_level'] ?? '原创作者') ?></div>
                </div>
            </div>
            <p class="author-intro"><?= e(excerpt((string) ($book['author_intro'] ?? '这位作者还没有写下自我介绍。'), 120)) ?></p>
            <?php if ($authorBooks !== []): ?>
                <div style="margin-top:16px;padding-top:14px;border-top:1px dashed var(--line);">
                    <div style="font-size:11px;letter-spacing:.12em;color:var(--ink-faint);margin-bottom:8px;">作者其他作品</div>
                    <div class="simple-list">
                        <?php foreach ($authorBooks as $other): ?>
                            <a class="simple-item" href="<?= url('/book/' . (int) $other['id']) ?>" style="padding:9px 12px;">
                                <div class="grow">
                                    <div class="title" style="font-family:var(--serif);font-size:13px;"><?= e($other['title']) ?></div>
                                    <div class="sub"><?= e(status_label((string) $other['status'])) ?> · <?= number_format((int) $other['word_count']) ?> 字</div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($similar !== []): ?>
            <div class="panel">
                <div class="panel-head"><h2 style="font-size:15px;">相似作品</h2></div>
                <div class="simple-list">
                    <?php foreach ($similar as $item): ?>
                        <a class="simple-item" href="<?= url('/book/' . (int) $item['id']) ?>" style="padding:10px 12px;">
                            <div class="grow">
                                <div class="title" style="font-family:var(--serif);font-size:13px;"><?= e($item['title']) ?></div>
                                <div class="sub"><?= author_avatar($item['pen_name'] ?? null, 'xs', $item['author_avatar'] ?? null) ?><?= e($item['pen_name']) ?> · <?= number_format((int) $item['view_count']) ?> 阅读</div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="panel" style="background: linear-gradient(150deg, rgba(216,180,138,.16), rgba(255,255,255,.6));">
            <div style="font-size:11px;letter-spacing:.16em;color:var(--gold-deep);margin-bottom:8px;">版权与审核</div>
            <p style="font-size:11.5px;line-height:1.9;color:var(--ink-soft);">
                本作品已通过平台内容审核，执行先审后发制度。作品版权归作者所有，未经授权禁止转载。
                如发现侵权或违规内容，可通过举报入口反馈。
            </p>
        </div>
    </aside>
</div>
