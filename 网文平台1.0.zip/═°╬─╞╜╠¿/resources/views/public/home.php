<?php
/** 首页 */
$pageTitle = null;
?>
<?php if ($heroSlides !== []): $slideTotal = count($heroSlides); ?>
<section class="hero-carousel" data-hero-slider aria-roledescription="carousel" aria-label="主编推荐轮播">
    <div class="hero-stage">
        <?php foreach ($heroSlides as $index => $slide): ?>
            <article class="hero-slide <?= $index === 0 ? 'is-active' : '' ?>" data-hero-slide data-hero-chapters="<?= (int) ($slide['published_chapters'] ?? 0) ?>" data-hero-words="<?= (int) $slide['word_count'] ?>" aria-hidden="<?= $index === 0 ? 'false' : 'true' ?>">
                <span class="hero-glow" style="background: <?= e(cover_gradient((int) $slide['id'])) ?>;"></span>
                <div class="hero-slide-inner">
                    <div class="hero-cover" style="background: <?= e(cover_gradient((int) $slide['id'])) ?>;">
                        <?php if (!empty($slide['cover'])): ?>
                            <img src="<?= e(upload_url((string) $slide['cover'])) ?>" alt="<?= e($slide['title']) ?>">
                        <?php endif; ?>
                        <span class="cover-title"><?= e($slide['title']) ?></span>
                    </div>
                    <div class="hero-info">
                        <div class="eyebrow"><?= $index === 0 ? '今日主编推荐' : '浪漫书单 · 第 ' . ($index + 1) . ' 期' ?></div>
                        <h2 class="hero-title"><?= e($slide['title']) ?></h2>
                        <div class="hero-meta">
                            <span><?= author_avatar($slide['pen_name'] ?? null, 'xs', $slide['author_avatar'] ?? null) ?><?= e($slide['pen_name']) ?></span>
                            <span><i class="fa-solid fa-tag"></i> <?= e($slide['category_name'] ?? '未分类') ?></span>
                            <span><i class="fa-solid fa-circle-dot"></i> <?= e(status_label((string) $slide['status'])) ?></span>
                            <span><i class="fa-solid fa-file-lines"></i> <?= number_format((int) $slide['word_count']) ?> 字</span>
                            <span><i class="fa-solid fa-eye"></i> <?= number_format((int) $slide['view_count']) ?> 阅读</span>
                        </div>
                        <p class="hero-summary"><?= e(excerpt((string) $slide['summary'], 170)) ?></p>
                        <div class="hero-actions">
                            <a class="btn btn-primary" href="<?= url('/book/' . (int) $slide['id']) ?>">
                                <i class="fa-solid fa-book-open"></i> 开始阅读
                            </a>
                            <a class="btn btn-ghost" href="<?= url('/book/' . (int) $slide['id'] . '/catalog') ?>">
                                <i class="fa-solid fa-list"></i> 查看目录
                            </a>
                        </div>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <div class="hero-toolbar">
        <div class="hero-dots">
            <?php foreach ($heroSlides as $index => $slide): ?>
                <button class="hero-dot <?= $index === 0 ? 'is-active' : '' ?>" type="button" data-hero-dot data-index="<?= $index ?>" aria-label="切换到《<?= e($slide['title']) ?>》"></button>
            <?php endforeach; ?>
        </div>
        <div class="hero-arrows">
            <button class="hero-arrow" type="button" data-hero-prev aria-label="上一张"><i class="fa-solid fa-arrow-left"></i></button>
            <button class="hero-arrow" type="button" data-hero-next aria-label="下一张"><i class="fa-solid fa-arrow-right"></i></button>
        </div>
        <div class="hero-count"><b data-hero-index>01</b> / <?= sprintf('%02d', $slideTotal) ?></div>
    </div>

    <div class="hero-stats-bar">
        <div class="hero-stats">
            <div><span class="num"><?= number_format((int) $stats['books']) ?></span><span class="lbl">本站在架作品</span></div>
            <div><span class="num"><?= number_format((int) $stats['authors']) ?></span><span class="lbl">本站签约作者</span></div>
            <div><span class="num" data-hero-chapters><?= number_format((int) ($heroSlides[0]['published_chapters'] ?? 0)) ?></span><span class="lbl">本作已发布章节</span></div>
            <div><span class="num" data-hero-words><?= number_format((int) ($heroSlides[0]['word_count'] / 10000)) ?> 万</span><span class="lbl">本作累计字数</span></div>
        </div>
    </div>
</section>
<?php endif; ?>

<div class="category-nav chip-scroll">
    <a class="<?= url('/category') === url('/category') ? '' : '' ?>" href="<?= url('/category') ?>">全部</a>
    <?php foreach ($categories as $category): ?>
        <a href="<?= url('/category/' . (int) $category['id']) ?>"><?= e($category['name']) ?></a>
    <?php endforeach; ?>
    <a href="<?= url('/ranking') ?>" style="margin-left:auto;color:var(--rose-deep);"><i class="fa-solid fa-ranking-star"></i> 全部榜单</a>
</div>

<?php if ($spotlight !== []): ?>
<section class="section">
    <div class="section-head">
        <div>
            <div class="eyebrow">编辑精选</div>
            <h2 class="section-title"><span class="mark"></span>值得一盏灯的时间</h2>
            <p class="section-desc">由编辑逐篇读过，再放到你面前的故事。</p>
        </div>
    </div>
    <div class="book-grid">
        <?php foreach ($spotlight as $book): ?>
            <?php require __DIR__ . '/../partials/book_card.php'; ?>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<?php if ($categories !== []): ?>
<section class="section">
    <div class="section-head">
        <div>
            <div class="eyebrow">分类书库</div>
            <h2 class="section-title"><span class="mark"></span>按心情挑一本</h2>
        </div>
        <a class="more-link" href="<?= url('/category') ?>">浏览全部分类 <i class="fa-solid fa-arrow-right"></i></a>
    </div>
    <?php foreach ($categories as $category): ?>
        <?php if ($category['books'] === []) { continue; } ?>
        <div style="margin-bottom: 26px;">
            <div class="section-head" style="margin-bottom: 12px;">
                <h3 style="font-size: 17px; letter-spacing:.08em;">
                    <?= e($category['name']) ?>
                    <span style="font-size:11px;font-weight:400;color:var(--ink-faint);margin-left:8px;"><?= e(excerpt((string)($category['description'] ?? ''), 40)) ?></span>
                </h3>
                <a class="more-link" href="<?= url('/category/' . (int) $category['id']) ?>">更多 <i class="fa-solid fa-arrow-right"></i></a>
            </div>
            <div class="book-grid">
                <?php foreach ($category['books'] as $book): ?>
                    <?php require __DIR__ . '/../partials/book_card.php'; ?>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</section>
<?php endif; ?>

<div style="display:grid; grid-template-columns: 1.15fr .85fr; gap: 26px; margin-bottom: 40px;" class="home-two-col">
    <section class="section" style="margin-bottom:0;">
        <div class="section-head">
            <div>
                <div class="eyebrow">新书上架</div>
                <h2 class="section-title"><span class="mark"></span>刚刚写下的第一页</h2>
            </div>
            <a class="more-link" href="<?= url('/search?sort=new') ?>">更多新书 <i class="fa-solid fa-arrow-right"></i></a>
        </div>
        <div class="book-grid new-books-grid">
            <?php foreach ($newBooks as $book): ?>
                <a class="new-book-card" href="<?= url('/book/' . (int) $book['id']) ?>">
                    <span class="new-book-cover" style="background: <?= e(cover_gradient((int) $book['id'])) ?>;">
                        <?php if (!empty($book['cover'])): ?>
                            <img src="<?= e(upload_url((string) $book['cover'])) ?>" alt="<?= e($book['title']) ?>" loading="lazy">
                        <?php endif; ?>
                    </span>
                    <span class="new-book-body">
                        <span class="new-book-title"><?= e($book['title']) ?></span>
                        <span class="new-book-author"><?= author_avatar($book['pen_name'] ?? null, 'xs', $book['author_avatar'] ?? null) ?><?= e($book['pen_name'] ?? '佚名') ?></span>
                    </span>
                </a>
            <?php endforeach; ?>
            <?php if ($newBooks === []): ?>
                <div class="empty" style="grid-column:1/-1;"><i class="fa-solid fa-book"></i><p>还没有新书，敬请期待。</p></div>
            <?php endif; ?>
        </div>
    </section>

    <section class="section" style="margin-bottom:0;">
        <div class="section-head">
            <div>
                <div class="eyebrow">热度榜</div>
                <h2 class="section-title"><span class="mark"></span>此刻被最多人翻开</h2>
            </div>
            <a class="more-link" href="<?= url('/ranking/total') ?>">完整榜单 <i class="fa-solid fa-arrow-right"></i></a>
        </div>
        <div class="rank-list" style="grid-template-columns:1fr;">
            <?php foreach ($top as $index => $book): ?>
                <a class="rank-item" href="<?= url('/book/' . (int) $book['id']) ?>">
                    <span class="rank-no"><?= $index + 1 ?></span>
                    <span class="rank-info">
                        <span class="rank-title"><?= e($book['title']) ?></span>
                        <span class="rank-meta"><?= author_avatar($book['pen_name'] ?? null, 'xs', $book['author_avatar'] ?? null) ?><?= e($book['pen_name']) ?> · <?= e($book['category_name'] ?? '') ?></span>
                    </span>
                    <span class="rank-heat">热度 <?= number_format((int) $book['rank_score']) ?></span>
                </a>
            <?php endforeach; ?>
            <?php if ($top === []): ?>
                <div class="empty"><i class="fa-solid fa-ranking-star"></i><p>榜单正在生成。</p></div>
            <?php endif; ?>
        </div>
    </section>
</div>

<div style="display:grid; grid-template-columns: 1fr 1fr; gap: 26px;" class="home-two-col">
    <section class="section" style="margin-bottom:0;">
        <div class="section-head">
            <div>
                <div class="eyebrow">最近更新</div>
                <h2 class="section-title"><span class="mark"></span>故事又向前走了一步</h2>
            </div>
        </div>
        <div class="simple-list">
            <?php foreach ($latestChapters as $chapter): ?>
                <a class="simple-item" href="<?= url('/chapter/' . (int) $chapter['id']) ?>">
                    <div class="grow">
                        <div class="title"><?= e($chapter['title']) ?></div>
                        <div class="sub"><?= e($chapter['book_title']) ?> · <?= author_avatar($chapter['pen_name'] ?? null, 'xs', $chapter['author_avatar'] ?? null) ?><?= e($chapter['pen_name']) ?></div>
                    </div>
                    <span class="badge badge-gray"><?= time_ago($chapter['published_at']) ?></span>
                </a>
            <?php endforeach; ?>
            <?php if ($latestChapters === []): ?>
                <div class="empty"><i class="fa-solid fa-pen-nib"></i><p>还没有章节更新。</p></div>
            <?php endif; ?>
        </div>
    </section>

    <section class="section" style="margin-bottom:0;">
        <div class="section-head">
            <div>
                <div class="eyebrow">站内动态</div>
                <h2 class="section-title"><span class="mark"></span>公告与活动</h2>
            </div>
        </div>
        <div class="notice-grid" style="grid-template-columns:1fr;">
            <?php foreach ($announcements as $item): ?>
                <a class="notice-card" href="<?= url('/announcement/' . (int) $item['id']) ?>">
                    <span class="date">公告 · <?= format_date($item['published_at'] ?? $item['created_at']) ?></span>
                    <h3><?= e($item['title']) ?></h3>
                    <p><?= e(excerpt((string) $item['content'], 90)) ?></p>
                </a>
            <?php endforeach; ?>
            <?php foreach ($activities as $item): ?>
                <a class="notice-card" href="<?= url('/activity/' . (int) $item['id']) ?>">
                    <span class="date" style="color:var(--gold-deep);">活动 · <?= format_date($item['start_at'] ?? $item['created_at']) ?></span>
                    <h3><?= e($item['title']) ?></h3>
                    <p><?= e(excerpt((string) $item['content'], 90)) ?></p>
                </a>
            <?php endforeach; ?>
            <?php if ($announcements === [] && $activities === []): ?>
                <div class="empty"><i class="fa-solid fa-bullhorn"></i><p>暂无站内动态。</p></div>
            <?php endif; ?>
        </div>
    </section>
</div>

<style>
@media (max-width: 900px) {
    .home-two-col { grid-template-columns: 1fr !important; }
}
</style>
