<?php /** 财务（第一版占位） */ ?>
<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
    <p style="font-size:12px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-lock"></i>
        第一版关闭全部商业化能力：充值、订阅、章节购买、打赏、自动订阅、月票、打赏礼物、作者结算。
        本页面仅保留数据结构与入口占位，不提供任何可执行的收费操作，也不注册相关路由与接口。
    </p>
</div>

<div class="review-layout">
    <div>
        <div class="admin-card">
            <div class="card-head"><h2>商业化开关</h2><span class="hint">全部锁定</span></div>
            <div class="switch-list">
                <?php foreach ($commercialSwitches as $switch): ?>
                    <div class="switch-item">
                        <div class="info" style="min-width:0;flex:1;">
                            <div class="name"><?= e($switch['name']) ?> <span class="locked-note"><i class="fa-solid fa-lock"></i></span></div>
                            <div class="code"><?= e($switch['code']) ?></div>
                        </div>
                        <span class="switch-state <?= (int) $switch['value'] === 1 ? 'on' : 'off' ?>"><?= (int) $switch['value'] === 1 ? '开启' : '关闭' ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>预留数据表</h2><span class="hint">仅统计，不含操作</span></div>
            <div class="table-wrap">
                <table class="table">
                    <thead><tr><th>数据表</th><th>用途</th><th>记录数</th><th>状态</th></tr></thead>
                    <tbody>
                    <tr><td>orders</td><td class="sub">充值订单</td><td><?= number_format((int) $counts['orders']) ?></td><td><span class="badge badge-gray">未启用</span></td></tr>
                    <tr><td>subscription_orders</td><td class="sub">订阅订单</td><td><?= number_format((int) $counts['subscription_orders']) ?></td><td><span class="badge badge-gray">未启用</span></td></tr>
                    <tr><td>rewards</td><td class="sub">打赏记录</td><td><?= number_format((int) $counts['rewards']) ?></td><td><span class="badge badge-gray">未启用</span></td></tr>
                    <tr><td>settlements</td><td class="sub">作者结算</td><td><?= number_format((int) $counts['settlements']) ?></td><td><span class="badge badge-gray">未启用</span></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div>
        <div class="admin-card">
            <div class="card-head"><h2>启用前置条件</h2></div>
            <div style="font-size:12px;line-height:2.1;color:var(--ink-soft);">
                <p>商业化能力需要在后续版本中满足以下条件后才可开启：</p>
                <p>1. 支付与退款合规审核完成；</p>
                <p>2. 未成年人保护与实名认证链路打通；</p>
                <p>3. 作者合同、分成与结算规则完成备案；</p>
                <p>4. 四层闸门（菜单 / 路由 / 接口 / 任务）改造完成；</p>
                <p>5. 财务对账与发票流程可用。</p>
                <p style="margin-top:10px;color:var(--ink-faint);">在任何条件未满足前，后台不提供开启入口。</p>
            </div>
        </div>
    </div>
</div>
