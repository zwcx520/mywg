<?php
/** 活动管理 */
$statusLabels = ['draft' => '草稿', 'published' => '进行中', 'offline' => '已下线'];
?>
<div class="filter-bar" style="justify-content:space-between;">
    <form method="get" action="<?= url('/admin/activities') ?>">
        <input type="hidden" name="r" value="/admin/activities">
        <select class="select" name="status">
            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>全部状态</option>
            <?php foreach ($statusLabels as $key => $label): ?>
                <option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= $label ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit">筛选</button>
    </form>
    <a class="btn btn-primary btn-sm" href="<?= url('/admin/activities/create') ?>"><i class="fa-solid fa-plus"></i> 新建活动</a>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:820px;">
            <thead><tr><th>活动</th><th>状态</th><th>活动时间</th><th>创建时间</th><th style="width:200px;">操作</th></tr></thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="5"><div class="empty"><i class="fa-solid fa-gift"></i><p>还没有活动。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td>
                        <span class="title-cell"><?= e($row['title']) ?></span>
                        <?php if (!empty($row['summary'])): ?><div class="sub"><?= e(excerpt((string) $row['summary'], 60)) ?></div><?php endif; ?>
                    </td>
                    <td><span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e($statusLabels[$row['status']] ?? $row['status']) ?></span></td>
                    <td class="sub">
                        <?= e($row['start_at'] ? format_date((string) $row['start_at'], 'Y-m-d H:i') : '未设置') ?>
                        ~ <?= e($row['end_at'] ? format_date((string) $row['end_at'], 'Y-m-d H:i') : '未设置') ?>
                    </td>
                    <td class="sub"><?= e(format_date((string) $row['created_at'], 'm-d H:i')) ?></td>
                    <td>
                        <div class="actions">
                            <a class="btn btn-soft btn-sm" href="<?= url('/admin/activities/' . (int) $row['id'] . '/edit') ?>">编辑</a>
                            <a class="btn btn-ghost btn-sm" href="<?= url('/activity/' . (int) $row['id']) ?>" target="_blank" rel="noopener">前台</a>
                            <form method="post" action="<?= url('/admin/activities/' . (int) $row['id'] . '/status') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="status" value="<?= (string) $row['status'] === 'published' ? 'offline' : 'published' ?>">
                                <button class="btn btn-ghost btn-sm" type="submit"><?= (string) $row['status'] === 'published' ? '下线' : '发布' ?></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);margin-top:18px;">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-circle-info"></i>
        第一版活动仅做内容展示，不包含充值返利、打赏、月票与订阅类营销玩法。
    </p>
</div>
