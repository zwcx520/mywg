<?php /** 用户管理 */ ?>
<div class="filter-bar">
    <form method="get" action="<?= url('/admin/users') ?>">
        <input type="hidden" name="r" value="/admin/users">
        <input class="input search" type="search" name="q" value="<?= e($keyword) ?>" placeholder="登录名 / 手机号 / 邮箱 / 昵称">
        <select class="select" name="status">
            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>全部状态</option>
            <?php foreach (['active', 'limited', 'locked', 'risk', 'deleting', 'inactive'] as $item): ?>
                <option value="<?= $item ?>" <?= $status === $item ? 'selected' : '' ?>><?= e(status_label($item)) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i> 筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/users') ?>">重置</a>
    </form>
    <form method="post" action="<?= url('/admin/users/purge-cancelled') ?>" data-confirm="将永久删除已满 5 天冷静期的注销账号及其全部数据与上传文件，确认继续？" data-danger style="margin-left:auto;">
        <?= csrf_field() ?>
        <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-broom"></i> 清理到期注销</button>
    </form>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table">
            <thead>
            <tr>
                <th style="width:70px;">ID</th>
                <th>用户</th>
                <th>手机 / 邮箱</th>
                <th>角色</th>
                <th>状态</th>
                <th>注册时间</th>
                <th>最近登录</th>
                <th style="width:90px;">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="8"><div class="empty"><i class="fa-solid fa-users"></i><p>没有匹配的用户。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td class="sub">#<?= (int) $row['id'] ?></td>
                    <td>
                        <div class="cell-media">
                            <?= avatar_thumb($row['avatar'] ?? null, $row['nickname'] ?? $row['login_name']) ?>
                            <div class="cell-main">
                                <a class="title-cell" href="<?= url('/admin/users/' . (int) $row['id']) ?>"><?= e($row['nickname'] ?? $row['login_name']) ?></a>
                                <div class="sub"><?= e($row['login_name']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td class="sub">
                        <?= e(sensitive($row['phone'] ?? '', 'phone')) ?><br>
                        <?= e(sensitive($row['email'] ?? '', 'email')) ?>
                    </td>
                    <td>
                        <span class="badge badge-gray"><?= e($row['role_names'] ?? '无角色') ?></span>
                        <?php if ((int) ($row['is_admin'] ?? 0) > 0): ?>
                            <span class="badge badge-gold"><i class="fa-solid fa-shield-halved"></i> <?= (int) $row['id'] === (int) $primaryAdminId ? '初始站长' : '站长账号' ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e(status_label((string) $row['status'])) ?></span>
                        <?php if ($row['status'] === 'deleting'): ?>
                            <div class="sub" style="margin-top:4px;">剩余 <?= \App\Services\AccountPurgeService::remainingDays((string) $row['updated_at']) ?> 天自动删除</div>
                        <?php endif; ?>
                    </td>
                    <td class="sub"><?= e(format_date((string) $row['created_at'], 'Y-m-d H:i')) ?></td>
                    <td class="sub"><?= e($row['last_login_at'] ? time_ago((string) $row['last_login_at']) : '—') ?></td>
                    <td><a class="btn btn-soft btn-sm" href="<?= url('/admin/users/' . (int) $row['id']) ?>">详情</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= pager_html($pager) ?>
