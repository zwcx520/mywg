<?php /** 审计日志 */ ?>
<div class="filter-bar">
    <form method="get" action="<?= url('/admin/logs') ?>">
        <input type="hidden" name="r" value="/admin/logs">
        <select class="select" name="module">
            <option value="">全部模块</option>
            <?php foreach ($modules as $item): ?>
                <option value="<?= e($item['module']) ?>" <?= $module === (string) $item['module'] ? 'selected' : '' ?>><?= e($item['module']) ?></option>
            <?php endforeach; ?>
        </select>
        <input class="input search" type="search" name="q" value="<?= e($keyword) ?>" placeholder="动作 / 详情 / 操作人">
        <button class="btn btn-primary btn-sm" type="submit">筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/logs') ?>">重置</a>
    </form>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:900px;">
            <thead>
            <tr>
                <th style="width:70px;">ID</th>
                <th style="width:140px;">时间</th>
                <th style="width:140px;">操作人</th>
                <th style="width:110px;">模块</th>
                <th style="width:150px;">动作</th>
                <th>详情</th>
                <th style="width:120px;">对象</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="7"><div class="empty"><i class="fa-solid fa-scroll"></i><p>没有匹配的日志。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td class="sub">#<?= (int) $row['id'] ?></td>
                    <td class="sub"><?= e(format_date((string) $row['created_at'], 'Y-m-d H:i:s')) ?></td>
                    <td class="sub"><?= e($row['nickname'] ?? $row['login_name'] ?? '系统') ?></td>
                    <td><span class="badge badge-gray"><?= e($row['module']) ?></span></td>
                    <td><?= e($row['action']) ?></td>
                    <td class="sub" style="max-width:420px;word-break:break-all;"><?= e($row['detail']) ?></td>
                    <td class="sub"><?= e($row['target_type'] ? $row['target_type'] . ' #' . (int) $row['target_id'] : '—') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= pager_html($pager) ?>

<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);margin-top:18px;">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-circle-info"></i> 审计日志只读，不提供删除入口。日志保留策略由站长在站点配置中约定，建议至少保留 180 天。
    </p>
</div>
