<?php
/** 站点设置 */
$logo = $settings['site_logo'] ?? '';
?>
<div class="card-head" style="margin-bottom:18px;">
    <div>
        <h2 style="font-size:20px;">站点设置</h2>
        <p class="hint" style="margin-top:4px;">修改后将同步更新前台标题、页脚与举报提示。</p>
    </div>
</div>

<form class="admin-card" method="post" action="<?= url('/admin/settings/save') ?>" enctype="multipart/form-data" data-lock-submit>
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field">
            <label for="site_name">站点名称</label>
            <input class="input" id="site_name" type="text" name="site_name" maxlength="60" value="<?= e($settings['site_name'] ?? '') ?>">
        </div>
        <div class="field">
            <label for="site_slogan">站点标语</label>
            <input class="input" id="site_slogan" type="text" name="site_slogan" maxlength="120" value="<?= e($settings['site_slogan'] ?? '') ?>">
        </div>
        <div class="field full">
            <label for="site_keywords">SEO 关键词</label>
            <input class="input" id="site_keywords" type="text" name="site_keywords" maxlength="255" value="<?= e($settings['site_keywords'] ?? '') ?>" placeholder="以英文逗号分隔">
        </div>
        <div class="field full">
            <label for="site_desc">站点描述</label>
            <textarea class="textarea" id="site_desc" name="site_desc" maxlength="500" style="min-height:80px;"><?= e($settings['site_desc'] ?? '') ?></textarea>
        </div>
        <div class="field">
            <label for="contact_email">联系邮箱</label>
            <input class="input" id="contact_email" type="email" name="contact_email" maxlength="120" value="<?= e($settings['contact_email'] ?? '') ?>">
        </div>
        <div class="field">
            <label for="icp_no">备案号</label>
            <input class="input" id="icp_no" type="text" name="icp_no" maxlength="80" value="<?= e($settings['icp_no'] ?? '') ?>">
        </div>
        <div class="field full">
            <label for="copyright_text">版权信息</label>
            <input class="input" id="copyright_text" type="text" name="copyright_text" maxlength="160" value="<?= e($settings['copyright_text'] ?? '') ?>">
        </div>
        <div class="field full">
            <label for="report_notice">举报须知</label>
            <textarea class="textarea" id="report_notice" name="report_notice" maxlength="1000" style="min-height:90px;"><?= e($settings['report_notice'] ?? '') ?></textarea>
        </div>
        <div class="field full">
            <label for="about_text">关于我们</label>
            <textarea class="textarea" id="about_text" name="about_text" maxlength="4000" style="min-height:160px;"><?= e($settings['about_text'] ?? '') ?></textarea>
        </div>
        <div class="field full">
            <label for="logo">站点 Logo</label>
            <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;">
                <?php if ($logo !== ''): ?>
                    <img src="<?= e(upload_url($logo)) ?>" alt="站点 Logo" style="height:52px;border-radius:10px;background:#fff;padding:6px;border:1px solid var(--line);">
                <?php else: ?>
                    <span class="badge badge-gray">尚未上传</span>
                <?php endif; ?>
                <input class="input" id="logo" type="file" name="logo" accept="image/png,image/jpeg,image/webp" style="max-width:320px;">
            </div>
            <span class="hint">支持 PNG / JPG / WEBP，建议高度 60px 以内的透明背景图片。</span>
        </div>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit" data-confirm="确认保存站点设置？">保存设置</button>
    </div>
</form>

<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-circle-info"></i>
        站点设置不包含任何收费配置项。业务开关请前往「业务开关」页面；商业化开关在第一版锁定，无法开启。
    </p>
</div>
