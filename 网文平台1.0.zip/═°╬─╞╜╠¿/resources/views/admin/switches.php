<?php
/** 业务开关 */
$groupLabels = ['commercial' => '商业化开关（第一版锁定）', 'operation' => '运营开关', 'content' => '内容与审核', 'account' => '账号与注册', 'site' => '站点运行'];
?>
<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-lock"></i>
        商业化 8 项开关在第一版被强制锁定（充值、订阅、章节购买、打赏、自动订阅、月票、打赏礼物、作者结算）。
        页面菜单、路由、接口与后台任务四层均不可触达，任何变更都需要新版本发布，无法在后台开启。
    </p>
</div>

<?php foreach ($groups as $group => $items): ?>
    <div class="admin-card">
        <div class="card-head">
            <h2><?= e($groupLabels[$group] ?? $group) ?></h2>
            <span class="hint"><?= count($items) ?> 项</span>
        </div>
        <div class="switch-list">
            <?php foreach ($items as $item): ?>
                <?php $locked = (int) $item['allow_toggle'] !== 1; ?>
                <div class="switch-item">
                    <div class="info" style="min-width:0;flex:1;">
                        <div class="name"><?= e($item['name']) ?><?= $locked ? ' <span class="locked-note"><i class="fa-solid fa-lock"></i></span>' : '' ?></div>
                        <div class="code"><?= e($item['code']) ?> · v<?= (int) $item['version'] ?></div>
                        <div class="desc"><?= e($item['description'] ?? '') ?></div>
                        <?php if (!empty($item['reason'])): ?>
                            <div class="desc">最近变更原因：<?= e($item['reason']) ?></div>
                        <?php endif; ?>
                    </div>
                    <span class="switch-state <?= (int) $item['value'] === 1 ? 'on' : 'off' ?>"><?= (int) $item['value'] === 1 ? '开启' : '关闭' ?></span>
                    <?php if ($locked): ?>
                        <span class="btn btn-ghost btn-sm" style="opacity:.55;cursor:not-allowed;"><i class="fa-solid fa-ban"></i> 已锁定</span>
                    <?php else: ?>
                        <form method="post" action="<?= url('/admin/switches/' . (int) $item['id'] . '/toggle') ?>" style="display:flex;gap:6px;align-items:center;" data-lock-submit>
                            <?= csrf_field() ?>
                            <input type="hidden" name="value" value="<?= (int) $item['value'] === 1 ? 0 : 1 ?>">
                            <input class="input" type="text" name="reason" maxlength="255" placeholder="必填：变更原因" style="width:170px;" required>
                            <button class="btn btn-soft btn-sm" type="submit" data-confirm="确认切换该业务开关并记录变更原因？">
                                <?= (int) $item['value'] === 1 ? '关闭' : '开启' ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endforeach; ?>
