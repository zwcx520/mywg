<?php /** 审核工作台 */ ?>
<div class="tabs">
    <a class="tab <?= $tab === 'book' ? 'is-active' : '' ?>" href="<?= url('/admin/reviews?tab=book') ?>">作品审核 <span class="count"><?= count($bookTasks) ?></span></a>
    <a class="tab <?= $tab === 'chapter' ? 'is-active' : '' ?>" href="<?= url('/admin/reviews?tab=chapter') ?>">章节审核 <span class="count"><?= count($chapterTasks) ?></span></a>
    <a class="tab <?= $tab === 'author' ? 'is-active' : '' ?>" href="<?= url('/admin/reviews?tab=author') ?>">作家认证 <span class="count"><?= count($authorTasks) ?></span></a>
</div>

<?php if ($tab === 'book'): ?>
    <div class="admin-card flush">
        <div class="table-wrap" style="border:0;">
            <table class="table" style="min-width:820px;">
                <thead><tr><th>作品</th><th>作者</th><th>当前状态</th><th>优先级</th><th>提交时间</th><th>简介</th><th style="width:110px;">操作</th></tr></thead>
                <tbody>
                <?php if ($bookTasks === []): ?>
                    <tr><td colspan="7"><div class="empty"><i class="fa-solid fa-clipboard-check"></i><p>没有待审作品。</p></div></td></tr>
                <?php endif; ?>
                <?php foreach ($bookTasks as $task): ?>
                    <tr>
                        <td>
                            <div class="cell-media">
                                <?= cover_thumb($task['cover'] ?? null, (string) $task['title'], (int) $task['target_id']) ?>
                                <div class="cell-main title-cell"><?= e($task['title']) ?></div>
                            </div>
                        </td>
                        <td class="sub"><?= author_avatar($task['pen_name'] ?? null, 'xs', $task['author_avatar'] ?? null) ?><?= e($task['pen_name']) ?></td>
                        <td><span class="badge <?= status_badge_class((string) $task['book_status']) ?>"><?= e(status_label((string) $task['book_status'])) ?></span></td>
                        <td><?= (int) $task['priority'] === 1 ? '<span class="badge badge-red">高</span>' : '<span class="badge badge-gray">普通</span>' ?></td>
                        <td class="sub"><?= e(time_ago((string) $task['created_at'])) ?></td>
                        <td class="sub"><?= e(excerpt((string) $task['summary'], 50)) ?></td>
                        <td><a class="btn btn-primary btn-sm" href="<?= url('/admin/review/book/' . (int) $task['target_id']) ?>">进入审核</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php elseif ($tab === 'chapter'): ?>
    <div class="admin-card flush">
        <div class="table-wrap" style="border:0;">
            <table class="table" style="min-width:820px;">
                <thead><tr><th>章节</th><th>作品</th><th>作者</th><th>状态</th><th>优先级</th><th>提交时间</th><th style="width:110px;">操作</th></tr></thead>
                <tbody>
                <?php if ($chapterTasks === []): ?>
                    <tr><td colspan="7"><div class="empty"><i class="fa-solid fa-file-lines"></i><p>没有待审章节。</p></div></td></tr>
                <?php endif; ?>
                <?php foreach ($chapterTasks as $task): ?>
                    <tr>
                        <td class="title-cell"><?= e($task['title']) ?></td>
                        <td class="sub">
                            <div class="cell-media">
                                <?= cover_thumb($task['book_cover'] ?? null, (string) $task['book_title'], (int) $task['book_id']) ?>
                                <span class="cell-main"><?= e($task['book_title']) ?></span>
                            </div>
                        </td>
                        <td class="sub"><?= author_avatar($task['pen_name'] ?? null, 'xs', $task['author_avatar'] ?? null) ?><?= e($task['pen_name']) ?></td>
                        <td><span class="badge <?= status_badge_class((string) $task['chapter_status']) ?>"><?= e(status_label((string) $task['chapter_status'])) ?></span></td>
                        <td><?= (int) $task['priority'] === 1 ? '<span class="badge badge-red">高</span>' : '<span class="badge badge-gray">普通</span>' ?></td>
                        <td class="sub"><?= e(time_ago((string) $task['created_at'])) ?></td>
                        <td><a class="btn btn-primary btn-sm" href="<?= url('/admin/review/chapter/' . (int) $task['target_id']) ?>">进入审核</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="admin-card flush">
        <div class="table-wrap" style="border:0;">
            <table class="table" style="min-width:720px;">
                <thead><tr><th>笔名</th><th>真实姓名</th><th>申请状态</th><th>提交时间</th><th style="width:110px;">操作</th></tr></thead>
                <tbody>
                <?php if ($authorTasks === []): ?>
                    <tr><td colspan="5"><div class="empty"><i class="fa-solid fa-id-card"></i><p>没有待审认证申请。</p></div></td></tr>
                <?php endif; ?>
                <?php foreach ($authorTasks as $task): ?>
                    <tr>
                        <td>
                            <div class="cell-media" style="align-items:center;">
                                <?= avatar_thumb($task['avatar'] ?? null, (string) $task['pen_name']) ?>
                                <span class="cell-main title-cell"><?= e($task['pen_name']) ?></span>
                            </div>
                        </td>
                        <td class="sub"><?= e(sensitive($task['real_name'] ?? '', 'name')) ?></td>
                        <td><span class="badge badge-gold"><?= e(status_label((string) $task['application_status'])) ?></span></td>
                        <td class="sub"><?= e(time_ago((string) $task['created_at'])) ?></td>
                        <td><a class="btn btn-primary btn-sm" href="<?= url('/admin/authors') ?>">去处理</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-circle-info"></i>
        审核原则：先审后发；章节正文与作者草稿分离；驳回必须填写读者与作者都能理解的原因。审核通过后按版本流生成发布版，已发布内容的后续修改不得原地覆盖。
    </p>
</div>
