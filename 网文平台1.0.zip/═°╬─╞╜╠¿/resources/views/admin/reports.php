<?php /** 举报处置列表 */ ?>
<div class="filter-bar">
    <form method="get" action="<?= url('/admin/reports') ?>">
        <input type="hidden" name="r" value="/admin/reports">
        <select class="select" name="status">
            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>全部状态</option>
            <?php foreach (['received', 'reviewing', 'handled', 'transferred', 'closed'] as $item): ?>
                <option value="<?= $item ?>" <?= $status === $item ? 'selected' : '' ?>><?= e(report_status_label($item)) ?></option>
            <?php endforeach; ?>
        </select>
        <select class="select" name="category">
            <option value="all" <?= $category === 'all' ? 'selected' : '' ?>>全部类型</option>
            <?php foreach (['violation', 'copyright', 'spam', 'minor', 'other'] as $item): ?>
                <option value="<?= $item ?>" <?= $category === $item ? 'selected' : '' ?>><?= e(report_category_label($item)) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit">筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/reports') ?>">重置</a>
    </form>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:900px;">
            <thead>
            <tr>
                <th style="width:96px;">受理编号</th>
                <th>举报类型</th>
                <th>对象</th>
                <th>举报人</th>
                <th>说明</th>
                <th>状态</th>
                <th>时间</th>
                <th style="width:90px;">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="8"><div class="empty"><i class="fa-solid fa-flag"></i><p>没有匹配的举报。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td class="sub">JB<?= str_pad((string) $row['id'], 6, '0', STR_PAD_LEFT) ?></td>
                    <td><span class="badge badge-gray"><?= e(report_category_label((string) $row['category'])) ?></span></td>
                    <td class="sub"><?= e($row['target_type']) ?> #<?= (int) $row['target_id'] ?></td>
                    <td class="sub">
                        <div class="cell-media" style="align-items:center;">
                            <?= avatar_thumb($row['reporter_avatar'] ?? null, $row['reporter_name'] ?? '匿名') ?>
                            <span class="cell-main"><?= e($row['reporter_name'] ?? '匿名') ?></span>
                        </div>
                    </td>
                    <td class="sub"><?= e(excerpt((string) $row['description'], 60)) ?></td>
                    <td><span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e(report_status_label((string) $row['status'])) ?></span></td>
                    <td class="sub"><?= e(format_date((string) $row['created_at'], 'm-d H:i')) ?></td>
                    <td><a class="btn btn-soft btn-sm" href="<?= url('/admin/reports/' . (int) $row['id']) ?>">处置</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= pager_html($pager) ?>
