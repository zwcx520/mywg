<?php /** 推荐位管理 */ ?>
<div class="review-layout">
    <div>
        <div class="admin-card flush">
            <div class="card-head" style="padding:20px 22px 0;"><h2>当前推荐位</h2><span class="hint">按位置与权重排序</span></div>
            <div class="table-wrap" style="border:0;margin-top:14px;">
                <table class="table" style="min-width:640px;">
                    <thead><tr><th>位置</th><th>作品</th><th>作者</th><th>权重</th><th>生效时间</th><th>状态</th><th style="width:90px;">操作</th></tr></thead>
                    <tbody>
                    <?php if ($rows === []): ?>
                        <tr><td colspan="7"><div class="empty"><i class="fa-solid fa-star"></i><p>还没有推荐位配置。</p></div></td></tr>
                    <?php endif; ?>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><span class="badge badge-gold"><?= e($slots[$row['slot']] ?? $row['slot']) ?></span></td>
                            <td>
                                <div class="cell-media">
                                    <?= cover_thumb($row['cover'] ?? null, (string) $row['title'], (int) $row['book_id']) ?>
                                    <span class="cell-main title-cell"><?= e($row['title']) ?></span>
                                </div>
                            </td>
                            <td class="sub"><?= author_avatar($row['pen_name'] ?? null, 'xs', $row['author_avatar'] ?? null) ?><?= e($row['pen_name']) ?></td>
                            <td><?= (int) $row['weight'] ?></td>
                            <td class="sub">
                                <?= e($row['start_at'] ? format_date((string) $row['start_at'], 'Y-m-d H:i') : '立即') ?>
                                ~ <?= e($row['end_at'] ? format_date((string) $row['end_at'], 'Y-m-d H:i') : '长期') ?>
                            </td>
                            <td><span class="badge <?= (int) $row['status'] === 1 ? 'badge-green' : 'badge-gray' ?>"><?= (int) $row['status'] === 1 ? '上线' : '下线' ?></span></td>
                            <td>
                                <form method="post" action="<?= url('/admin/recommend/' . (int) $row['id'] . '/toggle') ?>">
                                    <?= csrf_field() ?>
                                    <button class="btn btn-ghost btn-sm" type="submit"><?= (int) $row['status'] === 1 ? '下线' : '上线' ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div>
        <div class="admin-card">
            <div class="card-head"><h2>添加推荐位</h2></div>
            <form method="post" action="<?= url('/admin/recommend/save') ?>" data-lock-submit>
                <?= csrf_field() ?>
                <div class="field">
                    <label for="slot">推荐位置</label>
                    <select class="select" id="slot" name="slot">
                        <?php foreach ($slots as $key => $label): ?>
                            <option value="<?= e($key) ?>"><?= e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="book_id">选择作品</label>
                    <select class="select" id="book_id" name="book_id" required>
                        <option value="">请选择已公开作品</option>
                        <?php foreach ($books as $book): ?>
                            <option value="<?= (int) $book['id'] ?>"><?= e($book['title']) ?> · <?= e($book['pen_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="weight">权重（越大越靠前）</label>
                    <input class="input" id="weight" type="number" name="weight" value="10">
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="start_at">开始时间（可选）</label>
                    <input class="input" id="start_at" type="datetime-local" name="start_at">
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="end_at">结束时间（可选）</label>
                    <input class="input" id="end_at" type="datetime-local" name="end_at">
                </div>
                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">添加推荐</button>
                </div>
            </form>
        </div>
    </div>
</div>
