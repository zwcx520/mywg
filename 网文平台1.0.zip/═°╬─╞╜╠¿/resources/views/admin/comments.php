<?php /** 评论治理 */ ?>
<div class="filter-bar">
    <form method="get" action="<?= url('/admin/comments') ?>">
        <input type="hidden" name="r" value="/admin/comments">
        <input class="input search" type="search" name="q" value="<?= e($keyword) ?>" placeholder="评论内容 / 作品名">
        <select class="select" name="status">
            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>全部状态</option>
            <?php foreach (['waiting', 'approved', 'hidden', 'deleted'] as $item): ?>
                <option value="<?= $item ?>" <?= $status === $item ? 'selected' : '' ?>><?= e(status_label($item)) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit">筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/comments') ?>">重置</a>
    </form>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:880px;">
            <thead>
            <tr>
                <th style="width:60px;">ID</th>
                <th style="width:170px;">用户 / 作品</th>
                <th>评论内容</th>
                <th>状态</th>
                <th>点赞</th>
                <th>时间</th>
                <th style="width:180px;">处置</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="7"><div class="empty"><i class="fa-solid fa-comments"></i><p>没有匹配的评论。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td class="sub">#<?= (int) $row['id'] ?></td>
                    <td class="sub">
                        <div class="cell-media">
                            <?= avatar_thumb($row['avatar'] ?? null, $row['nickname'] ?? '匿名') ?>
                            <div class="cell-main">
                                <?= e($row['nickname'] ?? '匿名') ?><br>
                                <?= e($row['book_title']) ?>
                            </div>
                        </div>
                    </td>
                    <td style="font-size:12px;line-height:1.8;max-width:420px;">
                        <?= e(excerpt((string) $row['content'], 140)) ?>
                        <?php if (!empty($row['parent_id'])): ?><div class="sub">回复评论 #<?= (int) $row['parent_id'] ?></div><?php endif; ?>
                    </td>
                    <td><span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e(status_label((string) $row['status'])) ?></span></td>
                    <td><?= (int) $row['like_count'] ?></td>
                    <td class="sub"><?= e(format_date((string) $row['created_at'], 'm-d H:i')) ?></td>
                    <td>
                        <div class="actions">
                            <?php foreach (['approved' => '通过', 'hidden' => '隐藏', 'deleted' => '删除'] as $value => $label): ?>
                                <?php if ((string) $row['status'] !== $value): ?>
                                    <form method="post" action="<?= url('/admin/comments/' . (int) $row['id'] . '/action') ?>" <?= $value === 'deleted' ? 'data-confirm="确认删除该评论？"' : '' ?>>
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="status" value="<?= $value ?>">
                                        <input type="hidden" name="status_filter" value="<?= e($status) ?>">
                                        <button class="btn btn-<?= $value === 'approved' ? 'soft' : ($value === 'deleted' ? 'danger' : 'ghost') ?> btn-sm" type="submit"><?= $label ?></button>
                                    </form>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= pager_html($pager) ?>

<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);margin-top:18px;">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-shield-halved"></i>
        评论采用先审后发策略（可通过业务开关调整）。删除为软删除，可进入回收站恢复；涉及违法不良信息请同步处理举报并保留处置记录。
    </p>
</div>
