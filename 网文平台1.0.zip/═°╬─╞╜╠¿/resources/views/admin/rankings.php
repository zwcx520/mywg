<?php
/** 榜单管理 */
$rankingNames = [];
foreach ($rankings as $ranking) {
    $rankingNames[(int) $ranking['id']] = (string) $ranking['name'];
}
?>
<div class="review-layout">
    <div>
        <div class="admin-card flush">
            <div class="card-head" style="padding:20px 22px 0;"><h2>榜单列表</h2><span class="hint">刷新会生成当日快照，重复执行不会覆盖历史</span></div>
            <div class="table-wrap" style="border:0;margin-top:14px;">
                <table class="table" style="min-width:560px;">
                    <thead><tr><th>榜单</th><th>编码</th><th>统计口径</th><th>最新快照</th><th>条目</th><th style="width:90px;">操作</th></tr></thead>
                    <tbody>
                    <?php if ($rankings === []): ?>
                        <tr><td colspan="6"><div class="empty"><i class="fa-solid fa-ranking-star"></i><p>还没有配置榜单。</p></div></td></tr>
                    <?php endif; ?>
                    <?php foreach ($rankings as $ranking): ?>
                        <?php $info = $latest[(int) $ranking['id']] ?? ['date' => null, 'count' => 0]; ?>
                        <tr>
                            <td class="title-cell"><?= e($ranking['name']) ?></td>
                            <td><span class="badge badge-gray"><?= e($ranking['code']) ?></span></td>
                            <td class="sub"><?= e($ranking['type']) ?> / <?= e($ranking['period']) ?></td>
                            <td class="sub"><?= e($info['date'] ? format_date((string) $info['date'], 'Y-m-d') : '未生成') ?></td>
                            <td><?= (int) $info['count'] ?></td>
                            <td>
                                <form method="post" action="<?= url('/admin/rankings/' . (int) $ranking['id'] . '/refresh') ?>" data-confirm="确认立即刷新该榜单？">
                                    <?= csrf_field() ?>
                                    <button class="btn btn-soft btn-sm" type="submit">刷新</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>最新快照预览（首个榜单）</h2></div>
            <?php if ($results === []): ?>
                <div class="empty"><i class="fa-solid fa-chart-simple"></i><p>暂无榜单快照，请先刷新榜单。</p></div>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="table" style="min-width:520px;">
                        <thead><tr><th>名次</th><th>作品</th><th>作者</th><th>得分</th><th>快照日期</th></tr></thead>
                        <tbody>
                        <?php
                        $previewRankingId = (int) ($rankings[0]['id'] ?? 0);
                        $previewDate = $latest[$previewRankingId]['date'] ?? null;
                        foreach ($results as $index => $item): ?>
                            <tr>
                                <td><span class="badge <?= $index < 3 ? 'badge-gold' : 'badge-gray' ?>">NO.<?= (int) ($item['position'] ?? $index + 1) ?></span></td>
                                <td class="title-cell"><?= e($item['title']) ?></td>
                                <td class="sub"><?= author_avatar($item['pen_name'] ?? null, 'xs', $item['author_avatar'] ?? null) ?><?= e($item['pen_name'] ?? '—') ?></td>
                                <td><?= number_format((float) ($item['score'] ?? 0), 1) ?></td>
                                <td class="sub"><?= e($previewDate ? format_date((string) $previewDate, 'Y-m-d') : '—') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
            <p style="font-size:11.5px;color:#8a6438;line-height:2;">
                <i class="fa-solid fa-circle-info"></i>
                榜单统计仅使用点击、收藏、阅读与评论等免费指标。第一版不包含月票榜、打赏榜与订阅榜。
            </p>
        </div>
    </div>
</div>
