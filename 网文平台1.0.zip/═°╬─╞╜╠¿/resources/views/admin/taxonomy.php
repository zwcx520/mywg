<?php /** 分类与标签 */ ?>
<div class="review-layout">
    <div>
        <div class="admin-card">
            <div class="card-head">
                <h2>分类管理</h2>
                <div class="actions">
                    <span class="hint">两级结构 · 编码用于前台路径</span>
                    <form method="post" action="<?= url('/admin/taxonomy/preset') ?>" data-confirm="将补充官方预置分类与标签（已存在的会自动跳过），确认继续？">
                        <?= csrf_field() ?>
                        <button class="btn btn-ghost btn-sm" type="submit"><i class="fa-solid fa-wand-magic-sparkles"></i> 补充预置分类/标签</button>
                    </form>
                </div>
            </div>
            <div class="table-wrap">
                <table class="table" style="min-width:720px;">
                    <thead><tr><th>名称</th><th>编码</th><th>上级</th><th>排序</th><th>状态</th><th>作品</th><th style="width:170px;">操作</th></tr></thead>
                    <tbody>
                    <?php if ($categories === []): ?>
                        <tr><td colspan="7"><div class="empty"><i class="fa-solid fa-tags"></i><p>还没有分类。</p></div></td></tr>
                    <?php endif; ?>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td class="title-cell"><?= (int) $category['parent_id'] > 0 ? '　└ ' : '' ?><?= e($category['name']) ?></td>
                            <td><code style="font-size:11px;color:var(--rose-deep);"><?= e($category['code']) ?></code></td>
                            <td class="sub"><?= (int) $category['parent_id'] > 0 ? '#' . (int) $category['parent_id'] : '顶级' ?></td>
                            <td><?= (int) $category['sort'] ?></td>
                            <td><span class="badge <?= (int) $category['status'] === 1 ? 'badge-green' : 'badge-gray' ?>"><?= (int) $category['status'] === 1 ? '启用' : '停用' ?></span></td>
                            <td><?= (int) $category['book_count'] ?></td>
                            <td>
                                <div class="actions">
                                    <form method="post" action="<?= url('/admin/taxonomy/category/save') ?>">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id" value="<?= (int) $category['id'] ?>">
                                        <input type="hidden" name="name" value="<?= e($category['name']) ?>">
                                        <input type="hidden" name="code" value="<?= e($category['code']) ?>">
                                        <input type="hidden" name="parent_id" value="<?= (int) $category['parent_id'] ?>">
                                        <input type="hidden" name="sort" value="<?= (int) $category['sort'] ?>">
                                        <input type="hidden" name="status" value="<?= (int) $category['status'] === 1 ? 0 : 1 ?>">
                                        <input type="hidden" name="description" value="<?= e($category['description'] ?? '') ?>">
                                        <button class="btn btn-ghost btn-sm" type="submit"><?= (int) $category['status'] === 1 ? '停用' : '启用' ?></button>
                                    </form>
                                    <form method="post" action="<?= url('/admin/taxonomy/category/' . (int) $category['id'] . '/delete') ?>" data-confirm="确认删除该分类？有作品或子分类时无法删除。" data-danger>
                                        <?= csrf_field() ?>
                                        <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash-can"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="admin-card">
            <div class="card-head">
                <h2>标签管理</h2>
                <span class="hint">作品标签用于检索与筛选</span>
            </div>
            <div class="table-wrap">
                <table class="table" style="min-width:520px;">
                    <thead><tr><th>标签</th><th>编码</th><th>引用作品</th><th style="width:90px;">操作</th></tr></thead>
                    <tbody>
                    <?php if ($tags === []): ?>
                        <tr><td colspan="4"><div class="empty"><i class="fa-solid fa-tag"></i><p>还没有标签。</p></div></td></tr>
                    <?php endif; ?>
                    <?php foreach ($tags as $tag): ?>
                        <tr>
                            <td class="title-cell"><?= e($tag['name']) ?></td>
                            <td><code style="font-size:11px;color:var(--rose-deep);"><?= e($tag['code']) ?></code></td>
                            <td><?= (int) $tag['book_count'] ?></td>
                            <td>
                                <form method="post" action="<?= url('/admin/taxonomy/tag/' . (int) $tag['id'] . '/delete') ?>" data-confirm="确认删除该标签？被作品引用时无法删除。" data-danger>
                                    <?= csrf_field() ?>
                                    <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div>
        <div class="admin-card">
            <div class="card-head"><h2>新建 / 编辑分类</h2></div>
            <form method="post" action="<?= url('/admin/taxonomy/category/save') ?>" data-lock-submit>
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="0">
                <div class="field">
                    <label for="c_name">分类名称</label>
                    <input class="input" id="c_name" type="text" name="name" maxlength="40" required>
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="c_code">分类编码</label>
                    <input class="input" id="c_code" type="text" name="code" maxlength="40" pattern="[a-z0-9_-]{2,40}" placeholder="小写字母 / 数字 / _ / -" required>
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="c_parent">上级分类</label>
                    <select class="select" id="c_parent" name="parent_id">
                        <option value="0">顶级分类</option>
                        <?php foreach ($parents as $parent): ?>
                            <option value="<?= (int) $parent['id'] ?>"><?= e($parent['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="c_sort">排序</label>
                    <input class="input" id="c_sort" type="number" name="sort" value="0">
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="c_desc">描述</label>
                    <textarea class="textarea" id="c_desc" name="description" maxlength="255" style="min-height:70px;"></textarea>
                </div>
                <label class="check-pill" style="margin-top:10px;justify-self:start;">
                    <input type="checkbox" name="status" value="1" checked> 启用
                </label>
                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">保存分类</button>
                </div>
            </form>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>新建标签</h2></div>
            <form method="post" action="<?= url('/admin/taxonomy/tag/save') ?>" data-lock-submit>
                <?= csrf_field() ?>
                <div class="field">
                    <label for="t_name">标签名称</label>
                    <input class="input" id="t_name" type="text" name="name" maxlength="30" required>
                </div>
                <div class="field" style="margin-top:10px;">
                    <label for="t_code">标签编码</label>
                    <input class="input" id="t_code" type="text" name="code" maxlength="30" pattern="[a-z0-9_-]{2,30}" required>
                </div>
                <div class="form-actions">
                    <button class="btn btn-primary" type="submit">创建标签</button>
                </div>
            </form>
        </div>
    </div>
</div>
