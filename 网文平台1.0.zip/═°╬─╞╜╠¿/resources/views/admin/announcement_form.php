<?php
/** 公告编辑 */
$isEdit = $item !== null;
$startValue = $item && !empty($item['start_at']) ? date('Y-m-d\TH:i', strtotime((string) $item['start_at'])) : '';
$endValue = $item && !empty($item['end_at']) ? date('Y-m-d\TH:i', strtotime((string) $item['end_at'])) : '';
$statusValue = $item['status'] ?? 'draft';
?>
<div class="card-head" style="margin-bottom:18px;">
    <div>
        <h2 style="font-size:20px;"><?= $isEdit ? '编辑公告' : '新建公告' ?></h2>
        <p class="hint" style="margin-top:4px;">全站公告展示在首页与公共页；作家专区公告仅作家端可见。</p>
    </div>
    <div class="actions">
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/announcements') ?>"><i class="fa-solid fa-arrow-left"></i> 返回列表</a>
        <?php if ($isEdit): ?>
            <a class="btn btn-soft btn-sm" href="<?= url('/announcement/' . (int) $item['id']) ?>" target="_blank" rel="noopener">前台预览</a>
        <?php endif; ?>
    </div>
</div>

<form class="admin-card" method="post" action="<?= url($isEdit ? '/admin/announcements/' . (int) $item['id'] . '/save' : '/admin/announcements/save') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field full">
            <label for="title">公告标题</label>
            <input class="input" id="title" type="text" name="title" maxlength="120" value="<?= e($item['title'] ?? '') ?>" required>
        </div>
        <div class="field full">
            <label for="summary">摘要（列表展示）</label>
            <input class="input" id="summary" type="text" name="summary" maxlength="255" value="<?= e($item['summary'] ?? '') ?>">
        </div>
        <div class="field">
            <label for="scope">公告范围</label>
            <select class="select" id="scope" name="scope">
                <?php foreach (['site' => '全站公告', 'author' => '作家专区', 'admin' => '后台公告'] as $value => $label): ?>
                    <option value="<?= $value ?>" <?= (string) ($item['scope'] ?? 'site') === $value ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="status">发布状态</label>
            <select class="select" id="status" name="status">
                <?php foreach (['draft' => '草稿', 'published' => '立即发布', 'offline' => '下线'] as $value => $label): ?>
                    <option value="<?= $value ?>" <?= (string) $statusValue === $value ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="start_at">开始展示时间（可选）</label>
            <input class="input" id="start_at" type="datetime-local" name="start_at" value="<?= e($startValue) ?>">
        </div>
        <div class="field">
            <label for="end_at">结束展示时间（可选）</label>
            <input class="input" id="end_at" type="datetime-local" name="end_at" value="<?= e($endValue) ?>">
        </div>
        <div class="field full">
            <label for="content">公告正文</label>
            <textarea class="textarea" id="content" name="content" maxlength="10000" style="min-height:320px;"><?= e($item['content'] ?? '') ?></textarea>
        </div>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit" data-confirm="确认保存公告？">保存公告</button>
        <a class="btn btn-ghost" href="<?= url('/admin/announcements') ?>">取消</a>
    </div>
</form>
