<?php /** 章节管理 */ ?>
<div class="filter-bar">
    <form method="get" action="<?= url('/admin/chapters') ?>">
        <input type="hidden" name="r" value="/admin/chapters">
        <input class="input" type="number" name="book_id" min="0" value="<?= $bookId > 0 ? (int) $bookId : '' ?>" placeholder="作品 ID" style="width:100px;">
        <input class="input search" type="search" name="q" value="<?= e($keyword) ?>" placeholder="章节标题">
        <select class="select" name="status">
            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>全部状态</option>
            <?php foreach (['draft', 'pending', 'published', 'scheduled', 'rejected', 'hidden', 'offline'] as $item): ?>
                <option value="<?= $item ?>" <?= $status === $item ? 'selected' : '' ?>><?= e(status_label($item)) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit">筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/chapters') ?>">重置</a>
    </form>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:900px;">
            <thead>
            <tr>
                <th style="width:60px;">ID</th>
                <th>章节</th>
                <th>作品 / 作者</th>
                <th>状态</th>
                <th>字数</th>
                <th>阅读</th>
                <th>发布时间</th>
                <th style="width:170px;">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="8"><div class="empty"><i class="fa-solid fa-file-lines"></i><p>没有匹配的章节。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td class="sub">#<?= (int) $row['id'] ?></td>
                    <td>
                        <span class="title-cell"><?= e($row['title']) ?></span>
                        <div class="sub">第 <?= (int) $row['chapter_no'] ?> 章</div>
                    </td>
                    <td class="sub">
                        <?= e($row['book_title']) ?><br>
                        <?= author_avatar($row['pen_name'] ?? null, 'xs', $row['author_avatar'] ?? null) ?><?= e($row['pen_name']) ?>
                    </td>
                    <td><span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e(status_label((string) $row['status'])) ?></span></td>
                    <td><?= number_format((int) $row['word_count']) ?></td>
                    <td><?= number_format((int) $row['read_count']) ?></td>
                    <td class="sub">
                        <?= e(format_date((string) $row['published_at'], 'm-d H:i')) ?>
                        <?php if (!empty($row['scheduled_at'])): ?><div class="sub">定时：<?= e(format_date((string) $row['scheduled_at'], 'm-d H:i')) ?></div><?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <a class="btn btn-ghost btn-sm" href="<?= url('/chapter/' . (int) $row['id']) ?>" target="_blank" rel="noopener">阅读</a>
                            <?php if ((string) $row['status'] === 'pending'): ?>
                                <a class="btn btn-soft btn-sm" href="<?= url('/admin/review/chapter/' . (int) $row['id']) ?>">审核</a>
                            <?php endif; ?>
                            <?php if (in_array((string) $row['status'], ['published', 'scheduled'], true)): ?>
                                <form method="post" action="<?= url('/admin/chapters/' . (int) $row['id'] . '/action') ?>" data-confirm="确认隐藏该章节？">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="hide">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <button class="btn btn-ghost btn-sm" type="submit">隐藏</button>
                                </form>
                            <?php endif; ?>
                            <?php if (in_array((string) $row['status'], ['hidden', 'offline', 'recycle'], true)): ?>
                                <form method="post" action="<?= url('/admin/chapters/' . (int) $row['id'] . '/action') ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="restore">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <button class="btn btn-soft btn-sm" type="submit">恢复</button>
                                </form>
                            <?php endif; ?>
                            <?php if ((string) $row['status'] === 'published'): ?>
                                <form method="post" action="<?= url('/admin/chapters/' . (int) $row['id'] . '/action') ?>" data-confirm="确认下架该章节？" data-danger>
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="offline">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <button class="btn btn-danger btn-sm" type="submit">下架</button>
                                </form>
                            <?php endif; ?>
                            <?php if ((string) $row['status'] !== 'recycle'): ?>
                                <form method="post" action="<?= url('/admin/chapters/' . (int) $row['id'] . '/action') ?>" data-confirm="确认删除该章节？将移入回收站，可恢复或彻底删除。" data-danger>
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <button class="btn btn-danger btn-sm" type="submit">删除</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= pager_html($pager) ?>
