<?php /** 后台工作台 */ ?>
<div class="card-head" style="margin-bottom:18px;">
    <div>
        <h2 style="font-size:20px;">今日工作台</h2>
        <p class="hint" style="margin-top:4px;">审核优先处理高优先级任务；举报与评论处置须留下可追溯记录。</p>
    </div>
    <div class="actions">
        <a class="btn btn-soft btn-sm" href="<?= url('/admin/reviews') ?>"><i class="fa-solid fa-clipboard-check"></i> 审核队列</a>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/reports') ?>"><i class="fa-solid fa-flag"></i> 举报处置</a>
    </div>
</div>

<div class="admin-stats">
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-users"></i> 注册用户</div>
        <div class="val"><?= number_format((int) $counts['users']) ?></div>
        <div class="foot">账号总数</div>
    </div>
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-book-open"></i> 作品总数</div>
        <div class="val"><?= number_format((int) $counts['books']) ?></div>
        <div class="foot">公开 <?= number_format((int) $counts['online_books']) ?> 部</div>
    </div>
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-file-lines"></i> 章节总数</div>
        <div class="val"><?= number_format((int) $counts['chapters']) ?></div>
        <div class="foot">含草稿与历史章节</div>
    </div>
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-hourglass-half"></i> 待审任务</div>
        <div class="val"><?= number_format((int) $counts['review_tasks']) ?></div>
        <div class="foot">作品 / 章节 / 认证</div>
    </div>
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-id-card"></i> 作家认证</div>
        <div class="val"><?= number_format((int) $counts['author_applications']) ?></div>
        <div class="foot">待处理申请</div>
    </div>
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-flag"></i> 待处置举报</div>
        <div class="val"><?= number_format((int) $counts['reports']) ?></div>
        <div class="foot">已受理 / 处理中</div>
    </div>
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-comments"></i> 待审评论</div>
        <div class="val"><?= number_format((int) $counts['comments_waiting']) ?></div>
        <div class="foot">先审后发队列</div>
    </div>
    <div class="admin-stat">
        <div class="lbl"><i class="fa-solid fa-toggle-on"></i> 业务开关</div>
        <div class="val"><?= count($switches) ?></div>
        <div class="foot">商业化项锁定</div>
    </div>
</div>

<div class="admin-card">
    <div class="card-head">
        <h2>近 7 日趋势</h2>
        <span class="hint">新增用户 / 新增举报</span>
    </div>
    <div style="display:flex;align-items:flex-end;gap:12px;height:150px;padding:0 4px;">
        <?php foreach ($trend as $row): ?>
            <?php
            $userH = max(3, (int) round(($row['users'] / $maxTrend) * 120));
            $reportH = max(2, (int) round(($row['reports'] / $maxTrend) * 120));
            ?>
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;min-width:0;">
                <div style="display:flex;align-items:flex-end;gap:3px;height:124px;">
                    <span title="新增用户 <?= (int) $row['users'] ?>" style="width:12px;height:<?= $userH ?>px;border-radius:5px 5px 2px 2px;background:linear-gradient(180deg,#c08497,#e2bfc8);"></span>
                    <span title="新增举报 <?= (int) $row['reports'] ?>" style="width:12px;height:<?= $reportH ?>px;border-radius:5px 5px 2px 2px;background:linear-gradient(180deg,#d8b48a,#efdcc3);"></span>
                </div>
                <span style="font-size:9.5px;color:var(--ink-faint);white-space:nowrap;"><?= e(date('m-d', strtotime($row['date']))) ?></span>
            </div>
        <?php endforeach; ?>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:16px;row-gap:6px;font-size:10.5px;color:var(--ink-faint);margin-top:10px;">
        <span><i class="fa-solid fa-square" style="color:#c08497;"></i> 新增用户</span>
        <span><i class="fa-solid fa-square" style="color:#d8b48a;"></i> 新增举报</span>
    </div>
</div>

<div class="review-layout">
    <div>
        <div class="admin-card">
            <div class="card-head">
                <h2>待办审核</h2>
                <a class="btn btn-ghost btn-sm" href="<?= url('/admin/reviews') ?>">全部</a>
            </div>
            <?php if ($tasks === []): ?>
                <div class="empty"><i class="fa-solid fa-clipboard-check"></i><p>审核队列已清空，辛苦了。</p></div>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="table" style="min-width:520px;">
                        <thead><tr><th>对象</th><th>名称</th><th>优先级</th><th>提交时间</th><th>操作</th></tr></thead>
                        <tbody>
                        <?php foreach ($tasks as $task): ?>
                            <?php
                            $type = (string) $task['target_type'];
                            $name = $type === 'book' ? ($task['book_title'] ?? '') : ($type === 'chapter' ? ($task['chapter_title'] ?? '') : '作家认证申请');
                            ?>
                            <tr>
                                <td><span class="badge <?= $type === 'book' ? 'badge-gold' : ($type === 'chapter' ? '' : 'badge-green') ?>"><?= $type === 'book' ? '作品' : ($type === 'chapter' ? '章节' : '认证') ?></span></td>
                                <td class="title-cell"><?= e($name) ?></td>
                                <td><?= (int) $task['priority'] === 1 ? '<span class="badge badge-red">高</span>' : '<span class="badge badge-gray">普通</span>' ?></td>
                                <td class="sub"><?= e(time_ago((string) $task['created_at'])) ?></td>
                                <td>
                                    <?php if ($type === 'author'): ?>
                                        <a class="btn btn-soft btn-sm" href="<?= url('/admin/authors') ?>">去处理</a>
                                    <?php else: ?>
                                        <a class="btn btn-soft btn-sm" href="<?= url('/admin/review/' . $type . '/' . (int) $task['target_id']) ?>">审核</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <div class="admin-card">
            <div class="card-head">
                <h2>最新举报</h2>
                <a class="btn btn-ghost btn-sm" href="<?= url('/admin/reports') ?>">全部</a>
            </div>
            <?php if ($reports === []): ?>
                <div class="empty"><i class="fa-solid fa-shield-halved"></i><p>暂无待处置举报。</p></div>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="table" style="min-width:520px;">
                        <thead><tr><th>编号</th><th>类型</th><th>举报人</th><th>状态</th><th>时间</th><th>操作</th></tr></thead>
                        <tbody>
                        <?php foreach ($reports as $report): ?>
                            <tr>
                                <td>JB<?= str_pad((string) $report['id'], 6, '0', STR_PAD_LEFT) ?></td>
                                <td><?= e(report_category_label((string) $report['category'])) ?></td>
                                <td class="sub"><?= e($report['reporter_name'] ?? '匿名') ?></td>
                                <td><span class="badge badge-gold"><?= e(report_status_label((string) $report['status'])) ?></span></td>
                                <td class="sub"><?= e(time_ago((string) $report['created_at'])) ?></td>
                                <td><a class="btn btn-soft btn-sm" href="<?= url('/admin/reports/' . (int) $report['id']) ?>">查看</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <div class="admin-card">
            <div class="card-head"><h2>最近操作日志</h2></div>
            <?php if ($logs === []): ?>
                <div class="empty"><i class="fa-solid fa-scroll"></i><p>暂无日志。</p></div>
            <?php else: ?>
                <div class="log-list">
                    <?php foreach ($logs as $log): ?>
                        <div class="log-item">
                            <span class="time"><?= e(format_date((string) $log['created_at'], 'm-d H:i')) ?></span>
                            <span class="who"><?= e($log['nickname'] ?? '系统') ?></span>
                            <span class="action"><?= e($log['action']) ?></span>
                            <span class="detail"><?= e(excerpt((string) $log['detail'], 80)) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <a class="btn btn-ghost btn-sm" style="margin-top:10px;" href="<?= url('/admin/logs') ?>">查看全部日志</a>
            <?php endif; ?>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>业务开关概览</h2></div>
            <div class="switch-list">
                <?php foreach (array_slice($switches, 0, 8) as $switch): ?>
                    <div class="switch-item" style="padding:10px 12px;">
                        <div class="info" style="min-width:0;">
                            <div class="name" style="font-size:12px;"><?= e($switch['name']) ?></div>
                            <div class="code"><?= e($switch['code']) ?></div>
                        </div>
                        <span class="switch-state <?= (int) $switch['value'] === 1 ? 'on' : 'off' ?>"><?= (int) $switch['value'] === 1 ? '开启' : '关闭' ?></span>
                        <?php if ((int) $switch['allow_toggle'] !== 1): ?><span class="locked-note"><i class="fa-solid fa-lock"></i></span><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <a class="btn btn-ghost btn-sm" style="margin-top:10px;" href="<?= url('/admin/switches') ?>">开关管理</a>
        </div>
    </div>
</div>
