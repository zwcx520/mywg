<?php
/** 举报处置详情 */
$reportId = (int) $report['id'];
$targetType = (string) $report['target_type'];
$targetLabel = ['book' => '作品', 'cover' => '作品封面', 'summary' => '作品简介', 'chapter' => '章节', 'comment' => '评论', 'user' => '用户'][$targetType] ?? $targetType;
?>
<div class="card-head" style="margin-bottom:18px;">
    <div>
        <h2 style="font-size:20px;">举报处置 · JB<?= str_pad((string) $reportId, 6, '0', STR_PAD_LEFT) ?></h2>
        <p class="hint" style="margin-top:4px;"><?= e(report_category_label((string) $report['category'])) ?> · 提交于 <?= e(format_date((string) $report['created_at'], 'Y-m-d H:i')) ?></p>
    </div>
    <div class="actions">
        <span class="badge <?= status_badge_class((string) $report['status']) ?>"><?= e(report_status_label((string) $report['status'])) ?></span>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/reports') ?>"><i class="fa-solid fa-arrow-left"></i> 返回列表</a>
    </div>
</div>

<div class="review-layout">
    <div>
        <div class="admin-card">
            <div class="card-head"><h2>举报内容</h2></div>
            <div class="review-content" style="font-family:var(--sans);font-size:13px;max-height:260px;"><?= e($report['description'] ?? '未填写补充说明') ?></div>
            <?php if (!empty($report['result'])): ?>
                <div class="flash flash-info" style="margin-top:12px;">
                    <i class="fa-solid fa-circle-info"></i><span>处置结论：<?= e($report['result']) ?></span>
                </div>
            <?php endif; ?>
        </div>

        <div class="admin-card">
            <div class="card-head">
                <h2>被举报对象 · <?= e($targetLabel) ?></h2>
                <?php if ($target && in_array($targetType, ['book', 'chapter', 'cover', 'summary'], true)): ?>
                    <a class="btn btn-ghost btn-sm" href="<?= url($targetType === 'chapter' ? '/chapter/' . (int) $target['id'] : '/book/' . (int) $target['id']) ?>" target="_blank" rel="noopener">前台查看</a>
                <?php endif; ?>
            </div>
            <?php if (!$target): ?>
                <div class="empty"><i class="fa-solid fa-link-slash"></i><p>被举报对象已不存在。</p></div>
            <?php else: ?>
                <div class="review-meta" style="margin-bottom:12px;">
                    <dl>
                        <?php if ($targetType === 'chapter'): ?>
                            <dt>章节</dt><dd><?= e($target['title']) ?>（《<?= e($target['book_title']) ?>》）</dd>
                            <dt>作者</dt><dd><?= author_avatar($target['pen_name'] ?? null, 'xs', $target['author_avatar'] ?? null) ?><?= e($target['pen_name']) ?></dd>
                            <dt>状态</dt><dd><span class="badge <?= status_badge_class((string) $target['status']) ?>"><?= e(status_label((string) $target['status'])) ?></span></dd>
                        <?php elseif (in_array($targetType, ['book', 'cover', 'summary'], true)): ?>
                            <dt>作品</dt><dd><?= e($target['title']) ?></dd>
                            <dt>封面</dt><dd><?= cover_thumb($target['cover'] ?? null, (string) $target['title'], (int) $target['id'], 'sm') ?></dd>
                            <dt>作者</dt><dd><?= author_avatar($target['pen_name'] ?? null, 'xs', $target['author_avatar'] ?? null) ?><?= e($target['pen_name']) ?></dd>
                            <dt>状态</dt><dd><span class="badge <?= status_badge_class((string) $target['status']) ?>"><?= e(status_label((string) $target['status'])) ?></span></dd>
                            <dt>分类</dt><dd><?= e($target['category_name'] ?? '未分类') ?></dd>
                        <?php elseif ($targetType === 'comment'): ?>
                            <dt>评论人</dt><dd><?= e($target['nickname'] ?? '匿名') ?></dd>
                            <dt>所属作品</dt><dd><?= e($target['book_title'] ?? '—') ?></dd>
                            <dt>状态</dt><dd><span class="badge <?= status_badge_class((string) $target['status']) ?>"><?= e(status_label((string) $target['status'])) ?></span></dd>
                        <?php elseif ($targetType === 'user'): ?>
                            <dt>用户</dt><dd><?= e($target['nickname'] ?? $target['login_name']) ?></dd>
                            <dt>状态</dt><dd><span class="badge <?= status_badge_class((string) $target['status']) ?>"><?= e(status_label((string) $target['status'])) ?></span></dd>
                        <?php endif; ?>
                    </dl>
                </div>
                <?php if (!empty($target['preview'])): ?>
                    <div class="review-content" style="max-height:240px;"><?= e(excerpt((string) $target['preview'], 400)) ?></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>处置记录</h2></div>
            <?php if ($actions === []): ?>
                <p class="hint">暂无处置记录。</p>
            <?php else: ?>
                <div class="log-list">
                    <?php foreach ($actions as $action): ?>
                        <div class="log-item">
                            <span class="time"><?= e(format_date((string) $action['created_at'], 'm-d H:i')) ?></span>
                            <span class="who"><?= e($action['nickname'] ?? '管理员') ?></span>
                            <span class="action"><?= e($action['action']) ?></span>
                            <span class="detail"><?= e($action['note'] ?? '') ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <div class="admin-card">
            <div class="card-head"><h2>提交人</h2></div>
            <div style="display:flex;gap:12px;align-items:center;margin-bottom:12px;">
                <?= avatar_thumb($reporter['avatar'] ?? null, $reporter['nickname'] ?? '匿名', 'sm') ?>
                <span style="font-size:13px;"><?= e($reporter['nickname'] ?? '匿名') ?></span>
            </div>
            <div class="review-meta">
                <dl>
                    <dt>昵称</dt><dd><?= e($reporter['nickname'] ?? '匿名') ?></dd>
                    <dt>登录名</dt><dd><?= e($reporter['login_name'] ?? '—') ?></dd>
                    <dt>手机号</dt><dd><?= e(sensitive($reporter['phone'] ?? '', 'phone')) ?></dd>
                </dl>
            </div>
        </div>

        <?php if (auth_can('admin.reports.handle')): ?>
            <div class="admin-card">
                <div class="card-head"><h2>处置操作</h2></div>
                <form method="post" action="<?= url('/admin/reports/' . $reportId . '/act') ?>" data-lock-submit>
                    <?= csrf_field() ?>
                    <div class="field">
                        <label for="status">处置状态</label>
                        <select class="select" id="status" name="status">
                            <?php foreach (['reviewing' => '处理中', 'handled' => '已处理', 'transferred' => '已转交', 'closed' => '已关闭'] as $value => $label): ?>
                                <option value="<?= $value ?>" <?= (string) $report['status'] === $value ? 'selected' : '' ?>><?= $label ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="field" style="margin-top:10px;">
                        <label for="result">处置结论（对举报人可见）</label>
                        <input class="input" id="result" type="text" name="result" maxlength="255" placeholder="如：已核实并下架相关内容">
                    </div>
                    <div class="field" style="margin-top:10px;">
                        <label for="note">内部备注</label>
                        <input class="input" id="note" type="text" name="note" maxlength="255">
                    </div>
                    <label class="check-pill" style="margin-top:12px;justify-self:start;">
                        <input type="checkbox" name="take_down" value="1">
                        同步限制展示（下架对象）
                    </label>
                    <div class="form-actions">
                        <button class="btn btn-primary" type="submit" data-confirm="确认提交处置结果？">提交处置</button>
                    </div>
                </form>
                <p class="hint" style="margin-top:8px;">处置结果会通知举报人，并写入审计日志。</p>
            </div>
        <?php endif; ?>
    </div>
</div>
