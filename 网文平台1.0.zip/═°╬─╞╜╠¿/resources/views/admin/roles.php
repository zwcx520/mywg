<?php /** 角色与权限 */ ?>
<div class="filter-bar" style="justify-content:space-between;">
    <span style="font-size:11.5px;color:var(--ink-faint);line-height:1.9;">权限采用页面级 / 操作级 / 资源级三层校验；站长角色默认保留全部权限，不允许编辑。</span>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table">
            <thead>
            <tr>
                <th style="width:70px;">ID</th>
                <th>角色</th>
                <th>编码</th>
                <th>说明</th>
                <th>权限数</th>
                <th>用户数</th>
                <th style="width:110px;">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($roles as $role): ?>
                <tr>
                    <td class="sub">#<?= (int) $role['id'] ?></td>
                    <td class="title-cell"><?= e($role['name']) ?></td>
                    <td><span class="badge badge-gray"><?= e($role['code']) ?></span></td>
                    <td class="sub"><?= e($role['description'] ?? '—') ?></td>
                    <td><?= (int) $role['permission_count'] ?></td>
                    <td><?= (int) $role['user_count'] ?></td>
                    <td>
                        <a class="btn btn-soft btn-sm" href="<?= url('/admin/roles/' . (int) $role['id'] . '/edit') ?>">
                            <?= (string) $role['code'] === 'admin' ? '查看' : '编辑权限' ?>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="admin-card">
    <div class="card-head"><h2>权限码说明</h2></div>
    <div class="table-wrap">
        <table class="table">
            <thead><tr><th>模块</th><th>权限码</th><th>名称</th><th>动作</th></tr></thead>
            <tbody>
            <?php foreach ($permissions as $permission): ?>
                <tr>
                    <td class="sub"><?= e($permission['module']) ?></td>
                    <td><code style="font-size:11px;color:var(--rose-deep);"><?= e($permission['code']) ?></code></td>
                    <td><?= e($permission['name']) ?></td>
                    <td class="sub"><?= e($permission['action']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
