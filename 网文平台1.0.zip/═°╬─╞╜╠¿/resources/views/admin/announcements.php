<?php
/** 公告管理 */
$scopeLabels = ['site' => '全站公告', 'author' => '作家专区', 'admin' => '后台公告'];
$statusLabels = ['draft' => '草稿', 'published' => '已发布', 'offline' => '已下线'];
?>
<div class="filter-bar" style="justify-content:space-between;">
    <form method="get" action="<?= url('/admin/announcements') ?>">
        <input type="hidden" name="r" value="/admin/announcements">
        <select class="select" name="status">
            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>全部状态</option>
            <?php foreach ($statusLabels as $key => $label): ?>
                <option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= $label ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit">筛选</button>
    </form>
    <a class="btn btn-primary btn-sm" href="<?= url('/admin/announcements/create') ?>"><i class="fa-solid fa-plus"></i> 新建公告</a>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:820px;">
            <thead><tr><th>标题</th><th>范围</th><th>状态</th><th>展示时间</th><th>更新时间</th><th style="width:200px;">操作</th></tr></thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="6"><div class="empty"><i class="fa-solid fa-bullhorn"></i><p>还没有公告。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td>
                        <span class="title-cell"><?= e($row['title']) ?></span>
                        <?php if (!empty($row['summary'])): ?><div class="sub"><?= e(excerpt((string) $row['summary'], 60)) ?></div><?php endif; ?>
                    </td>
                    <td><span class="badge badge-gray"><?= e($scopeLabels[$row['scope']] ?? $row['scope']) ?></span></td>
                    <td><span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e($statusLabels[$row['status']] ?? $row['status']) ?></span></td>
                    <td class="sub">
                        <?= e($row['start_at'] ? format_date((string) $row['start_at'], 'Y-m-d H:i') : '立即') ?>
                        ~ <?= e($row['end_at'] ? format_date((string) $row['end_at'], 'Y-m-d H:i') : '长期') ?>
                    </td>
                    <td class="sub"><?= e(format_date((string) ($row['updated_at'] ?: $row['created_at']), 'm-d H:i')) ?></td>
                    <td>
                        <div class="actions">
                            <a class="btn btn-soft btn-sm" href="<?= url('/admin/announcements/' . (int) $row['id'] . '/edit') ?>">编辑</a>
                            <form method="post" action="<?= url('/admin/announcements/' . (int) $row['id'] . '/status') ?>">
                                <?= csrf_field() ?>
                                <input type="hidden" name="status" value="<?= (string) $row['status'] === 'published' ? 'offline' : 'published' ?>">
                                <button class="btn btn-ghost btn-sm" type="submit"><?= (string) $row['status'] === 'published' ? '下线' : '发布' ?></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
