<?php /** 作品管理 */ ?>
<div class="filter-bar">
    <form method="get" action="<?= url('/admin/books') ?>">
        <input type="hidden" name="r" value="/admin/books">
        <input class="input search" type="search" name="q" value="<?= e($keyword) ?>" placeholder="书名 / 作者笔名 / 作品编号">
        <select class="select" name="status">
            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>全部状态</option>
            <?php foreach (['draft', 'reviewing', 'rejected', 'approved', 'serializing', 'paused', 'finished', 'offline'] as $item): ?>
                <option value="<?= $item ?>" <?= $status === $item ? 'selected' : '' ?>><?= e(status_label($item)) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i> 筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/books') ?>">重置</a>
    </form>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:960px;">
            <thead>
            <tr>
                <th>作品</th>
                <th>作者</th>
                <th>分类</th>
                <th>状态</th>
                <th>字数</th>
                <th>点击 / 收藏</th>
                <th>更新时间</th>
                <th style="width:210px;">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="8"><div class="empty"><i class="fa-solid fa-book-open"></i><p>没有匹配的作品。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td>
                        <div style="display:flex;gap:10px;align-items:flex-start;">
                            <span class="book-cover" style="width:40px;height:54px;flex-shrink:0;background:<?= e(cover_gradient((int) $row['id'])) ?>;border-radius:7px;overflow:hidden;position:relative;">
                                <?php if (!empty($row['cover'])): ?><img src="<?= e(upload_url((string) $row['cover'])) ?>" alt="" style="width:100%;height:100%;object-fit:cover;"><?php endif; ?>
                            </span>
                            <div>
                                <span class="title-cell"><?= e($row['title']) ?></span>
                                <div class="sub"><?= e($row['book_code']) ?><?= !empty($row['is_featured']) ? ' · 编辑推荐' : '' ?></div>
                            </div>
                        </div>
                    </td>
                    <td class="sub"><?= author_avatar($row['pen_name'] ?? null, 'xs', $row['author_avatar'] ?? null) ?><?= e($row['pen_name']) ?></td>
                    <td class="sub"><?= e($row['category_name'] ?? '未分类') ?></td>
                    <td><span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e(status_label((string) $row['status'])) ?></span></td>
                    <td><?= number_format((int) $row['word_count']) ?></td>
                    <td class="sub"><?= number_format((int) $row['view_count']) ?> / <?= number_format((int) $row['favorite_count']) ?></td>
                    <td class="sub"><?= e(format_date((string) $row['updated_at'], 'm-d H:i')) ?></td>
                    <td>
                        <div class="actions">
                            <?php if ((string) $row['status'] === 'reviewing'): ?>
                                <a class="btn btn-soft btn-sm" href="<?= url('/admin/review/book/' . (int) $row['id']) ?>">审核</a>
                            <?php endif; ?>
                            <a class="btn btn-ghost btn-sm" href="<?= url('/book/' . (int) $row['id']) ?>" target="_blank" rel="noopener">前台</a>
                            <a class="btn btn-ghost btn-sm" href="<?= url('/admin/chapters?book_id=' . (int) $row['id']) ?>">章节</a>
                            <?php if ((string) $row['status'] === 'offline'): ?>
                                <form method="post" action="<?= url('/admin/books/' . (int) $row['id'] . '/action') ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="restore">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <button class="btn btn-soft btn-sm" type="submit">恢复</button>
                                </form>
                            <?php elseif ((string) $row['status'] !== 'deleted'): ?>
                                <form method="post" action="<?= url('/admin/books/' . (int) $row['id'] . '/action') ?>" data-confirm="确认下架《<?= e($row['title']) ?>》？前台目录与阅读入口将立即关闭。" data-danger>
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="offline">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <input type="hidden" name="reason" value="后台运营下架">
                                    <button class="btn btn-danger btn-sm" type="submit">下架</button>
                                </form>
                            <?php endif; ?>
                            <?php if (book_is_public((string) $row['status'])): ?>
                                <form method="post" action="<?= url('/admin/books/' . (int) $row['id'] . '/action') ?>">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="<?= !empty($row['is_featured']) ? 'feature_off' : 'feature_on' ?>">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <button class="btn btn-gold btn-sm" type="submit"><?= !empty($row['is_featured']) ? '取消推荐' : '推荐' ?></button>
                                </form>
                            <?php endif; ?>
                            <?php if ((string) $row['status'] !== 'deleted'): ?>
                                <form method="post" action="<?= url('/admin/books/' . (int) $row['id'] . '/action') ?>" data-confirm="确认删除《<?= e($row['title']) ?>》？将移入回收站，可在回收站恢复或彻底删除。" data-danger>
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="status" value="<?= e($status) ?>">
                                    <input type="hidden" name="reason" value="后台删除作品">
                                    <button class="btn btn-danger btn-sm" type="submit">删除</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= pager_html($pager) ?>
