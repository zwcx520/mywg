<?php
/** 活动编辑 */
$isEdit = $item !== null;
$startValue = $item && !empty($item['start_at']) ? date('Y-m-d\TH:i', strtotime((string) $item['start_at'])) : '';
$endValue = $item && !empty($item['end_at']) ? date('Y-m-d\TH:i', strtotime((string) $item['end_at'])) : '';
$statusValue = $item['status'] ?? 'draft';
?>
<div class="card-head" style="margin-bottom:18px;">
    <div>
        <h2 style="font-size:20px;"><?= $isEdit ? '编辑活动' : '新建活动' ?></h2>
        <p class="hint" style="margin-top:4px;">活动仅用于内容运营展示，商业化玩法在第一版中保持关闭。</p>
    </div>
    <div class="actions">
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/activities') ?>"><i class="fa-solid fa-arrow-left"></i> 返回列表</a>
        <?php if ($isEdit): ?>
            <a class="btn btn-soft btn-sm" href="<?= url('/activity/' . (int) $item['id']) ?>" target="_blank" rel="noopener">前台预览</a>
        <?php endif; ?>
    </div>
</div>

<form class="admin-card" method="post" action="<?= url($isEdit ? '/admin/activities/' . (int) $item['id'] . '/save' : '/admin/activities/save') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <div class="form-grid">
        <div class="field full">
            <label for="title">活动标题</label>
            <input class="input" id="title" type="text" name="title" maxlength="120" value="<?= e($item['title'] ?? '') ?>" required>
        </div>
        <div class="field full">
            <label for="summary">活动摘要</label>
            <input class="input" id="summary" type="text" name="summary" maxlength="255" value="<?= e($item['summary'] ?? '') ?>">
        </div>
        <div class="field">
            <label for="cover">封面地址</label>
            <input class="input" id="cover" type="text" name="cover" maxlength="255" value="<?= e($item['cover'] ?? '') ?>" placeholder="https://... 或 uploads/...">
            <span class="hint">也可以留空，前台将使用渐变封面。</span>
        </div>
        <div class="field">
            <label for="status">活动状态</label>
            <select class="select" id="status" name="status">
                <?php foreach (['draft' => '草稿', 'published' => '立即发布', 'offline' => '下线'] as $value => $label): ?>
                    <option value="<?= $value ?>" <?= (string) $statusValue === $value ? 'selected' : '' ?>><?= $label ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="start_at">开始时间</label>
            <input class="input" id="start_at" type="datetime-local" name="start_at" value="<?= e($startValue) ?>">
        </div>
        <div class="field">
            <label for="end_at">结束时间</label>
            <input class="input" id="end_at" type="datetime-local" name="end_at" value="<?= e($endValue) ?>">
        </div>
        <div class="field full">
            <label for="content">活动正文</label>
            <textarea class="textarea" id="content" name="content" maxlength="10000" style="min-height:320px;"><?= e($item['content'] ?? '') ?></textarea>
        </div>
    </div>
    <div class="form-actions">
        <button class="btn btn-primary" type="submit" data-confirm="确认保存活动？">保存活动</button>
        <a class="btn btn-ghost" href="<?= url('/admin/activities') ?>">取消</a>
    </div>
</form>
