<?php
/** 角色权限编辑 */
$isAdminRole = (string) $role['code'] === 'admin';
$grouped = [];
foreach ($permissions as $permission) {
    $grouped[(string) $permission['module']][] = $permission;
}
?>
<div class="card-head" style="margin-bottom:18px;">
    <div>
        <h2 style="font-size:20px;"><?= e($role['name']) ?></h2>
        <p class="hint" style="margin-top:4px;">编码 <?= e($role['code']) ?> · <?= e($role['description'] ?? '无说明') ?></p>
    </div>
    <div class="actions">
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/roles') ?>"><i class="fa-solid fa-arrow-left"></i> 返回角色列表</a>
    </div>
</div>

<?php if ($isAdminRole): ?>
    <div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
        <p style="font-size:12px;color:#8a6438;line-height:2;">
            <i class="fa-solid fa-lock"></i>
            站长角色为系统保留角色，始终拥有全部权限，不允许修改。若需要分级管理，请为运营、审核、编辑等岗位创建独立角色。
        </p>
    </div>
<?php endif; ?>

<form method="post" action="<?= url('/admin/roles/' . (int) $role['id'] . '/save') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <?php foreach ($grouped as $module => $items): ?>
        <div class="admin-card">
            <div class="card-head">
                <h2><?= e($module) ?> 模块</h2>
                <span class="hint"><?= count($items) ?> 项权限</span>
            </div>
            <div class="switch-list">
                <?php foreach ($items as $permission): ?>
                    <label class="switch-item" style="cursor:<?= $isAdminRole ? 'not-allowed' : 'pointer' ?>;">
                        <input type="checkbox" name="permissions[]" value="<?= (int) $permission['id'] ?>"
                            <?= in_array((int) $permission['id'], $selected, true) ? 'checked' : '' ?>
                            <?= $isAdminRole ? 'disabled' : '' ?>>
                        <span class="info">
                            <span class="name"><?= e($permission['name']) ?></span>
                            <span class="code"><?= e($permission['code']) ?></span>
                            <span class="desc">动作：<?= e($permission['action']) ?></span>
                        </span>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>

    <?php if (!$isAdminRole): ?>
        <div class="form-actions">
            <button class="btn btn-primary" type="submit" data-confirm="确认保存该角色的权限配置？">保存权限</button>
            <a class="btn btn-ghost" href="<?= url('/admin/roles') ?>">取消</a>
        </div>
    <?php endif; ?>
</form>
