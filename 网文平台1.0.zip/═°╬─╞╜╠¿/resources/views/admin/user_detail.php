<?php
/** 用户详情 */
$userId = (int) $user['id'];
$roleNameMap = [];
foreach ($roles as $role) {
    $roleNameMap[(int) $role['id']] = (string) $role['name'];
}
?>
<div class="card-head" style="margin-bottom:18px;">
    <div style="display:flex;gap:14px;align-items:center;">
        <?= avatar_thumb($user['avatar'] ?? null, $user['nickname'] ?? $user['login_name'], 'lg') ?>
        <div>
            <h2 style="font-size:20px;"><?= e($user['nickname'] ?? $user['login_name']) ?></h2>
            <p class="hint" style="margin-top:4px;">#<?= $userId ?> · 注册于 <?= e(format_date((string) $user['created_at'], 'Y-m-d H:i')) ?></p>
        </div>
    </div>
    <div class="actions">
        <span class="badge <?= status_badge_class((string) $user['status']) ?>"><?= e(status_label((string) $user['status'])) ?></span>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/users') ?>"><i class="fa-solid fa-arrow-left"></i> 返回</a>
    </div>
</div>

<?php if (!is_site_owner()): ?>
    <div class="admin-card" style="margin-bottom:18px;padding:12px 16px;">
        <span class="hint"><i class="fa-solid fa-shield-halved"></i> 仅站长可查看完整用户信息；当前账号所见手机号、邮箱、IP 与实名信息均已脱敏。</span>
    </div>
<?php endif; ?>

<div class="review-layout">
    <div>
        <div class="admin-card">
            <div class="card-head"><h2>基础资料</h2></div>
            <div class="review-meta">
                <dl>
                    <dt>登录名</dt><dd><?= e($user['login_name']) ?></dd>
                    <dt>昵称</dt><dd><?= e($user['nickname'] ?? '—') ?></dd>
                    <dt>手机号</dt><dd><?= e(sensitive($user['phone'] ?? '', 'phone')) ?></dd>
                    <dt>邮箱</dt><dd><?= e(sensitive($user['email'] ?? '', 'email')) ?></dd>
                    <dt>城市 / 性别</dt><dd><?= e(($user['city'] ?? '—') . ' / ' . ($user['gender'] ?? '—')) ?></dd>
                    <dt>注册 IP</dt><dd><?= e(sensitive($user['register_ip'] ?? '', 'ip')) ?></dd>
                    <dt>最近登录</dt><dd><?= e($user['last_login_at'] ? format_date((string) $user['last_login_at'], 'Y-m-d H:i') : '—') ?></dd>
                    <dt>个人简介</dt><dd><?= e($user['bio'] ?? '—') ?></dd>
                </dl>
            </div>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>作家身份</h2></div>
            <div class="review-meta">
                <dl>
                    <dt>作家状态</dt>
                    <dd>
                        <?php if ($author): ?>
                            <span class="badge <?= status_badge_class((string) $author['status']) ?>"><?= e(status_label((string) $author['status'])) ?></span>
                            <span class="sub" style="margin-left:6px;">笔名：<?= author_avatar($author['pen_name'] ?? null, 'xs', $user['avatar'] ?: ($author['avatar'] ?? null)) ?><?= e($author['pen_name']) ?></span>
                        <?php else: ?>
                            <span class="badge badge-gray">未认证</span>
                        <?php endif; ?>
                    </dd>
                    <dt>最近申请</dt>
                    <dd>
                        <?php if ($application): ?>
                            笔名 <?= author_avatar($application['pen_name'] ?? null) ?><?= e($application['pen_name']) ?> ·
                            <span class="badge <?= status_badge_class((string) $application['status']) ?>"><?= e(status_label((string) $application['status'])) ?></span>
                            <span class="sub" style="margin-left:6px;"><?= e(format_date((string) $application['created_at'], 'Y-m-d H:i')) ?></span>
                            <?php if (!empty($application['remark'])): ?><div class="sub" style="margin-top:4px;">备注：<?= e($application['remark']) ?></div><?php endif; ?>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </dd>
                    <dt>实名核验</dt>
                    <dd>
                        <?php if ($identity): ?>
                            状态 <span class="badge <?= status_badge_class((string) $identity['status']) ?>"><?= e(status_label((string) $identity['status'])) ?></span>
                            <dl style="margin-top:8px;">
                                <dt>真实姓名</dt><dd><?= e(sensitive($identity['real_name'] ?? '', 'name')) ?></dd>
                                <dt>证件号码</dt><dd><?= e(sensitive($identity['id_no'] ?? '', 'id_no')) ?></dd>
                                <dt>认证手机</dt><dd><?= e(sensitive($identity['phone'] ?? '', 'phone')) ?></dd>
                            </dl>
                            <?php if (!is_site_owner()): ?>
                                <div class="sub" style="margin-top:4px;">非站长账号，敏感信息已脱敏展示。</div>
                            <?php endif; ?>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </dd>
                </dl>
            </div>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>作品</h2><span class="hint">最近 10 部</span></div>
            <?php if ($books === []): ?>
                <div class="empty"><i class="fa-solid fa-book-open"></i><p>该用户暂无可管理作品。</p></div>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="table" style="min-width:520px;">
                        <thead><tr><th>作品</th><th>状态</th><th>字数</th><th>更新</th><th>操作</th></tr></thead>
                        <tbody>
                        <?php foreach ($books as $book): ?>
                            <tr>
                                <td class="title-cell"><?= e($book['title']) ?></td>
                                <td><span class="badge <?= status_badge_class((string) $book['status']) ?>"><?= e(status_label((string) $book['status'])) ?></span></td>
                                <td><?= number_format((int) $book['word_count']) ?></td>
                                <td class="sub"><?= e(format_date((string) $book['updated_at'], 'Y-m-d')) ?></td>
                                <td><a class="btn btn-ghost btn-sm" href="<?= url('/admin/chapters?book_id=' . (int) $book['id']) ?>">章节</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <div class="admin-card">
            <div class="card-head"><h2>举报与登录记录</h2></div>
            <div class="split-grid">
                <div>
                    <p class="hint" style="margin-bottom:6px;">该用户发起的举报</p>
                    <?php if ($reports === []): ?>
                        <p class="hint">无记录。</p>
                    <?php else: ?>
                        <div class="log-list">
                            <?php foreach ($reports as $report): ?>
                                <div class="log-item">
                                    <span class="time"><?= e(format_date((string) $report['created_at'], 'm-d')) ?></span>
                                    <span class="detail"><?= e(report_category_label((string) $report['category'])) ?> · <?= e(report_status_label((string) $report['status'])) ?></span>
                                    <a class="btn btn-ghost btn-sm" href="<?= url('/admin/reports/' . (int) $report['id']) ?>">查看</a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div>
                    <p class="hint" style="margin-bottom:6px;">最近登录</p>
                    <?php if ($loginLogs === []): ?>
                        <p class="hint">无记录。</p>
                    <?php else: ?>
                        <div class="log-list">
                            <?php foreach ($loginLogs as $loginLog): ?>
                                <div class="log-item">
                                    <span class="time"><?= e(format_date((string) $loginLog['created_at'], 'm-d H:i')) ?></span>
                                    <span class="detail"><?= e(sensitive((string) $loginLog['ip'], 'ip')) ?> · <?= (string) $loginLog['result'] === 'success' ? '成功' : '失败' ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div>
        <?php if (!$canManageTarget): ?>
            <div class="admin-card">
                <div class="card-head"><h2>账号保护</h2></div>
                <p class="hint"><i class="fa-solid fa-shield-halved"></i> <?= $isPrimaryTarget ? '该账号为初始站长，受系统保护，任何账号都不能调整其状态或角色。' : '该账号拥有站长角色，只有初始站长可以管理。' ?></p>
            </div>
        <?php else: ?>
        <?php if (auth_can('admin.users.manage')): ?>
            <div class="admin-card">
                <div class="card-head"><h2>账号状态</h2></div>
                <form method="post" action="<?= url('/admin/users/' . $userId . '/status') ?>" data-lock-submit>
                    <?= csrf_field() ?>
                    <div class="field">
                        <label for="status">调整状态</label>
                        <select class="select" id="status" name="status">
                            <?php foreach (['active', 'limited', 'locked', 'risk', 'deleting'] as $item): ?>
                                <option value="<?= $item ?>" <?= (string) $user['status'] === $item ? 'selected' : '' ?>><?= e(status_label($item)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="field" style="margin-top:10px;">
                        <label for="reason">变更原因</label>
                        <input class="input" id="reason" type="text" name="reason" maxlength="255" placeholder="将写入审计日志并通知用户">
                    </div>
                    <div class="form-actions">
                        <button class="btn btn-primary btn-sm" type="submit" data-confirm="确认调整该用户状态？变更会通知用户并记录日志。">保存状态</button>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <?php if (auth_can('admin.roles.manage')): ?>
            <div class="admin-card">
                <div class="card-head"><h2>角色分配</h2></div>
                <form method="post" action="<?= url('/admin/users/' . $userId . '/roles') ?>" data-lock-submit>
                    <?= csrf_field() ?>
                    <div class="switch-list">
                        <?php foreach ($roles as $role): ?>
                            <label class="switch-item" style="padding:9px 12px;cursor:pointer;">
                                <input type="checkbox" name="roles[]" value="<?= (int) $role['id'] ?>" <?= in_array((int) $role['id'], $userRoles, true) ? 'checked' : '' ?>>
                                <span class="info" style="min-width:0;">
                                    <span class="name"><?= e($role['name']) ?></span>
                                    <span class="code"><?= e($role['code']) ?></span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <div class="form-actions">
                        <button class="btn btn-primary btn-sm" type="submit">保存角色</button>
                    </div>
                </form>
                <p class="hint" style="margin-top:8px;">至少保留一个角色；站长角色账号受保护，不能调整。「认证作家」与作家身份双向同步：勾选即开通作家中心，取消勾选会立即撤销其作家身份（作品数据保留）。</p>
            </div>
        <?php endif; ?>
        <?php if (auth_can('admin.users.manage')): ?>
            <div class="admin-card">
                <div class="card-head"><h2>重置密码</h2></div>
                <p class="hint">站长直接设置新密码，请线下告知用户本人。</p>
                <form method="post" action="<?= url('/admin/users/' . (int) $user['id'] . '/password') ?>" data-lock-submit>
                    <?= csrf_field() ?>
                    <div class="field">
                        <label for="u_password">新密码</label>
                        <input class="input" id="u_password" type="password" name="password" minlength="8" autocomplete="new-password" required>
                    </div>
                    <div class="field" style="margin-top:10px;">
                        <label for="u_password_confirm">确认新密码</label>
                        <input class="input" id="u_password_confirm" type="password" name="confirm_password" minlength="8" autocomplete="new-password" required>
                    </div>
                    <div class="form-actions">
                        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-key"></i> 重置密码</button>
                    </div>
                </form>
            </div>
            <div class="admin-card" style="border-color:rgba(190,60,60,.35);">
                <div class="card-head"><h2>删除账号</h2></div>
                <?php if (!$canManageTarget): ?>
                    <p class="hint">该账号受保护，不能删除。</p>
                <?php elseif ((string) $user['status'] === 'deleted'): ?>
                    <p class="hint">该账号已被删除，无法登录。</p>
                <?php else: ?>
                    <form method="post" action="<?= url('/admin/users/' . (int) $user['id'] . '/delete') ?>" data-confirm="确认删除账号「<?= e($user['login_name']) ?>」？删除后该用户立即退出且无法登录，作品与历史数据保留。" data-danger>
                        <?= csrf_field() ?>
                        <p class="hint">软删除：账号不可登录，作品、评论等内容数据保留。</p>
                        <div class="form-actions">
                            <button class="btn btn-danger" type="submit"><i class="fa-solid fa-user-slash"></i> 删除账号</button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php endif; ?>

        <div class="admin-card">
            <div class="card-head"><h2>操作记录</h2></div>
            <?php if ($logs === []): ?>
                <p class="hint">该用户暂无后台操作记录。</p>
            <?php else: ?>
                <div class="log-list">
                    <?php foreach ($logs as $log): ?>
                        <div class="log-item">
                            <span class="time"><?= e(format_date((string) $log['created_at'], 'm-d H:i')) ?></span>
                            <span class="action"><?= e($log['action']) ?></span>
                            <span class="detail"><?= e(excerpt((string) $log['detail'], 60)) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
