<?php
/** 审核详情 */
$isBook = $type === 'book';
$entityId = (int) $entity['id'];
?>
<div class="card-head" style="margin-bottom:18px;">
    <div>
        <h2 style="font-size:20px;"><?= $isBook ? '作品审核' : '章节审核' ?> · <?= e($entity['title']) ?></h2>
        <p class="hint" style="margin-top:4px;">
            <?php if ($isBook): ?>
                作者 <?= author_avatar($entity['pen_name'] ?? null, 'xs', $entity['author_avatar'] ?? null) ?><?= e($entity['pen_name']) ?> · <?= e($entity['category_name'] ?? '未分类') ?> · <?= number_format((int) $entity['word_count']) ?> 字
            <?php else: ?>
                《<?= e($entity['book_title']) ?>》· 第 <?= (int) $entity['chapter_no'] ?> 章 · 作者 <?= author_avatar($entity['pen_name'] ?? null, 'xs', $entity['author_avatar'] ?? null) ?><?= e($entity['pen_name']) ?>
            <?php endif; ?>
        </p>
    </div>
    <div class="actions">
        <span class="badge <?= status_badge_class((string) $entity['status']) ?>"><?= e(status_label((string) $entity['status'])) ?></span>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/reviews?tab=' . ($isBook ? 'book' : 'chapter')) ?>"><i class="fa-solid fa-arrow-left"></i> 返回队列</a>
    </div>
</div>

<div class="review-layout">
    <div>
        <div class="admin-card">
            <div class="card-head">
                <h2><?= $isBook ? '作品简介' : '提交审核的正文版本' ?></h2>
                <?php if (!$isBook && !empty($versionNo)): ?>
                    <span class="hint">审核版本 v<?= (int) $versionNo ?></span>
                <?php endif; ?>
            </div>
            <div class="review-content"><?= e($content !== '' ? $content : '（该版本没有正文内容）') ?></div>
            <?php if ($isBook): ?>
                <div class="review-meta" style="margin-top:16px;">
                    <dl>
                        <dt>作品封面</dt><dd><?= cover_thumb($entity['cover'] ?? null, (string) $entity['title'], (int) $entity['id'], 'sm') ?></dd>
                        <dt>作品编号</dt><dd><?= e($entity['book_code'] ?? '—') ?></dd>
                        <dt>版权说明</dt><dd><?= e($entity['copyright_note'] ?? '—') ?></dd>
                        <dt>创建时间</dt><dd><?= e(format_date((string) $entity['created_at'], 'Y-m-d H:i')) ?></dd>
                        <dt>点击 / 收藏</dt><dd><?= number_format((int) $entity['view_count']) ?> / <?= number_format((int) $entity['favorite_count']) ?></dd>
                        <dt>实名状态</dt><dd><?= $identity ? e(status_label((string) $identity['status'])) : '未提交' ?></dd>
                    </dl>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($isBook): ?>
            <div class="admin-card">
                <div class="card-head"><h2>章节清单</h2><span class="hint">前 30 章</span></div>
                <?php if ($chapters === []): ?>
                    <div class="empty"><i class="fa-solid fa-file-lines"></i><p>该作品还没有章节。</p></div>
                <?php else: ?>
                    <div class="table-wrap">
                        <table class="table" style="min-width:520px;">
                            <thead><tr><th>章序</th><th>标题</th><th>状态</th><th>字数</th><th>操作</th></tr></thead>
                            <tbody>
                            <?php foreach ($chapters as $chapter): ?>
                                <tr>
                                    <td class="sub"><?= (int) $chapter['id'] ?></td>
                                    <td class="title-cell"><?= e($chapter['title']) ?></td>
                                    <td><span class="badge <?= status_badge_class((string) $chapter['status']) ?>"><?= e(status_label((string) $chapter['status'])) ?></span></td>
                                    <td><?= number_format((int) $chapter['word_count']) ?></td>
                                    <td><a class="btn btn-ghost btn-sm" href="<?= url('/admin/review/chapter/' . (int) $chapter['id']) ?>">查看</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="admin-card">
            <div class="card-head"><h2>审核记录</h2></div>
            <?php if ($reviews === []): ?>
                <p class="hint">暂无审核记录。</p>
            <?php else: ?>
                <div class="log-list">
                    <?php foreach ($reviews as $review): ?>
                        <div class="log-item">
                            <span class="time"><?= e(format_date((string) $review['created_at'], 'm-d H:i')) ?></span>
                            <span class="who"><?= e($review['nickname'] ?? '审核员') ?></span>
                            <span class="action"><?= e(status_label((string) $review['action'])) ?></span>
                            <span class="detail"><?= e($review['reason'] ?? '') ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div>
        <div class="admin-card">
            <div class="card-head"><h2>审核处置</h2></div>
            <?php if (auth_can('admin.review.handle')): ?>
                <form method="post" action="<?= url('/admin/review/' . $type . '/' . $entityId . '/act') ?>" data-lock-submit>
                    <?= csrf_field() ?>
                    <div class="field">
                        <label for="reason">驳回原因（驳回必填）</label>
                        <textarea class="textarea" id="reason" name="reason" maxlength="255" style="min-height:80px;" placeholder="请写明具体问题与修改建议"></textarea>
                    </div>
                    <div class="field" style="margin-top:10px;">
                        <label for="note">审核备注（可选，仅后台可见）</label>
                        <input class="input" id="note" type="text" name="note" maxlength="500">
                    </div>
                    <div class="form-actions">
                        <button class="btn btn-primary" type="submit" name="action" value="approve" data-confirm="确认通过该<?= $isBook ? '作品' : '章节' ?>？通过后将按发布流程处理。">
                            <i class="fa-solid fa-circle-check"></i> 通过
                        </button>
                        <button class="btn btn-danger" type="submit" name="action" value="reject" data-confirm="确认驳回？请确保已填写原因。">
                            <i class="fa-solid fa-circle-xmark"></i> 驳回
                        </button>
                    </div>
                </form>
            <?php else: ?>
                <div class="empty"><i class="fa-solid fa-lock"></i><p>当前账号没有内容处置权限。</p></div>
            <?php endif; ?>
        </div>

        <?php if (!$isBook && !empty($versions)): ?>
            <div class="admin-card">
                <div class="card-head"><h2>版本流</h2></div>
                <div class="version-list">
                    <?php foreach ($versions as $version): ?>
                        <div class="version-item" style="display:flex;justify-content:space-between;gap:8px;">
                            <span>v<?= (int) $version['version_no'] ?> · <?= $version['kind'] === 'publish' ? '发布版' : '审核版' ?></span>
                            <span><?= number_format((int) $version['word_count']) ?> 字 · <?= e(format_date((string) $version['created_at'], 'm-d H:i')) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
            <p style="font-size:11.5px;color:#8a6438;line-height:2;">
                <i class="fa-solid fa-scale-balanced"></i>
                审核须核对违法不良信息、侵权风险、未成年人保护与外部引流。通过后作品/章节将进入发布流程，所有处置记录会写入审计日志。
            </p>
        </div>
    </div>
</div>
