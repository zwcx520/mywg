<?php /** 作家认证审核 */ ?>
<div class="tabs">
    <?php foreach (['pending' => '待审核', 'approved' => '已通过', 'rejected' => '已驳回', 'all' => '全部'] as $key => $label): ?>
        <a class="tab <?= $status === $key ? 'is-active' : '' ?>" href="<?= url('/admin/authors?status=' . $key) ?>"><?= $label ?></a>
    <?php endforeach; ?>
</div>

<?php if ($rows === []): ?>
    <div class="admin-card"><div class="empty"><i class="fa-solid fa-id-card"></i><p>当前筛选下没有认证申请。</p></div></div>
<?php else: ?>
    <div class="simple-list">
        <?php foreach ($rows as $row): ?>
            <div class="admin-card" style="padding:18px 22px;margin-bottom:0;">
                <div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-start;">
                    <div style="flex:1;min-width:240px;">
                        <div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap;">
                            <?= avatar_thumb($row['avatar'] ?? null, $row['nickname'] ?? $row['login_name'], 'sm') ?>
                            <h2 style="font-size:16px;"><?= e($row['pen_name']) ?></h2>
                            <span class="badge <?= status_badge_class((string) $row['status']) ?>"><?= e(status_label((string) $row['status'])) ?></span>
                        </div>
                        <div class="sub" style="margin-top:5px;line-height:1.9;">
                            申请人：<?= e($row['nickname'] ?? $row['login_name']) ?>（<?= e($row['login_name']) ?>） ·
                            账号状态：<?= e(status_label((string) $row['user_status'])) ?><br>
                            真实姓名：<?= e(sensitive($row['real_name'] ?? '', 'name')) ?> ·
                            手机：<?= e(sensitive($row['phone'] ?? '', 'phone')) ?> ·
                            证件：<?= e(sensitive($row['id_no'] ?? '', 'id_no')) ?><br>
                            提交时间：<?= e(format_date((string) $row['created_at'], 'Y-m-d H:i')) ?>
                        </div>
                        <?php if (!empty($row['intro'])): ?>
                            <p style="font-size:12px;color:var(--ink-soft);margin-top:8px;line-height:1.9;">创作简介：<?= e($row['intro']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($row['remark'])): ?>
                            <div class="flash flash-info" style="margin-top:10px;font-size:11.5px;">
                                <i class="fa-solid fa-circle-info"></i><span>审核备注：<?= e($row['remark']) ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if ((string) $row['status'] === 'pending'): ?>
                        <div style="width:250px;flex-shrink:0;">
                            <form method="post" action="<?= url('/admin/authors/' . (int) $row['id'] . '/review') ?>" data-lock-submit>
                                <?= csrf_field() ?>
                                <div class="field">
                                    <label for="remark_<?= (int) $row['id'] ?>">审核备注（驳回必填）</label>
                                    <input class="input" id="remark_<?= (int) $row['id'] ?>" type="text" name="remark" maxlength="255" placeholder="如：材料不完整，请补充">
                                </div>
                                <div style="display:flex;gap:8px;margin-top:10px;">
                                    <button class="btn btn-primary btn-sm" type="submit" name="action" value="approve" data-confirm="确认通过该作家认证？">通过</button>
                                    <button class="btn btn-danger btn-sm" type="submit" name="action" value="reject" data-confirm="确认驳回该认证申请？">驳回</button>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);margin-top:18px;">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-shield-halved"></i>
        实名材料仅用于身份核验：审核端只展示脱敏信息，禁止下载、转发或截图留存。通过后系统自动开通作家角色与创作权限。
    </p>
</div>
