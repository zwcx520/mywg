<?php
/** 回收站（后台） */
$typeLabels = ['book' => '作品', 'volume' => '分卷', 'chapter' => '章节', 'comment' => '评论', 'bookshelf' => '书架记录'];
?>
<div class="filter-bar">
    <form method="get" action="<?= url('/admin/recycle') ?>">
        <input type="hidden" name="r" value="/admin/recycle">
        <select class="select" name="type">
            <option value="all" <?= $type === 'all' ? 'selected' : '' ?>>全部类型</option>
            <?php foreach ($typeLabels as $key => $label): ?>
                <option value="<?= $key ?>" <?= $type === $key ? 'selected' : '' ?>><?= $label ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary btn-sm" type="submit">筛选</button>
        <a class="btn btn-ghost btn-sm" href="<?= url('/admin/recycle') ?>">重置</a>
    </form>
</div>

<div class="admin-card flush">
    <div class="table-wrap" style="border:0;">
        <table class="table" style="min-width:900px;">
            <thead>
            <tr>
                <th style="width:70px;">ID</th>
                <th>内容</th>
                <th>类型</th>
                <th>归属</th>
                <th>删除原因</th>
                <th>删除时间</th>
                <th>恢复截止</th>
                <th style="width:170px;">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($rows === []): ?>
                <tr><td colspan="8"><div class="empty"><i class="fa-solid fa-trash-can"></i><p>回收站是空的。</p></div></td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
                <?php $expired = !empty($row['restore_deadline']) && strtotime((string) $row['restore_deadline']) < time(); ?>
                <tr>
                    <td class="sub">#<?= (int) $row['id'] ?></td>
                    <td class="title-cell"><?= e($row['title']) ?></td>
                    <td><span class="badge badge-gray"><?= e($typeLabels[$row['target_type']] ?? $row['target_type']) ?></span></td>
                    <td class="sub"><?= e($row['owner_name'] ?? '—') ?></td>
                    <td class="sub"><?= e($row['reason'] ?? '—') ?></td>
                    <td class="sub"><?= e(format_date((string) $row['deleted_at'], 'Y-m-d H:i')) ?></td>
                    <td class="sub"><?= e($row['restore_deadline'] ? format_date((string) $row['restore_deadline'], 'Y-m-d H:i') : '—') ?><?= $expired ? ' <span class="badge badge-red">已过期</span>' : '' ?></td>
                    <td>
                        <div class="actions">
                            <form method="post" action="<?= url('/admin/recycle/' . (int) $row['id'] . '/restore') ?>" data-confirm="确认恢复该内容？">
                                <?= csrf_field() ?>
                                <button class="btn btn-soft btn-sm" type="submit" <?= $expired ? 'disabled' : '' ?>>恢复</button>
                            </form>
                            <form method="post" action="<?= url('/admin/recycle/' . (int) $row['id'] . '/purge') ?>" data-confirm="彻底删除后不可恢复，确认继续？" data-danger>
                                <?= csrf_field() ?>
                                <button class="btn btn-danger btn-sm" type="submit">彻底删除</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= pager_html($pager) ?>

<div class="admin-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);margin-top:18px;">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-triangle-exclamation"></i>
        彻底删除会从数据库移除该内容及其全部关联数据（章节正文、版本、评论、书架、推荐位等），删除后无法找回。请先确认举报处置与备份完成。
    </p>
</div>
