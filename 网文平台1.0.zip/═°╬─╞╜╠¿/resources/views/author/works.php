<?php /** 我的作品 */ ?>
<div class="account-head">
    <h1>我的作品</h1>
    <p>共 <?= count($rows) ?> 部作品。作品须先通过审核，章节才能进入发布流程。</p>
</div>

<div class="form-card" style="padding:16px 20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
    <span style="font-size:12px;color:var(--ink-faint);">状态说明：草稿 → 待审核 → 已通过 / 已驳回；通过后方可发布章节。</span>
    <a class="btn btn-primary btn-sm" href="<?= url('/author/work/create') ?>"><i class="fa-solid fa-plus"></i> 新建作品</a>
</div>

<?php if ($rows === []): ?>
    <div class="empty" style="padding:44px 20px;">
        <i class="fa-solid fa-feather-pointed"></i>
        <p>还没有作品。每一个故事，都从第一行开始。</p>
        <a class="btn btn-primary btn-sm" style="margin-top:14px;" href="<?= url('/author/work/create') ?>">新建第一部作品</a>
    </div>
<?php else: ?>
    <div class="simple-list">
        <?php foreach ($rows as $row): ?>
            <div class="form-card" style="padding:18px 20px;margin-bottom:0;">
                <div style="display:flex;gap:16px;align-items:flex-start;">
                    <span class="book-cover" style="width:64px;background:<?= e(cover_gradient((int) $row['id'])) ?>;">
                        <?php if (!empty($row['cover'])): ?>
                            <img src="<?= e(upload_url((string) $row['cover'])) ?>" alt="">
                        <?php endif; ?>
                        <span class="cover-title" style="font-size:10px;"><?= e($row['title']) ?></span>
                    </span>
                    <div style="flex:1;min-width:0;">
                        <div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap;">
                            <a style="font-family:var(--serif);font-size:17px;" href="<?= url('/author/work/' . (int) $row['id'] . '/chapters') ?>"><?= e($row['title']) ?></a>
                            <span class="badge <?= $row['status'] === 'serializing' ? 'badge-green' : ($row['status'] === 'draft' ? 'badge-gray' : ($row['status'] === 'rejected' ? 'badge-red' : 'badge-gold')) ?>"><?= e(status_label((string) $row['status'])) ?></span>
                            <?php if (!empty($row['is_featured'])): ?><span class="badge badge-gold">编辑推荐</span><?php endif; ?>
                        </div>
                        <div style="font-size:11.5px;color:var(--ink-faint);margin-top:5px;">
                            <?= e($row['category_name'] ?? '未分类') ?> ·
                            已发布 <?= (int) $row['published_count'] ?> / 共 <?= (int) $row['chapter_count'] ?> 章 ·
                            <?= number_format((int) $row['word_count']) ?> 字 ·
                            收藏 <?= (int) $row['favorite_count'] ?> ·
                            评分 <?= number_format((float) $row['rating'], 1) ?>
                        </div>
                        <div style="font-size:12px;color:var(--ink-soft);margin-top:8px;line-height:1.8;overflow-wrap:break-word;word-break:break-word;"><?= e(excerpt((string) $row['summary'], 90)) ?></div>
                        <?php if ((string) $row['status'] === 'rejected' && !empty($row['review_note'])): ?>
                            <div class="flash flash-error" style="margin-top:10px;font-size:11.5px;padding:8px 12px;">
                                <i class="fa-solid fa-circle-exclamation"></i>
                                <span>驳回原因：<?= e($row['review_note']) ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:14px;padding-top:12px;border-top:1px dashed var(--line);">
                    <a class="btn btn-soft btn-sm" href="<?= url('/author/work/' . (int) $row['id'] . '/edit') ?>"><i class="fa-solid fa-pen"></i> 编辑信息</a>
                    <a class="btn btn-ghost btn-sm" href="<?= url('/author/work/' . (int) $row['id'] . '/volumes') ?>"><i class="fa-solid fa-layer-group"></i> 分卷</a>
                    <a class="btn btn-ghost btn-sm" href="<?= url('/author/work/' . (int) $row['id'] . '/chapters') ?>"><i class="fa-solid fa-file-lines"></i> 章节</a>
                    <?php if (in_array((string) $row['status'], ['draft', 'rejected'], true)): ?>
                        <form method="post" action="<?= url('/author/work/' . (int) $row['id'] . '/submit') ?>" data-confirm="提交后作品将进入审核队列，审核期间不可再编辑简介等基础信息。确定提交？">
                            <?= csrf_field() ?>
                            <button class="btn btn-primary btn-sm" type="submit"><i class="fa-solid fa-paper-plane"></i> 提交审核</button>
                        </form>
                    <?php endif; ?>
                    <form method="post" action="<?= url('/author/work/' . (int) $row['id'] . '/delete') ?>" data-confirm="确定删除《<?= e($row['title']) ?>》？作品将移入回收站。" data-danger>
                        <?= csrf_field() ?>
                        <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash-can"></i> 删除</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
