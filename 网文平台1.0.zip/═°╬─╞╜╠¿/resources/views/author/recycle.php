<?php
/** 作家回收站 */
$typeLabels = [
    'book' => '作品',
    'volume' => '分卷',
    'chapter' => '章节',
];
?>
<div class="account-head">
    <h1>回收站</h1>
    <p>删除的作品、分卷与章节会先在回收站保留 30 天，期间可恢复；也可以随时彻底删除，彻底删除后会从数据库移除且无法找回。章节恢复后会按原顺序插回，作品内章节编号始终连续。</p>
</div>

<?php if ($items === []): ?>
    <div class="empty"><i class="fa-solid fa-trash-can"></i><p>回收站是空的，删除的内容会出现在这里。</p></div>
<?php else: ?>
    <div class="simple-list">
        <?php foreach ($items as $item): ?>
            <?php
            $deadline = !empty($item['restore_deadline']) ? strtotime((string) $item['restore_deadline']) : null;
            $expired = $deadline !== null && $deadline < time();
            $type = (string) $item['target_type'];
            ?>
            <div class="form-card" style="padding:16px 20px;margin-bottom:0;">
                <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;">
                    <i class="fa-solid <?= $type === 'book' ? 'fa-book-open' : ($type === 'volume' ? 'fa-layer-group' : 'fa-file-lines') ?>" style="color:var(--rose);"></i>
                    <div style="flex:1;min-width:200px;">
                        <div style="font-family:var(--serif);font-size:15px;">
                            <?= e($item['title']) ?>
                            <span class="badge badge-gray"><?= e($typeLabels[$type] ?? $type) ?></span>
                            <?php if ($expired): ?><span class="badge badge-red">已过期</span><?php endif; ?>
                        </div>
                        <div style="font-size:11.5px;color:var(--ink-faint);margin-top:4px;">
                            删除于 <?= e(format_date((string) $item['deleted_at'], 'Y-m-d H:i')) ?>
                            · 原因：<?= e($item['reason'] ?? '未填写') ?>
                            <?php if ($deadline !== null): ?> · 恢复截止 <?= e(date('Y-m-d H:i', $deadline)) ?><?php endif; ?>
                        </div>
                    </div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;">
                        <form method="post" action="<?= url('/author/recycle/' . (int) $item['id'] . '/restore') ?>" data-confirm="恢复后内容将回到草稿 / 公开状态，确定恢复？">
                            <?= csrf_field() ?>
                            <button class="btn btn-soft btn-sm" type="submit" <?= $expired ? 'disabled' : '' ?>><i class="fa-solid fa-rotate-left"></i> 恢复</button>
                        </form>
                        <form method="post" action="<?= url('/author/recycle/' . (int) $item['id'] . '/purge') ?>" data-confirm="彻底删除后不可恢复，确定继续？" data-danger>
                            <?= csrf_field() ?>
                            <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash-can"></i> 彻底删除</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
