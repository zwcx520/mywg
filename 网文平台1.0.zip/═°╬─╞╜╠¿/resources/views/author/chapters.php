<?php /** 章节列表 */ ?>
<div class="account-head">
    <h1>章节管理</h1>
    <p>《<?= e($book['title']) ?>》· 共 <?= count($chapters) ?> 章。正文与作者草稿分离保存，提交审核后该版本锁定编辑。</p>
</div>

<div class="form-card" style="padding:16px 20px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
    <span style="font-size:12px;color:var(--ink-faint);">作品状态：<span class="badge <?= book_is_public((string) $book['status']) ? 'badge-green' : 'badge-gold' ?>"><?= e(status_label((string) $book['status'])) ?></span>　章节须经审核通过后才会对读者可见。</span>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a class="more-link" href="<?= url('/author/work/' . (int) $book['id'] . '/volumes') ?>"><i class="fa-solid fa-layer-group"></i> 分卷管理</a>
        <a class="more-link" href="<?= url('/author/works') ?>"><i class="fa-solid fa-arrow-left"></i> 返回作品</a>
    </div>
</div>

<form class="form-card" method="post" action="<?= url('/author/work/' . (int) $book['id'] . '/chapters') ?>" data-lock-submit>
    <?= csrf_field() ?>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div class="field" style="flex:2;min-width:220px;">
            <label for="chapter_title">新章节标题</label>
            <input class="input" id="chapter_title" type="text" name="title" maxlength="120" placeholder="如：第一章 · 灯下初见" required>
        </div>
        <div class="field" style="flex:1;min-width:160px;">
            <label for="volume_id">所属分卷</label>
            <select class="select" id="volume_id" name="volume_id">
                <option value="0">自动选择 / 新建第一卷</option>
                <?php foreach ($volumes as $volume): ?>
                    <option value="<?= (int) $volume['id'] ?>"><?= e($volume['title']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-plus"></i> 创建章节</button>
    </div>
</form>

<?php if ($chapters === []): ?>
    <div class="empty">
        <i class="fa-solid fa-file-lines"></i>
        <p>还没有章节。创建第一章，故事从这里开始。</p>
    </div>
<?php else: ?>
    <div class="form-card" style="padding:0;overflow:hidden;">
        <div class="table-wrap" style="border:0;">
            <table class="table">
                <thead>
                <tr>
                    <th style="width:64px;">章序</th>
                    <th>标题</th>
                    <th>分卷</th>
                    <th>状态</th>
                    <th>字数</th>
                    <th>阅读</th>
                    <th>更新时间</th>
                    <th style="width:150px;">操作</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($chapters as $chapter): ?>
                    <tr>
                        <td style="color:var(--ink-faint);">第 <?= (int) $chapter['chapter_no'] ?> 章</td>
                        <td>
                            <a class="title-cell" href="<?= url('/author/chapter/' . (int) $chapter['id'] . '/edit') ?>"><?= e($chapter['title']) ?></a>
                            <?php if ((int) $chapter['review_waiting'] > 0): ?>
                                <span class="badge badge-gold" style="margin-left:6px;"><i class="fa-solid fa-hourglass-half"></i> 审核中</span>
                            <?php endif; ?>
                            <?php if ((string) $chapter['status'] === 'scheduled' && !empty($chapter['scheduled_at'])): ?>
                                <div class="sub">定时发布：<?= e(format_date((string) $chapter['scheduled_at'], 'Y-m-d H:i')) ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="sub"><?= e($chapter['volume_title'] ?? '未分卷') ?></td>
                        <td><span class="badge <?= status_badge_class((string) $chapter['status']) ?>"><?= e(status_label((string) $chapter['status'])) ?></span></td>
                        <td><?= number_format((int) $chapter['word_count']) ?></td>
                        <td><?= number_format((int) $chapter['read_count']) ?></td>
                        <td class="sub"><?= e(format_date((string) $chapter['updated_at'], 'm-d H:i')) ?></td>
                        <td>
                            <div class="actions">
                                <a class="btn btn-soft btn-sm" href="<?= url('/author/chapter/' . (int) $chapter['id'] . '/edit') ?>"><i class="fa-solid fa-pen"></i> 编辑</a>
                                <?php if ((string) $chapter['status'] !== 'recycle'): ?>
                                    <form method="post" action="<?= url('/author/chapter/' . (int) $chapter['id'] . '/delete') ?>" data-confirm="确定删除《<?= e($chapter['title']) ?>》？章节将移入回收站。" data-danger>
                                        <?= csrf_field() ?>
                                        <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash-can"></i></button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
