<?php /** 分卷管理 */ ?>
<div class="account-head">
    <h1>分卷管理</h1>
    <p>《<?= e($book['title']) ?>》· 分卷只影响目录结构，不影响章节审核状态。</p>
</div>

<div class="form-card" style="padding:16px 20px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
    <a class="more-link" href="<?= url('/author/work/' . (int) $book['id'] . '/chapters') ?>"><i class="fa-solid fa-file-lines"></i> 去章节列表</a>
    <a class="more-link" href="<?= url('/author/works') ?>"><i class="fa-solid fa-arrow-left"></i> 返回作品</a>
</div>

<form class="form-card" method="post" action="<?= url('/author/work/' . (int) $book['id'] . '/volumes') ?>">
    <?= csrf_field() ?>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div class="field" style="flex:1;min-width:220px;">
            <label for="new_volume">新建分卷名称</label>
            <input class="input" id="new_volume" type="text" name="title" maxlength="80" placeholder="如：第一卷 · 初遇" required>
        </div>
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-plus"></i> 创建分卷</button>
    </div>
</form>

<?php if ($volumes === []): ?>
    <div class="empty"><i class="fa-solid fa-layer-group"></i><p>还没有分卷，先创建一卷吧。</p></div>
<?php else: ?>
    <div class="simple-list">
        <?php foreach ($volumes as $volume): ?>
            <div class="form-card" style="padding:16px 20px;margin-bottom:0;">
                <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
                    <div style="flex:1;min-width:200px;">
                        <div style="font-family:var(--serif);font-size:15px;"><?= e($volume['title']) ?> <span class="badge <?= $volume['status'] === 'hidden' ? 'badge-gray' : 'badge-green' ?>"><?= $volume['status'] === 'hidden' ? '隐藏' : '公开' ?></span></div>
                        <div style="font-size:11.5px;color:var(--ink-faint);margin-top:4px;"><?= (int) $volume['chapter_count'] ?> 章 · 排序 <?= (int) $volume['sort'] ?></div>
                    </div>

                    <form method="post" action="<?= url('/author/volume/' . (int) $volume['id'] . '/update') ?>" style="display:flex;gap:7px;align-items:center;flex-wrap:wrap;">
                        <?= csrf_field() ?>
                        <input class="input" type="text" name="title" value="<?= e($volume['title']) ?>" maxlength="80" style="width:150px;">
                        <select class="select" name="status">
                            <option value="public" <?= $volume['status'] === 'public' ? 'selected' : '' ?>>公开</option>
                            <option value="hidden" <?= $volume['status'] === 'hidden' ? 'selected' : '' ?>>隐藏</option>
                        </select>
                        <button class="btn btn-soft btn-sm" type="submit">保存</button>
                    </form>

                    <form method="post" action="<?= url('/author/volume/' . (int) $volume['id'] . '/delete') ?>" data-confirm="确定删除该分卷？分卷下仍有章节时无法删除。" data-danger>
                        <?= csrf_field() ?>
                        <button class="btn btn-danger btn-sm" type="submit" <?= (int) $volume['chapter_count'] > 0 ? 'disabled' : '' ?>><i class="fa-solid fa-trash-can"></i></button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
