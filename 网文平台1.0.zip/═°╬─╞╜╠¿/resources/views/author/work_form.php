<?php
/** 作品创建 / 编辑 */
$isEdit = $book !== null;
$formAction = $isEdit ? url('/author/work/' . (int) $book['id'] . '/edit') : url('/author/work/create');
?>
<div class="account-head">
    <h1><?= $isEdit ? '编辑作品信息' : '新建作品' ?></h1>
    <p><?= $isEdit ? '作品基础信息修改后需重新提交审核（已发布作品建议仅修正明显错误）。' : '先写下书名与简介，再创建分卷与章节，最后提交审核。' ?></p>
</div>

<form class="form-card" method="post" action="<?= $formAction ?>" enctype="multipart/form-data" data-lock-submit>
    <?= csrf_field() ?>

    <div class="form-grid">
        <div class="field">
            <label for="title">书名</label>
            <input class="input" id="title" type="text" name="title" maxlength="60" value="<?= e($book['title'] ?? '') ?>" placeholder="2-60 个字符" required>
        </div>
        <div class="field">
            <label for="category_id">分类</label>
            <select class="select" id="category_id" name="category_id" required>
                <option value="">请选择分类</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= (int) $category['id'] ?>" <?= (int) ($book['category_id'] ?? 0) === (int) $category['id'] ? 'selected' : '' ?>>
                        <?= e($category['name']) ?><?= (int) ($category['parent_id'] ?? 0) > 0 ? ' · 子分类' : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field full">
            <label for="summary">作品简介</label>
            <textarea class="textarea" id="summary" name="summary" maxlength="1000" style="min-height:130px;" placeholder="至少 20 个字符，说明故事类型、主线与阅读感受。" required><?= e($book['summary'] ?? '') ?></textarea>
            <span class="hint">简介会在作品页公开展示，请勿填写联系方式或外部引流信息。</span>
        </div>
        <div class="field">
            <label for="cover_file">作品封面（可选）</label>
            <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap;">
                <span id="cover-preview" data-gradient="<?= e(cover_gradient((int) ($book['id'] ?? 1))) ?>" style="width:96px;height:128px;border-radius:12px;overflow:hidden;flex-shrink:0;display:grid;place-items:center;color:#fff;font-family:var(--serif);font-size:13px;text-align:center;<?= empty($book['cover']) ? 'background:' . e(cover_gradient((int) ($book['id'] ?? 1))) . ';' : '' ?>">
                    <?php if (!empty($book['cover'])): ?>
                        <img src="<?= e(upload_url((string) $book['cover'])) ?>" alt="" style="width:100%;height:100%;object-fit:cover;">
                    <?php else: ?>
                        暂无封面
                    <?php endif; ?>
                </span>
                <div style="flex:1;min-width:200px;">
                    <input class="input" id="cover_file" type="file" name="cover_file" accept="image/jpeg,image/png,image/webp,image/gif">
                    <span class="hint">支持 jpg / png / webp / gif，不超过 20MB，建议比例 3:4。选择后将立即预览。</span>
                    <?php if (!empty($book['cover'])): ?>
                        <label class="check-pill" style="margin-top:8px;">
                            <input type="checkbox" name="remove_cover" value="1"> 移除当前封面
                        </label>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="field">
            <label for="copyright_note">版权说明（可选）</label>
            <input class="input" id="copyright_note" type="text" name="copyright_note" maxlength="255" value="<?= e($book['copyright_note'] ?? '') ?>" placeholder="如：本人原创，保留所有权利">
        </div>
        <div class="field full">
            <label>作品标签</label>
            <div class="checks">
                <?php foreach ($tags as $tag): ?>
                    <label class="check-pill">
                        <input type="checkbox" name="tags[]" value="<?= (int) $tag['id'] ?>" <?= in_array((int) $tag['id'], $selectedTags, true) ? 'checked' : '' ?>>
                        <?= e($tag['name']) ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <span class="hint">最多选择 6 个标签，便于读者检索。</span>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> <?= $isEdit ? '保存修改' : '创建作品' ?></button>
        <a class="btn btn-ghost" href="<?= url('/author/works') ?>">返回作品列表</a>
    </div>
</form>

<?php if ($isEdit): ?>
    <div class="form-card">
        <div class="panel-head">
            <h2 style="font-size:16px;">分卷与章节</h2>
            <a class="btn btn-soft btn-sm" href="<?= url('/author/work/' . (int) $book['id'] . '/volumes') ?>">管理分卷</a>
        </div>
        <?php if ($volumes === []): ?>
            <p style="font-size:12px;color:var(--ink-faint);">还没有分卷。请先创建分卷，再添加章节。</p>
        <?php else: ?>
            <div class="simple-list">
                <?php foreach ($volumes as $volume): ?>
                    <div class="simple-item">
                        <i class="fa-solid fa-layer-group" style="color:var(--rose);"></i>
                        <div class="grow">
                            <div class="title"><?= e($volume['title']) ?></div>
                            <div class="sub"><?= (int) $volume['chapter_count'] ?> 章 · <?= $volume['status'] === 'hidden' ? '隐藏' : '公开' ?></div>
                        </div>
                        <a class="btn btn-ghost btn-sm" href="<?= url('/author/work/' . (int) $book['id'] . '/chapters') ?>">章节列表</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="form-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
        <p style="font-size:11.5px;color:#8a6438;line-height:2;">
            <i class="fa-solid fa-circle-info"></i>
            作品发布流程：保存信息 → 提交审核 → 审核通过 → 创建分卷与章节 → 章节提交审核 → 审核通过后正式发布。
            发布后的修改会生成新版本，不会覆盖读者正在阅读的内容。
        </p>
    </div>
<?php endif; ?>
