<?php /** 作家认证 */ ?>
<div class="account-head">
    <h1>作家认证</h1>
    <p>完成实名认证后即可创建作品。平台执行先审后发，认证信息仅用于审核与版权保护。</p>
</div>

<?php if ($application !== null && (string) $application['status'] === 'pending'): ?>
    <div class="form-card" style="text-align:center;padding:36px 26px;">
        <i class="fa-solid fa-hourglass-half" style="font-size:34px;color:var(--gold);"></i>
        <h2 style="font-size:19px;margin-top:14px;">认证申请审核中</h2>
        <p style="font-size:12.5px;color:var(--ink-faint);margin-top:8px;line-height:2;">
            笔名：<?= e($application['pen_name']) ?><br>
            提交时间：<?= format_date($application['created_at'], 'Y-m-d H:i') ?><br>
            审核结果会通过站内通知告知。
        </p>
    </div>
<?php else: ?>
    <?php if ($application !== null && (string) $application['status'] === 'rejected'): ?>
        <div class="flash flash-error" style="margin-bottom:18px;display:block;">
            <div><i class="fa-solid fa-circle-exclamation"></i> 上次认证未通过<?php if (!empty($application['remark'])): ?>：<?= e($application['remark']) ?><?php endif; ?></div>
            <div style="margin-top:4px;font-size:11.5px;">你可以修改信息后重新提交。</div>
        </div>
    <?php endif; ?>

    <form class="form-card" method="post" action="<?= url('/author/apply') ?>" data-lock-submit>
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="field">
                <label for="pen_name">笔名</label>
                <input class="input" id="pen_name" type="text" name="pen_name" maxlength="20" value="<?= e($application['pen_name'] ?? '') ?>" placeholder="2-20 个字符，仅支持中文、字母与数字" required>
            </div>
            <div class="field">
                <label for="phone">联系电话</label>
                <input class="input" id="phone" type="text" name="phone" maxlength="20" value="<?= e($application['phone'] ?? '') ?>" placeholder="用于审核联系" required>
            </div>
            <div class="field">
                <label for="real_name">真实姓名</label>
                <input class="input" id="real_name" type="text" name="real_name" maxlength="40" value="<?= e($application['real_name'] ?? '') ?>" required>
            </div>
            <div class="field">
                <label for="id_no">身份证号</label>
                <input class="input" id="id_no" type="text" name="id_no" maxlength="18" value="<?= e($application['id_no'] ?? '') ?>" placeholder="仅用于实名审。" required>
            </div>
            <div class="field full">
                <label for="intro">创作简介</label>
                <textarea class="textarea" id="intro" name="intro" maxlength="500" placeholder="介绍你的创作方向与代表想法。"><?= e($application['intro'] ?? '') ?></textarea>
            </div>
            <div class="field full">
                <label for="material">其他证明材料（可选）</label>
                <input class="input" id="material" type="text" name="material" maxlength="255" placeholder="可填写作品链接或说明，便于审核">
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit"><i class="fa-solid fa-id-card"></i> 提交认证申请</button>
        </div>
        <p style="font-size:11px;color:var(--ink-faint);margin-top:12px;line-height:1.9;">
            <i class="fa-solid fa-shield-halved" style="color:var(--rose);"></i>
            认证资料不会出现在任何公开页面；后台仅站长可查看完整信息，其他管理人员一律脱敏展示。
        </p>
    </form>
<?php endif; ?>
