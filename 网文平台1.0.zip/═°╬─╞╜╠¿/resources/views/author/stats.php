<?php /** 作家数据统计 */ ?>
<div class="account-head">
    <h1>数据统计</h1>
    <p>数据每日汇总，阅读数来自章节真实打开次数。第一版不包含任何付费、订阅与打赏数据。</p>
</div>

<div class="stat-grid">
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-eye"></i> 作品总点击</div>
        <div class="val"><?= number_format((int) $totals['views']) ?></div>
        <div class="hint">章节阅读 <?= number_format((int) $totals['reads']) ?></div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-bookmark"></i> 收藏总数</div>
        <div class="val"><?= number_format((int) $totals['favorites']) ?></div>
        <div class="hint">读者加入书架次数</div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-comment-dots"></i> 有效评论</div>
        <div class="val"><?= number_format((int) $totals['comments']) ?></div>
        <div class="hint">仅统计审核通过的评论</div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-feather-pointed"></i> 累计字数</div>
        <div class="val"><?= number_format((int) $totals['words']) ?></div>
        <div class="hint"><?= count($books) ?> 部作品</div>
    </div>
</div>

<div class="form-card">
    <div class="panel-head">
        <h2 style="font-size:16px;">作品数据明细</h2>
        <span style="font-size:11px;color:var(--ink-faint);">按最近更新排序</span>
    </div>
    <?php if ($books === []): ?>
        <div class="empty"><i class="fa-solid fa-chart-line"></i><p>还没有作品数据。发布第一章后即可查看阅读趋势。</p></div>
    <?php else: ?>
        <div class="table-wrap" style="border:0;">
            <table class="table">
                <thead>
                <tr>
                    <th>作品</th>
                    <th>状态</th>
                    <th>已发布章节</th>
                    <th>字数</th>
                    <th>点击</th>
                    <th>章节阅读</th>
                    <th>收藏</th>
                    <th>评论</th>
                    <th>评分</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($books as $book): ?>
                    <tr>
                        <td><a class="title-cell" href="<?= url('/author/work/' . (int) $book['id'] . '/chapters') ?>"><?= e($book['title']) ?></a></td>
                        <td><span class="badge <?= status_badge_class((string) $book['status']) ?>"><?= e(status_label((string) $book['status'])) ?></span></td>
                        <td><?= (int) $book['chapter_count'] ?></td>
                        <td><?= number_format((int) $book['word_count']) ?></td>
                        <td><?= number_format((int) $book['view_count']) ?></td>
                        <td><?= number_format((int) $book['chapter_reads']) ?></td>
                        <td><?= number_format((int) $book['favorite_count']) ?></td>
                        <td><?= number_format((int) $book['comment_count']) ?></td>
                        <td><?= number_format((float) $book['rating'], 1) ?><span style="color:var(--ink-faint);font-size:11px;"> (<?= (int) $book['rating_count'] ?>)</span></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<div class="form-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.7);">
    <p style="font-size:11.5px;color:#8a6438;line-height:2;">
        <i class="fa-solid fa-circle-info"></i>
        数据说明：点击为作品详情页访问次数；章节阅读为章节正文打开次数；评论仅统计审核通过状态。
        第一版商业化功能全部关闭，不提供订阅、打赏、月票与作者结算数据。
    </p>
</div>
