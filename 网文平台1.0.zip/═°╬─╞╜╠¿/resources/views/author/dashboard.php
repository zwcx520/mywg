<?php /** 作家创作台 */ ?>
<div class="account-head">
    <h1 style="display:flex;align-items:center;gap:10px;"><?= avatar_thumb($currentUser['avatar'] ?? ($author['avatar'] ?? null), (string) ($author['pen_name'] ?? '作者'), 'sm') ?>创作台 · <?= e($author['pen_name']) ?></h1>
    <p><?= e($author['intro'] ?? '愿你的故事被温柔地读完。') ?></p>
</div>

<div class="stat-grid">
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-book-open"></i>作品数</div>
        <div class="val"><?= (int) $stats['works'] ?></div>
        <div class="hint"><a href="<?= url('/author/works') ?>" style="color:inherit;">管理作品 →</a></div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-file-lines"></i>已发布章节</div>
        <div class="val"><?= (int) $stats['published'] ?></div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-hourglass-half"></i>审核中章节</div>
        <div class="val"><?= (int) $stats['pending'] ?></div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-pen-nib"></i>累计字数</div>
        <div class="val"><?= number_format((int) $stats['words']) ?></div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1.3fr .7fr;gap:20px;" class="author-two">
    <section class="form-card" style="margin-bottom:0;">
        <div class="panel-head">
            <h2 style="font-size:17px;">最近作品</h2>
            <a class="more-link" href="<?= url('/author/works') ?>">全部作品</a>
        </div>
        <?php if ($works === []): ?>
            <div class="empty" style="padding:26px;">
                <i class="fa-solid fa-feather-pointed"></i>
                <p>还没有作品，写下第一本书吧。</p>
                <a class="btn btn-primary btn-sm" style="margin-top:12px;" href="<?= url('/author/work/create') ?>">新建作品</a>
            </div>
        <?php else: ?>
            <div class="simple-list">
                <?php foreach ($works as $work): ?>
                    <div class="simple-item">
                        <div class="grow">
                            <a class="title" style="font-family:var(--serif);" href="<?= url('/author/work/' . (int) $work['id'] . '/chapters') ?>"><?= e($work['title']) ?></a>
                            <div class="sub"><?= (int) $work['chapter_count'] ?> 章 · <?= number_format((int) $work['word_count']) ?> 字 · <?= time_ago($work['updated_at']) ?></div>
                        </div>
                        <span class="badge <?= $work['status'] === 'serializing' ? 'badge-green' : ($work['status'] === 'draft' ? 'badge-gray' : 'badge-gold') ?>"><?= e(status_label((string) $work['status'])) ?></span>
                        <a class="btn btn-soft btn-sm" href="<?= url('/author/work/' . (int) $work['id'] . '/chapters') ?>">写章节</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <section class="form-card" style="margin-bottom:0;">
        <div class="panel-head"><h2 style="font-size:17px;">消息</h2><a class="more-link" href="<?= url('/user/notices') ?>">全部</a></div>
        <?php if ($notices === []): ?>
            <div class="empty" style="padding:22px;"><p>暂无新通知。</p></div>
        <?php else: ?>
            <div class="simple-list">
                <?php foreach ($notices as $notice): ?>
                    <div class="simple-item" style="align-items:flex-start;padding:10px 12px;">
                        <div class="grow">
                            <div class="title" style="font-size:12.5px;"><?= e($notice['title']) ?></div>
                            <div class="sub"><?= e(excerpt((string) $notice['content'], 42)) ?></div>
                        </div>
                        <?php if (empty($notice['is_read'])): ?><span class="badge">未读</span><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php if ($announcements !== []): ?>
<section class="form-card" style="margin-top:20px;">
    <div class="panel-head"><h2 style="font-size:17px;">作者公告</h2><a class="more-link" href="<?= url('/announcements') ?>">更多</a></div>
    <div class="notice-grid">
        <?php foreach ($announcements as $item): ?>
            <a class="notice-card" href="<?= url('/announcement/' . (int) $item['id']) ?>" style="padding:16px 18px;">
                <span class="date"><?= format_date($item['published_at'] ?? $item['created_at']) ?></span>
                <h3 style="font-size:14px;"><?= e($item['title']) ?></h3>
                <p style="font-size:11.5px;"><?= e(excerpt((string) $item['content'], 70)) ?></p>
            </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<style>@media (max-width:900px){.author-two{grid-template-columns:1fr !important;}}</style>
