<?php
/** 章节编辑 */
$chapterId = (int) $chapter['id'];
$scheduleValue = !empty($chapter['scheduled_at']) ? date('Y-m-d\TH:i', strtotime((string) $chapter['scheduled_at'])) : '';
$currentVolume = (int) $chapter['volume_id'];
?>
<div class="account-head">
    <h1>章节写作</h1>
    <p>《<?= e($chapter['book_title']) ?>》· 第 <?= (int) $chapter['chapter_no'] ?> 章　<span class="badge <?= status_badge_class((string) $chapter['status']) ?>"><?= e(status_label((string) $chapter['status'])) ?></span></p>
</div>

<?php if (!$editable): ?>
    <div class="form-card" style="border-color:#ecd9bd;background:rgba(253,247,238,.75);margin-bottom:16px;">
        <p style="font-size:12px;color:#8a6438;line-height:2;">
            <i class="fa-solid fa-lock"></i>
            <?php if ($waiting): ?>
                当前版本已提交审核，审核期间正文与标题锁定编辑。审核完成后可继续修改；
            <?php else: ?>
                当前章节状态为「<?= e(status_label((string) $chapter['status'])) ?>」，暂不可编辑；
            <?php endif; ?>
            可在下方查看审核版本与历史版本。
        </p>
    </div>
<?php endif; ?>

<div class="form-card" style="padding:16px 20px;margin-bottom:16px;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;">
    <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:11.5px;color:var(--ink-faint);">
        <span><i class="fa-solid fa-file-word"></i> 字数 <?= number_format((int) $chapter['word_count']) ?></span>
        <span><i class="fa-solid fa-eye"></i> 阅读 <?= number_format((int) $chapter['read_count']) ?></span>
        <span><i class="fa-solid fa-clock"></i> 更新 <?= e(format_date((string) $chapter['updated_at'], 'Y-m-d H:i')) ?></span>
        <?php if (!empty($chapter['published_at'])): ?>
            <span><i class="fa-solid fa-circle-check"></i> 发布 <?= e(format_date((string) $chapter['published_at'], 'Y-m-d H:i')) ?></span>
        <?php endif; ?>
    </div>
    <a class="more-link" href="<?= url('/author/work/' . (int) $chapter['book_id'] . '/chapters') ?>"><i class="fa-solid fa-arrow-left"></i> 返回章节列表</a>
</div>

<?php if ((string) $chapter['status'] === 'rejected' && !empty($chapter['review_note'])): ?>
    <div class="flash flash-error" style="margin-bottom:16px;">
        <i class="fa-solid fa-circle-exclamation"></i>
        <span>审核驳回：<?= e($chapter['review_note']) ?></span>
    </div>
<?php endif; ?>

<?php if ($latestReview && (string) $latestReview['action'] === 'reject' && !empty($latestReview['reason'])): ?>
    <div class="flash flash-error" style="margin-bottom:16px;">
        <i class="fa-solid fa-circle-exclamation"></i>
        <span>最近审核意见：<?= e($latestReview['reason']) ?></span>
    </div>
<?php endif; ?>

<?php if ($editable): ?>
    <form class="form-card" method="post" action="<?= url('/author/chapter/' . $chapterId . '/save') ?>"
          data-autosave-url="<?= url('/author/chapter/' . $chapterId . '/autosave') ?>" data-lock-submit>
        <?= csrf_field() ?>
        <input type="hidden" name="editor_token" value="<?= e($editorToken) ?>">
        <input type="hidden" name="is_paid" value="0">

        <div class="form-grid">
            <div class="field">
                <label for="title">章节标题</label>
                <input class="input" id="title" type="text" name="title" maxlength="120" value="<?= e($chapter['title']) ?>" required>
            </div>
            <div class="field">
                <label for="volume_id">所属分卷</label>
                <select class="select" id="volume_id" name="volume_id" required>
                    <?php foreach ($volumes as $volume): ?>
                        <option value="<?= (int) $volume['id'] ?>" <?= (int) $volume['id'] === $currentVolume ? 'selected' : '' ?>><?= e($volume['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="field full" style="margin-top:14px;">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
                <label for="content">章节正文</label>
                <span style="font-size:11px;color:var(--ink-faint);">
                    <span id="content-count">0</span> 字符 · <span data-autosave-status>自动保存已开启</span>
                </span>
            </div>
            <textarea class="textarea" id="content" name="content" maxlength="300000" data-counter="content-count"
                      style="min-height:420px;font-family:var(--serif);font-size:15px;line-height:2;"
                      placeholder="在此书写正文。建议每段空一行，段落之间不必缩进。"><?= e($content) ?></textarea>
            <span class="hint">正文与作者草稿分离保存；提交审核后生成独立的审核版本，读者端只会在审核通过后看到发布版。</span>
        </div>

        <div class="form-grid" style="margin-top:16px;">
            <div class="field full">
                <label class="check-pill" style="justify-self:start;">
                    <input type="checkbox" data-schedule-toggle <?= $scheduleValue !== '' ? 'checked' : '' ?>>
                    定时发布
                </label>
                <div data-schedule-box style="margin-top:8px;">
                    <input class="input" type="datetime-local" name="scheduled_at" value="<?= e($scheduleValue) ?>">
                    <span class="hint">审核通过后将在此时间自动发布；任务每分钟由后台定时器执行一次，重复执行不会重复发布。</span>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-soft" type="submit"><i class="fa-solid fa-floppy-disk"></i> 保存草稿</button>
            <button class="btn btn-primary" type="submit" formaction="<?= url('/author/chapter/' . $chapterId . '/submit') ?>"
                    data-confirm="提交后将进入审核队列，审核期间该版本锁定编辑。确定提交？">
                <i class="fa-solid fa-paper-plane"></i> 提交审核
            </button>
        </div>
    </form>
<?php else: ?>
    <div class="form-card">
        <div class="panel-head">
            <h2 style="font-size:16px;">当前正文（锁定）</h2>
            <span class="badge badge-gold">审核中 / 已锁定</span>
        </div>
        <div class="review-content" style="max-height:520px;"><?= e($content) ?></div>
        <p style="font-size:11.5px;color:var(--ink-faint);margin-top:10px;">为了保持版本可追溯，审核期间不允许修改正文。审核结束后可再次编辑并生成新版本。</p>
    </div>
<?php endif; ?>

<div class="form-card">
    <div class="panel-head">
        <h2 style="font-size:16px;">版本记录</h2>
        <span style="font-size:11px;color:var(--ink-faint);">最近 10 条</span>
    </div>
    <?php if ($versions === []): ?>
        <p style="font-size:12px;color:var(--ink-faint);">还没有提交版本。保存草稿不会生成正式版本，提交审核后才会写入版本流。</p>
    <?php else: ?>
        <div class="version-list">
            <?php foreach ($versions as $version): ?>
                <div class="version-item" style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;border-radius:10px;background:rgba(251,247,242,.8);margin-bottom:6px;font-size:11.5px;">
                    <span>
                        <strong style="font-family:var(--serif);">v<?= (int) $version['version_no'] ?></strong>
                        <span class="badge <?= $version['kind'] === 'publish' ? 'badge-green' : 'badge-gold' ?>" style="margin-left:6px;"><?= $version['kind'] === 'publish' ? '发布版' : '审核版' ?></span>
                        <span style="color:var(--ink-faint);margin-left:6px;"><?= number_format((int) $version['word_count']) ?> 字 · <?= e(format_date((string) $version['created_at'], 'Y-m-d H:i')) ?></span>
                    </span>
                    <?php if ($editable): ?>
                        <form method="post" action="<?= url('/author/chapter/' . $chapterId . '/restore') ?>" data-confirm="将该版本内容恢复到编辑草稿？当前未提交的修改会被覆盖。">
                            <?= csrf_field() ?>
                            <input type="hidden" name="version_no" value="<?= (int) $version['version_no'] ?>">
                            <button class="btn btn-ghost btn-sm" type="submit"><i class="fa-solid fa-rotate-left"></i> 恢复</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
