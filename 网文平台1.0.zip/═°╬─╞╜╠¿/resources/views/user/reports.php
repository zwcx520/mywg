<?php /** 我的举报 */ ?>
<div class="account-head">
    <h1>我的举报</h1>
    <p>举报人信息不会展示给被举报对象。每次处置都会留下可追溯记录。</p>
</div>

<?php if ($rows === []): ?>
    <div class="empty"><i class="fa-solid fa-flag"></i><p>还没有提交过举报。</p></div>
<?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>编号</th>
                    <th>举报对象</th>
                    <th>分类</th>
                    <th>状态</th>
                    <th>提交时间</th>
                    <th>处理结果</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td>JB<?= str_pad((string) $row['id'], 6, '0', STR_PAD_LEFT) ?></td>
                        <td class="title-cell"><?= e(status_label((string) $row['target_type'])) ?> #<?= (int) $row['target_id'] ?></td>
                        <td><?= e(report_category_label((string) $row['category'])) ?></td>
                        <td><span class="badge <?= $row['status'] === 'handled' ? 'badge-green' : ($row['status'] === 'rejected' ? 'badge-gray' : 'badge-gold') ?>"><?= e(report_status_label((string) $row['status'])) ?></span></td>
                        <td style="font-size:11px;color:var(--ink-faint);"><?= format_date($row['created_at'], 'Y-m-d H:i') ?></td>
                        <td style="font-size:11.5px;color:var(--ink-soft);max-width:240px;"><?= e(excerpt((string) ($row['result'] ?? '等待处理'), 60)) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
