<?php /** 消息通知 */ ?>
<div class="account-head">
    <h1>消息通知</h1>
    <p>审核结果、账号状态与站内提醒都会出现在这里。</p>
</div>

<div class="form-card" style="padding:16px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
    <span style="font-size:12px;color:var(--ink-faint);">共 <?= count($rows) ?> 条通知</span>
    <form method="post" action="<?= url('/user/notices/read') ?>">
        <?= csrf_field() ?>
        <button class="btn btn-soft btn-sm" type="submit"><i class="fa-solid fa-check-double"></i> 全部标记为已读</button>
    </form>
</div>

<?php if ($rows === []): ?>
    <div class="empty"><i class="fa-regular fa-bell"></i><p>暂无通知。</p></div>
<?php else: ?>
    <div class="simple-list">
        <?php foreach ($rows as $row): ?>
            <div class="simple-item" style="align-items:flex-start;<?= empty($row['is_read']) ? 'border-color:rgba(192,132,151,.4);' : '' ?>">
                <i class="fa-solid <?= empty($row['is_read']) ? 'fa-envelope' : 'fa-envelope-open' ?>" style="color:<?= empty($row['is_read']) ? 'var(--rose-deep)' : 'var(--ink-faint)' ?>;margin-top:4px;"></i>
                <div class="grow">
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                        <span style="font-size:13px;"><?= e($row['title']) ?></span>
                        <?php if (empty($row['is_read'])): ?>
                            <span class="badge">未读</span>
                        <?php endif; ?>
                    </div>
                    <div style="font-size:12px;color:var(--ink-soft);line-height:1.9;margin-top:3px;"><?= nl2br(e($row['content'])) ?></div>
                    <div class="sub" style="margin-top:4px;"><?= format_date($row['created_at'], 'Y-m-d H:i') ?></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
