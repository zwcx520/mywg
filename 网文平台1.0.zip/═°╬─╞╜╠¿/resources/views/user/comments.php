<?php /** 我的评论 */ ?>
<div class="account-head">
    <h1>我的评论</h1>
    <p>共 <?= count($rows) ?> 条评论。处于「待审核」的评论暂时仅自己可见。</p>
</div>

<?php if ($rows === []): ?>
    <div class="empty"><i class="fa-regular fa-comment"></i><p>还没有发表过评论。</p></div>
<?php else: ?>
    <div class="simple-list">
        <?php foreach ($rows as $row): ?>
            <div class="simple-item" style="align-items:flex-start;">
                <div class="grow">
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px;">
                        <a href="<?= url('/book/' . (int) $row['book_id'] . '#comments') ?>" style="font-family:var(--serif);font-size:13.5px;"><?= e($row['book_title'] ?? '作品') ?></a>
                        <span class="badge <?= $row['status'] === 'approved' ? 'badge-green' : ($row['status'] === 'waiting' ? 'badge-gold' : 'badge-gray') ?>">
                            <?= e(status_label((string) $row['status'])) ?>
                        </span>
                    </div>
                    <div style="font-size:12.5px;color:var(--ink-soft);line-height:1.9;"><?= nl2br(e($row['content'])) ?></div>
                    <div class="sub" style="margin-top:4px;"><?= time_ago($row['created_at']) ?> · 获赞 <?= (int) $row['like_count'] ?></div>
                </div>
                <form method="post" action="<?= url('/user/comments/delete') ?>" data-confirm="删除这条评论？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                    <button class="btn btn-ghost btn-sm" type="submit">删除</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
