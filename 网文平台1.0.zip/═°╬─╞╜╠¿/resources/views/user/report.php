<?php
/** 提交举报 */
$typeNames = ['book' => '作品', 'chapter' => '章节', 'comment' => '评论', 'user' => '用户', 'cover' => '封面', 'summary' => '简介'];
$hasTarget = $targetType !== '' && (int) $targetId > 0;
$targetTitle = $hasTarget ? ($target['title'] ?? ($target['content'] ?? ($target['nickname'] ?? ('#' . $targetId)))) : '';
?>
<div class="page-hero" style="margin-bottom:20px;">
    <div class="eyebrow">REPORT CONTENT</div>
    <h1 style="font-size:26px;">内容举报</h1>
    <p>请尽量准确描述问题，我们会逐条核查并反馈处理结果。</p>
</div>

<div class="container-narrow" style="width:100%;padding:0;">
<?php if (!$hasTarget): ?>
    <form class="form-card" method="get" action="<?= e(url('/report')) ?>">
        <input type="hidden" name="r" value="/report">
        <div class="field full">
            <label for="report-q">搜索要举报的作品</label>
            <div style="display:flex;gap:8px;">
                <input class="input" id="report-q" type="search" name="q" value="<?= e($keyword) ?>" placeholder="输入作品名或作者名">
                <button class="btn btn-primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> 搜索</button>
            </div>
            <span class="hint">章节、评论、用户等对象，请从对应页面的举报入口提交。</span>
        </div>
    </form>

    <?php if ($keyword !== ''): ?>
        <div class="form-card" style="padding:6px 0;margin-top:16px;">
            <?php if ($books === []): ?>
                <p class="hint" style="padding:4px 18px;">没有找到相关作品，试试其他关键词。</p>
            <?php else: ?>
                <?php foreach ($books as $b): ?>
                    <div class="report-book-item">
                        <a class="catalog-cover" href="<?= e(url('/book/' . (int) $b['id'])) ?>" style="background: <?= e(cover_gradient((int) $b['id'])) ?>;">
                            <?php if (!empty($b['cover'])): ?>
                                <img src="<?= e(upload_url((string) $b['cover'])) ?>" alt="<?= e($b['title']) ?>">
                            <?php endif; ?>
                            <span><?= e($b['title']) ?></span>
                        </a>
                        <div style="flex:1;min-width:0;">
                            <a href="<?= e(url('/book/' . (int) $b['id'])) ?>" style="font-family:var(--serif);font-size:14.5px;color:var(--ink);text-decoration:none;"><?= e($b['title']) ?></a>
                            <div style="font-size:11.5px;color:var(--ink-faint);margin-top:3px;"><?= author_avatar($b['pen_name'] ?? null, 'xs', $b['author_avatar'] ?? null) ?><?= e($b['pen_name']) ?> · <?= e(status_label((string) $b['status'])) ?></div>
                        </div>
                        <a class="btn btn-ghost btn-sm" href="<?= e(url('/report', ['target_type' => 'book', 'target_id' => (int) $b['id']])) ?>">举报</a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php else: ?>
    <div class="report-target">
        <span class="label">举报对象</span>
        <strong><?= e($typeNames[$targetType] ?? '内容') ?> #<?= (int) $targetId ?></strong> · <?= e(excerpt((string) $targetTitle, 80)) ?>
        <?php if (!empty($target['book_title'])): ?>
            <div style="font-size:11.5px;color:var(--ink-faint);margin-top:4px;">所属作品：<?= e($target['book_title']) ?></div>
        <?php endif; ?>
    </div>

    <form class="form-card" method="post" action="<?= url('/report') ?>" data-lock-submit>
        <?= csrf_field() ?>
        <input type="hidden" name="target_type" value="<?= e($targetType) ?>">
        <input type="hidden" name="target_id" value="<?= (int) $targetId ?>">
        <input type="hidden" name="back" value="<?= e($back) ?>">

        <div class="form-grid">
            <div class="field full">
                <label for="category">举报分类</label>
                <select class="select" id="category" name="category">
                    <option value="violation">违法违规内容</option>
                    <option value="copyright">侵犯版权 / 抄袭</option>
                    <option value="spam">垃圾广告或引流</option>
                    <option value="minor">涉及未成年人保护</option>
                    <option value="other">其他问题</option>
                </select>
            </div>
            <div class="field full">
                <label for="description">问题描述</label>
                <textarea class="textarea" id="description" name="description" maxlength="500" placeholder="请描述具体位置与问题，例如：第 3 章出现侵权转载内容。"></textarea>
                <span class="hint">最多 500 字。请勿在描述中填写他人隐私信息。</span>
            </div>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i> 提交举报</button>
            <a class="btn btn-ghost" href="<?= e(url($back)) ?>">返回</a>
        </div>
    </form>
<?php endif; ?>

    <div class="form-card" style="background:rgba(251,247,242,.7);">
        <p style="font-size:11.5px;color:var(--ink-faint);line-height:2;">
            <i class="fa-solid fa-shield-halved" style="color:var(--rose);"></i>
            举报受理后，站长后台会进入处置队列。处理结果会通知你，但不会向被举报人展示举报人身份。
            恶意举报可能被限制举报权限。
        </p>
    </div>
</div>
