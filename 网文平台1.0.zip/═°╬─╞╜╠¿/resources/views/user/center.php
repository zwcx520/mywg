<?php /** 读者中心 */ ?>
<div class="account-head">
    <div class="account-intro">
        <?= avatar_thumb($currentUser['avatar'] ?? null, (string) ($currentUser['nickname'] ?? $currentUser['login_name']), 'lg') ?>
        <div>
            <h1>晚上好，<?= e($currentUser['nickname'] ?? $currentUser['login_name']) ?></h1>
            <p>这里是你的阅读角落。书架、足迹与消息，都安静地放在这里。</p>
            <?php if (!empty($currentUser['bio'])): ?>
                <p style="margin-top:8px;font-size:13px;color:var(--ink-soft);line-height:1.7;overflow-wrap:break-word;word-break:break-word;"><?= e($currentUser['bio']) ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="stat-grid">
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-bookmark"></i>书架作品</div>
        <div class="val"><?= (int) $stats['shelf'] ?></div>
        <div class="hint"><a href="<?= url('/user/bookshelf') ?>" style="color:inherit;">去书架 →</a></div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-clock-rotate-left"></i>阅读足迹</div>
        <div class="val"><?= (int) $stats['history'] ?></div>
        <div class="hint"><a href="<?= url('/user/history') ?>" style="color:inherit;">查看历史 →</a></div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-comment-dots"></i>我的评论</div>
        <div class="val"><?= (int) $stats['comments'] ?></div>
        <div class="hint"><a href="<?= url('/user/comments') ?>" style="color:inherit;">管理评论 →</a></div>
    </div>
    <div class="stat-card">
        <div class="lbl"><i class="fa-solid fa-bell"></i>未读通知</div>
        <div class="val"><?= (int) $stats['notices'] ?></div>
        <div class="hint"><a href="<?= url('/user/notices') ?>" style="color:inherit;">查看通知 →</a></div>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;" class="center-two">
    <section class="form-card" style="margin-bottom:0;">
        <div class="panel-head">
            <h2 style="font-size:17px;">继续阅读</h2>
            <a class="more-link" href="<?= url('/user/history') ?>">全部</a>
        </div>
        <?php if ($history === []): ?>
            <div class="empty" style="padding:24px;"><i class="fa-solid fa-book-open"></i><p>还没有阅读记录，去找一本书吧。</p></div>
        <?php else: ?>
            <div class="simple-list">
                <?php foreach ($history as $item): ?>
                    <a class="simple-item" href="<?= url('/chapter/' . (int) $item['chapter_id']) ?>">
                        <div class="grow">
                            <div class="title" style="font-family:var(--serif);"><?= e($item['title']) ?></div>
                            <div class="sub"><?= e($item['chapter_title'] ?? '') ?> · <?= time_ago($item['read_at']) ?></div>
                        </div>
                        <i class="fa-solid fa-arrow-right" style="color:var(--rose);font-size:11px;"></i>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <section class="form-card" style="margin-bottom:0;">
        <div class="panel-head">
            <h2 style="font-size:17px;">最新通知</h2>
            <a class="more-link" href="<?= url('/user/notices') ?>">全部</a>
        </div>
        <?php if ($notices === []): ?>
            <div class="empty" style="padding:24px;"><i class="fa-regular fa-bell"></i><p>暂无通知。</p></div>
        <?php else: ?>
            <div class="simple-list">
                <?php foreach ($notices as $notice): ?>
                    <div class="simple-item">
                        <div class="grow">
                            <div class="title"><?= e($notice['title']) ?></div>
                            <div class="sub"><?= e(excerpt((string) $notice['content'], 60)) ?> · <?= time_ago($notice['created_at']) ?></div>
                        </div>
                        <?php if (empty($notice['is_read'])): ?>
                            <span class="badge">未读</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</div>

<div class="form-card" style="margin-top:20px;">
    <div class="panel-head"><h2 style="font-size:17px;">创作身份</h2></div>
    <?php if ($author !== null): ?>
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
            <span class="author-avatar"><?php $authorAvatar = $currentUser['avatar'] ?? ($author['avatar'] ?? null); ?><?php if (!empty($authorAvatar)): ?><img src="<?= e(upload_url((string) $authorAvatar)) ?>" alt=""><?php else: ?><?= e(mb_substr((string) $author['pen_name'], 0, 1, 'UTF-8')) ?><?php endif; ?></span>
            <div style="flex:1;min-width:200px;">
                <div style="font-family:var(--serif);font-size:16px;"><?= e($author['pen_name']) ?></div>
                <div style="font-size:11.5px;color:var(--ink-faint);"><?= e($author['intro'] ?? '这位作者还没有写下自我介绍。') ?></div>
            </div>
            <a class="btn btn-primary btn-sm" href="<?= url('/author') ?>"><i class="fa-solid fa-feather-pointed"></i> 进入作家中心</a>
        </div>
    <?php else: ?>
        <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
            <span class="author-avatar"><i class="fa-solid fa-feather-pointed"></i></span>
            <div style="flex:1;min-width:200px;">
                <div style="font-family:var(--serif);font-size:16px;">成为平台作者</div>
                <div style="font-size:11.5px;color:var(--ink-faint);">完成实名认证后即可创建作品、分卷与章节，作品将先审后发。</div>
            </div>
            <a class="btn btn-soft btn-sm" href="<?= url('/author/apply') ?>"><i class="fa-solid fa-id-card"></i> 去认证</a>
        </div>
    <?php endif; ?>
</div>

<style>@media (max-width:900px){.center-two{grid-template-columns:1fr !important;}}</style>
