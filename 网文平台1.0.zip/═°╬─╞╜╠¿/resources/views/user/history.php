<?php /** 阅读历史 */ ?>
<div class="account-head">
    <h1>阅读历史</h1>
    <p>最近 <?= count($rows) ?> 条阅读记录。历史只对你自己可见。</p>
</div>

<?php if ($rows === []): ?>
    <div class="empty"><i class="fa-solid fa-clock-rotate-left"></i><p>还没有阅读记录。</p></div>
<?php else: ?>
    <div class="form-card" style="padding:18px 22px;">
        <div class="panel-head" style="margin-bottom:8px;">
            <span style="font-size:12px;color:var(--ink-faint);">按最近阅读排序</span>
            <form method="post" action="<?= url('/user/history/clear') ?>" data-confirm="确定清空全部阅读历史？该操作不可撤销。" data-danger>
                <?= csrf_field() ?>
                <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-broom"></i> 清空历史</button>
            </form>
        </div>
        <div class="simple-list">
            <?php foreach ($rows as $row): ?>
                <div class="simple-item">
                    <div class="grow">
                        <a class="title" href="<?= url('/chapter/' . (int) $row['chapter_id']) ?>"><?= e($row['book_title'] ?? ($row['title'] ?? '作品')) ?></a>
                        <div class="sub"><?= e($row['chapter_title'] ?? '') ?> · <?= author_avatar($row['pen_name'] ?? null, 'xs', $row['author_avatar'] ?? null) ?><?= e($row['pen_name'] ?? '') ?> · <?= time_ago($row['read_at']) ?></div>
                    </div>
                    <a class="btn btn-soft btn-sm" href="<?= url('/chapter/' . (int) $row['chapter_id']) ?>">继续读</a>
                    <form method="post" action="<?= url('/user/history/delete') ?>" data-confirm="删除这条阅读记录？">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int) $row['id'] ?>">
                        <button class="btn btn-ghost btn-sm" type="submit"><i class="fa-solid fa-xmark"></i></button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
