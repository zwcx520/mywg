<?php /** 我的书架 */ ?>
<div class="account-head">
    <h1>我的书架</h1>
    <p>共 <?= count($rows) ?> 部作品。可按分组整理，阅读进度会自动记录。</p>
</div>

<?php if ($rows === []): ?>
    <div class="empty"><i class="fa-regular fa-bookmark"></i><p>书架还是空的。去 <a href="<?= url('/search') ?>" style="color:var(--rose-deep);">找书</a> 逛逛吧。</p></div>
<?php else: ?>
    <?php foreach ($groups as $groupName => $items): ?>
        <section style="margin-bottom:26px;">
            <div class="section-head" style="margin-bottom:12px;">
                <h2 style="font-size:16px;letter-spacing:.08em;"><i class="fa-solid fa-folder-open" style="color:var(--rose);margin-right:8px;"></i><?= e($groupName === '' ? '默认分组' : $groupName) ?></h2>
                <span style="font-size:11px;color:var(--ink-faint);"><?= count($items) ?> 部</span>
            </div>
            <div class="book-grid" style="grid-template-columns:repeat(2,minmax(0,1fr));">
                <?php foreach ($items as $item): ?>
                    <div class="book-card" style="align-items:flex-start;">
                        <a class="book-cover" href="<?= url('/book/' . (int) $item['book_id']) ?>" style="background:<?= e(cover_gradient((int) $item['book_id'])) ?>;">
                            <?php if (!empty($item['cover'])): ?>
                                <img src="<?= e(upload_url((string) $item['cover'])) ?>" alt="">
                            <?php endif; ?>
                            <span class="cover-title" style="font-size:11px;"><?= e($item['title']) ?></span>
                        </a>
                        <div class="book-body">
                            <a class="book-title" href="<?= url('/book/' . (int) $item['book_id']) ?>" style="font-size:14px;"><?= e($item['title']) ?></a>
                            <span class="book-author"><?= author_avatar($item['pen_name'] ?? null, 'xs', $item['author_avatar'] ?? null) ?><?= e($item['pen_name'] ?? '佚名') ?> · <?= (int) $item['chapter_count'] ?> 章</span>
                            <span class="book-meta">
                                <span class="badge badge-gray"><?= e(status_label((string) $item['status'])) ?></span>
                                <span><?= number_format((int) $item['word_count']) ?> 字</span>
                            </span>
                            <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;">
                                <a class="btn btn-soft btn-sm" href="<?= url('/book/' . (int) $item['book_id'] . '/catalog') ?>">目录</a>
                                <form method="post" action="<?= url('/user/bookshelf/remove') ?>" data-confirm="确定从书架移除《<?= e($item['title']) ?>》吗？">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="book_id" value="<?= (int) $item['book_id'] ?>">
                                    <button class="btn btn-ghost btn-sm" type="submit">移除</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endforeach; ?>
<?php endif; ?>
