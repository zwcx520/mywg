<?php /** 账号设置 */ ?>
<div class="account-head">
    <h1>账号设置</h1>
    <p>管理个人资料、头像与阅读偏好。</p>
</div>

<form class="form-card" method="post" action="<?= url('/user/settings') ?>" enctype="multipart/form-data" data-lock-submit>
    <?= csrf_field() ?>

    <div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;flex-wrap:wrap;">
        <span class="author-avatar" id="avatar-preview" style="width:64px;height:64px;font-size:24px;overflow:hidden;">
            <?php if (!empty($userRow['avatar'])): ?>
                <img src="<?= e(upload_url((string) $userRow['avatar'])) ?>" alt="">
            <?php else: ?>
                <?= e(mb_substr((string) ($userRow['nickname'] ?? '读'), 0, 1, 'UTF-8')) ?>
            <?php endif; ?>
        </span>
        <div class="field" style="flex:1;min-width:200px;">
            <label for="avatar">更换头像</label>
            <input class="input" id="avatar" type="file" name="avatar" accept="image/jpeg,image/png,image/webp,image/gif">
            <span class="hint">支持 jpg / png / webp / gif，大小不超过 20MB。</span>
        </div>
    </div>

    <div class="form-grid">
        <div class="field">
            <label for="nickname">昵称</label>
            <input class="input" id="nickname" type="text" name="nickname" maxlength="20" value="<?= e($userRow['nickname'] ?? '') ?>" required>
        </div>
        <div class="field">
            <label for="gender">性别</label>
            <select class="select" id="gender" name="gender">
                <option value="">不设置</option>
                <option value="female" <?= ($userRow['gender'] ?? '') === 'female' ? 'selected' : '' ?>>女</option>
                <option value="male" <?= ($userRow['gender'] ?? '') === 'male' ? 'selected' : '' ?>>男</option>
                <option value="other" <?= ($userRow['gender'] ?? '') === 'other' ? 'selected' : '' ?>>其他</option>
            </select>
        </div>
        <div class="field">
            <label for="city">所在城市</label>
            <input class="input" id="city" type="text" name="city" maxlength="40" value="<?= e($userRow['city'] ?? '') ?>">
        </div>
        <div class="field">
            <label>账号</label>
            <input class="input" type="text" value="<?= e(($userRow['login_name'] ?? '') . ' / ' . ($userRow['phone'] ?? $userRow['email'] ?? '')) ?>" disabled>
            <span class="hint">账号信息如需修改，请联系站长。</span>
        </div>
        <div class="field full">
            <label for="bio">个人简介</label>
            <textarea class="textarea" id="bio" name="bio" maxlength="255" style="min-height:80px;"><?= e($userRow['bio'] ?? '') ?></textarea>
        </div>
    </div>

    <div style="border-top:1px dashed var(--line);margin:24px 0 18px;"></div>
    <h2 style="font-size:16px;letter-spacing:.08em;margin-bottom:14px;">阅读偏好</h2>

    <div class="form-grid">
        <div class="field">
            <label for="font_size">默认字号</label>
            <select class="select" id="font_size" name="font_size">
                <?php foreach ([14, 16, 18, 20, 22, 24, 26] as $size): ?>
                    <option value="<?= $size ?>" <?= (int) ($settings['font_size'] ?? 18) === $size ? 'selected' : '' ?>><?= $size ?> px</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field">
            <label for="line_height">默认行距（整数档位）</label>
            <select class="select" id="line_height" name="line_height">
                <option value="2" <?= (int) ($settings['line_height'] ?? 2) === 2 ? 'selected' : '' ?>>2 · 舒适</option>
                <option value="3" <?= (int) ($settings['line_height'] ?? 2) === 3 ? 'selected' : '' ?>>3 · 宽松</option>
                <option value="4" <?= (int) ($settings['line_height'] ?? 2) === 4 ? 'selected' : '' ?>>4 · 疏朗</option>
            </select>
        </div>
        <div class="field">
            <label for="theme">阅读主题</label>
            <select class="select" id="theme" name="theme">
                <option value="light" <?= ($settings['theme'] ?? 'light') === 'light' ? 'selected' : '' ?>>暖白</option>
                <option value="sepia" <?= ($settings['theme'] ?? '') === 'sepia' ? 'selected' : '' ?>>纸黄</option>
                <option value="night" <?= ($settings['theme'] ?? '') === 'night' ? 'selected' : '' ?>>夜读</option>
            </select>
        </div>
        <div class="field">
            <label for="reading_mode">翻页方式</label>
            <select class="select" id="reading_mode" name="reading_mode">
                <option value="scroll" <?= ($settings['reading_mode'] ?? 'scroll') === 'scroll' ? 'selected' : '' ?>>上下滚动</option>
                <option value="paged" <?= ($settings['reading_mode'] ?? '') === 'paged' ? 'selected' : '' ?>>分页阅读</option>
            </select>
        </div>
    </div>

    <div class="form-actions">
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-check"></i> 保存设置</button>
    </div>
</form>

<div class="form-card">
    <h2 style="font-size:16px;letter-spacing:.08em;margin-bottom:8px;">修改密码</h2>
    <p style="font-size:12px;color:var(--ink-faint);line-height:1.9;margin-bottom:14px;">密码至少 8 个字符；忘记密码可在登录页使用「忘记密码」。</p>
    <form method="post" action="<?= url('/user/password') ?>" data-lock-submit>
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="field">
                <label for="p_current">当前密码</label>
                <input class="input" id="p_current" type="password" name="current_password" autocomplete="current-password" required>
            </div>
            <div class="field">
                <label for="p_new">新密码</label>
                <input class="input" id="p_new" type="password" name="new_password" minlength="8" autocomplete="new-password" required>
            </div>
            <div class="field">
                <label for="p_confirm">确认新密码</label>
                <input class="input" id="p_confirm" type="password" name="confirm_password" minlength="8" autocomplete="new-password" required>
            </div>
        </div>
        <div class="form-actions">
            <button class="btn btn-primary" type="submit"><i class="fa-solid fa-key"></i> 更新密码</button>
        </div>
    </form>
</div>

<div class="form-card" style="border-color:#edcbd0;">
    <h2 style="font-size:16px;letter-spacing:.08em;color:#a14550;margin-bottom:8px;">注销账号</h2>
    <p style="font-size:12px;color:var(--ink-faint);line-height:1.9;margin-bottom:14px;">
        提交后账号立即无法登录，并进入 5 天冷静期。冷静期内可联系站长恢复；满 5 天后将永久删除账号，以及你的作品、章节、评论、书架与全部上传文件，且不可恢复。
    </p>
    <form method="post" action="<?= url('/user/cancel') ?>" data-confirm="确定要注销账号吗？该操作不可自行撤销。" data-danger>
        <?= csrf_field() ?>
        <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-user-slash"></i> 提交注销申请</button>
    </form>
</div>
