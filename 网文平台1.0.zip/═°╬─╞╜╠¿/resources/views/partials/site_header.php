<?php
/** 公共站点头部（读者端与账户中心共用） */
$path = \App\Core\Request::path();
$navActive = static function (string $prefix) use ($path): string {
    if ($prefix === '/') {
        return $path === '/' ? 'is-active' : '';
    }
    return str_starts_with($path, $prefix) ? 'is-active' : '';
};
$navCategories = [];
try {
    $navCategories = \App\Core\Database::all(
        'SELECT id, name FROM book_categories WHERE parent_id IS NULL ORDER BY sort ASC, id ASC LIMIT 12'
    );
} catch (\Throwable $e) {
    $navCategories = [];
}
?>
<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="<?= url('/') ?>">
            <span class="brand-seal"><i class="fa-solid fa-feather-pointed"></i></span>
            <span>
                <span class="brand-name"><?= e(setting('site_name', $site['site_name'] ?? '墨韵文阁')) ?></span>
                <span class="brand-sub"><?= e(setting('site_slogan', '在字里行间，与你重逢')) ?></span>
            </span>
        </a>

        <nav class="nav-links" aria-label="主导航">
            <a class="nav-link <?= $navActive('/') ?>" href="<?= url('/') ?>">首页</a>
            <a class="nav-link <?= $navActive('/search') ?>" href="<?= url('/search') ?>">找书</a>
            <a class="nav-link <?= $navActive('/ranking') ?>" href="<?= url('/ranking') ?>">榜单</a>
            <a class="nav-link <?= $navActive('/activities') ?>" href="<?= url('/activities') ?>">活动</a>
            <a class="nav-link <?= $navActive('/announcements') ?>" href="<?= url('/announcements') ?>">公告</a>
            <a class="nav-link <?= $navActive('/about') ?>" href="<?= url('/about') ?>">关于</a>
        </nav>

        <form class="search-form desktop-search" action="<?= url('/search') ?>" method="get" role="search">
            <input type="hidden" name="r" value="/search">
            <input type="search" name="q" placeholder="搜索书名、作者或关键词" value="<?= e(\App\Core\Request::str('q', '')) ?>" aria-label="站内搜索">
            <button type="submit" aria-label="搜索"><i class="fa-solid fa-magnifying-glass"></i></button>
        </form>

        <div class="user-nav">
            <?php if ($currentUser !== null): ?>
                <a class="btn btn-soft btn-sm nav-auth nav-user" href="<?= url('/user') ?>" aria-label="<?= e((string) ($currentUser['nickname'] ?? $currentUser['login_name'])) ?>"<?= !empty($currentUser['bio']) ? ' title="' . e($currentUser['bio']) . '"' : '' ?>>
                    <?= avatar_thumb($currentUser['avatar'] ?? null, (string) ($currentUser['nickname'] ?? $currentUser['login_name']), 'xs') ?>
                    <span class="nav-user-name"><?= e(mb_substr((string) ($currentUser['nickname'] ?? $currentUser['login_name']), 0, 10, 'UTF-8')) ?></span>
                </a>
                <?php if (auth_can('admin.access')): ?>
                    <a class="btn btn-ghost btn-sm nav-auth" href="<?= url('/admin') ?>"><i class="fa-solid fa-sliders"></i>后台</a>
                <?php endif; ?>
                <form class="nav-auth" method="post" action="<?= url('/logout') ?>">
                    <?= csrf_field() ?>
                    <button class="btn btn-ghost btn-sm" type="submit"><i class="fa-solid fa-arrow-right-from-bracket"></i>退出</button>
                </form>
            <?php else: ?>
                <a class="btn btn-ghost btn-sm nav-auth" href="<?= url('/login') ?>">登录</a>
                <a class="btn btn-primary btn-sm nav-auth" href="<?= url('/register') ?>">注册</a>
            <?php endif; ?>
            <button class="device-toggle desktop-only" type="button" data-view-mode="<?= is_mobile() ? 'desktop' : 'mobile' ?>" title="切换浏览模式">
                <i class="fa-solid <?= is_mobile() ? 'fa-desktop' : 'fa-mobile-screen' ?>"></i>
                <?= is_mobile() ? '电脑版' : '手机版' ?>
            </button>
            <button class="nav-toggle" type="button" data-drawer-open aria-label="打开菜单">
                <i class="fa-solid fa-bars"></i>
            </button>
        </div>
    </div>
</header>

<div class="drawer" data-drawer>
    <div class="drawer-mask"></div>
    <aside class="drawer-panel" aria-label="移动端菜单">
        <button class="drawer-close" type="button" data-drawer-close aria-label="关闭菜单"><i class="fa-solid fa-xmark"></i></button>

        <form class="search-form" action="<?= url('/search') ?>" method="get" style="margin: 6px 0 8px; flex: none;">
            <input type="hidden" name="r" value="/search">
            <input type="search" name="q" placeholder="搜索书名、作者或关键词" value="<?= e(\App\Core\Request::str('q', '')) ?>">
            <button type="submit" aria-label="搜索"><i class="fa-solid fa-magnifying-glass"></i></button>
        </form>

        <a class="drawer-link" href="<?= url('/') ?>"><i class="fa-solid fa-house"></i>首页</a>
        <a class="drawer-link" href="<?= url('/search') ?>"><i class="fa-solid fa-compass"></i>找书</a>
        <a class="drawer-link" href="<?= url('/ranking') ?>"><i class="fa-solid fa-ranking-star"></i>榜单</a>
        <a class="drawer-link" href="<?= url('/activities') ?>"><i class="fa-solid fa-gift"></i>活动</a>
        <a class="drawer-link" href="<?= url('/announcements') ?>"><i class="fa-solid fa-bullhorn"></i>公告</a>
        <a class="drawer-link" href="<?= url('/about') ?>"><i class="fa-solid fa-circle-info"></i>关于</a>

        <div class="drawer-divider"></div>
        <?php foreach (array_slice($navCategories, 0, 6) as $category): ?>
            <a class="drawer-link" href="<?= url('/category/' . (int) $category['id']) ?>"><i class="fa-solid fa-tag"></i><?= e($category['name']) ?></a>
        <?php endforeach; ?>

        <div class="drawer-divider"></div>
        <?php if ($currentUser !== null): ?>
            <a class="drawer-link" href="<?= url('/user') ?>"><i class="fa-solid fa-user"></i>读者中心</a>
            <a class="drawer-link" href="<?= url('/author') ?>"><i class="fa-solid fa-feather-pointed"></i>作家中心</a>
            <?php if (auth_can('admin.access')): ?>
                <a class="drawer-link" href="<?= url('/admin') ?>"><i class="fa-solid fa-sliders"></i>站长后台</a>
            <?php endif; ?>
            <form method="post" action="<?= url('/logout') ?>">
                <?= csrf_field() ?>
                <button class="drawer-link" type="submit" style="width:100%;border:0;background:transparent;cursor:pointer;text-align:left;">
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>退出登录
                </button>
            </form>
        <?php else: ?>
            <a class="drawer-link" href="<?= url('/login') ?>"><i class="fa-solid fa-right-to-bracket"></i>登录</a>
            <a class="drawer-link" href="<?= url('/register') ?>"><i class="fa-solid fa-user-plus"></i>注册</a>
        <?php endif; ?>

        <div class="drawer-divider"></div>
        <button class="drawer-link" type="button" data-view-mode="<?= is_mobile() ? 'desktop' : 'mobile' ?>" style="border:0;background:transparent;cursor:pointer;text-align:left;width:100%;">
            <i class="fa-solid <?= is_mobile() ? 'fa-desktop' : 'fa-mobile-screen' ?>"></i>
            切换到<?= is_mobile() ? '电脑版' : '手机版' ?>
        </button>
    </aside>
</div>
