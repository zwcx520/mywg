<?php
/** 书卡（书库、搜索、推荐位共用） */
?>
<a class="book-card" href="<?= url('/book/' . (int) $book['id']) ?>">
    <span class="book-cover" style="background: <?= e(cover_gradient((int) ($book['id'] ?? 0))) ?>;">
        <?php if (!empty($book['cover'])): ?>
            <img src="<?= e(upload_url((string) $book['cover'])) ?>" alt="<?= e($book['title'] ?? '') ?>" loading="lazy">
        <?php endif; ?>
        <span class="cover-title"><?= e($book['title'] ?? '') ?></span>
    </span>
    <span class="book-body">
        <span class="book-title"><?= e($book['title'] ?? '') ?></span>
        <span class="book-author"><?= author_avatar($book['pen_name'] ?? ($book['author_name'] ?? null), 'xs', $book['author_avatar'] ?? null) ?><?= e($book['pen_name'] ?? ($book['author_name'] ?? '佚名')) ?></span>
        <?php if (!empty($book['summary'])): ?>
            <span class="book-summary"><?= e(excerpt((string) $book['summary'], 90)) ?></span>
        <?php endif; ?>
        <span class="book-meta">
            <span class="badge badge-gray"><?= e(status_label((string) ($book['status'] ?? 'serializing'))) ?></span>
            <span><?= number_format((int) ($book['word_count'] ?? 0)) ?> 字</span>
            <span class="dot"></span>
            <span><?= e($book['category_name'] ?? '') ?></span>
        </span>
    </span>
</a>
