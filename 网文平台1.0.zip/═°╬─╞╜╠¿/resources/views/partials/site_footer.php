<?php /** 公共站点页脚 */ ?>
<footer class="site-footer">
    <div class="container">
        <div class="footer-inner">
            <div class="footer-brand">
                <div class="brand" style="margin-bottom: 10px;">
                    <span class="brand-seal"><i class="fa-solid fa-feather-pointed"></i></span>
                    <span>
                        <span class="brand-name"><?= e(setting('site_name', '墨韵文阁')) ?></span>
                        <span class="brand-sub"><?= e(setting('site_slogan', '在字里行间，与你重逢')) ?></span>
                    </span>
                </div>
                <p><?= e(setting('site_desc', '一个温柔、克制、尊重版权的原创网络文学平台。所有作品先审后发，愿每一位读者都能在这里遇见值得等待的故事。')) ?></p>
            </div>
            <div class="footer-col">
                <h4>发现</h4>
                <a href="<?= url('/search') ?>">找书</a>
                <a href="<?= url('/ranking') ?>">排行榜</a>
                <a href="<?= url('/activities') ?>">站内活动</a>
                <a href="<?= url('/announcements') ?>">平台公告</a>
            </div>
            <div class="footer-col">
                <h4>参与</h4>
                <a href="<?= url('/author/apply') ?>">作家认证</a>
                <a href="<?= url('/author') ?>">作家创作台</a>
                <a href="<?= url('/report') ?>">内容举报</a>
                <a href="<?= url('/about') ?>">关于我们</a>
            </div>
        </div>
        <div class="footer-bottom">
            <span><?= e(setting('copyright_text', '© ' . date('Y') . ' 墨韵文阁 · 原创文学平台')) ?></span>
            <span><?= e(setting('icp_no', '备案信息请在后台上传')) ?></span>
            <span>所有作品均执行先审后发 · 尊重原创 · 拒绝侵权</span>
        </div>
    </div>
</footer>
