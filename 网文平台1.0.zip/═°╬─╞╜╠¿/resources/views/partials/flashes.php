<?php
/** 通用 Flash 提示 */
$flashIcons = [
    'success' => 'fa-circle-check',
    'error' => 'fa-circle-exclamation',
    'warning' => 'fa-triangle-exclamation',
    'info' => 'fa-circle-info',
];
if (!empty($flashes)):
?>
<div class="flashes">
    <?php foreach ($flashes as $flash): ?>
        <div class="flash flash-<?= e($flash['type'] ?? 'info') ?>">
            <i class="fa-solid <?= e($flashIcons[$flash['type'] ?? 'info'] ?? 'fa-circle-info') ?>"></i>
            <span><?= e($flash['message'] ?? '') ?></span>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
