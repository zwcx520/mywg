<?php
declare(strict_types=1);

if (!is_file(__DIR__ . '/config/config.php')) {
    $base = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php'))), '/');
    header('Location: ' . ($base === '' ? '' : $base) . '/install.php');
    exit;
}

require __DIR__ . '/app/bootstrap.php';

/** @var App\Core\Router $router */
$router = require __DIR__ . '/app/routes.php';
$router->dispatch();
